/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Page, Dish, CartItem } from './types';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { MenuPage } from './pages/MenuPage';
import { AboutPage } from './pages/AboutPage';
import { GalleryPage } from './pages/GalleryPage';
import { ReservationPage } from './pages/ReservationPage';
import { OrderingPage } from './pages/OrderingPage';
import { ContactPage } from './pages/ContactPage';
import { DishDetailModal } from './components/DishDetailModal';
import { ToastContainer } from './components/ToastContainer';
import { QuickAccessNav } from './components/QuickAccessNav';
import { FavoritesProvider } from './context/FavoritesContext';
import { DISHES } from './data/restaurantData';
import { luxuryAudio } from './utils/audioSynth';

// Register GSAP plugins
gsap.registerPlugin(ScrollTrigger);

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedDish, setSelectedDish] = useState<Dish | null>(null);
  const [cart, setCart] = useState<CartItem[]>([
    // Pre-populate with one signature dish for instant concierge cart feedback
    { dish: DISHES[0], quantity: 1 }
  ]);

  // Initialize auto-play default luxury piano audio
  useEffect(() => {
    luxuryAudio.setupAutoPlay();
  }, []);

  // Global Lenis Smooth Scrolling Engine
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 0.95,
      touchMultiplier: 1.5,
    });

    lenis.on('scroll', ScrollTrigger.update);

    const updateTicker = (time: number) => {
      lenis.raf(time * 1000);
    };

    gsap.ticker.add(updateTicker);
    gsap.ticker.lagSmoothing(0);

    (window as any).__molaqat_lenis = lenis;

    return () => {
      gsap.ticker.remove(updateTicker);
      lenis.destroy();
      delete (window as any).__molaqat_lenis;
    };
  }, []);

  // Scroll to top with Lenis on page change
  useEffect(() => {
    const lenis = (window as any).__molaqat_lenis;
    if (lenis) {
      lenis.scrollTo(0, { immediate: true });
    } else {
      window.scrollTo(0, 0);
    }
  }, [currentPage]);

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleAddToCart = (dish: Dish, quantity = 1, specialInstructions?: string) => {
    setCart((prevCart) => {
      const existingIndex = prevCart.findIndex((item) => item.dish.id === dish.id);
      if (existingIndex > -1) {
        const updated = [...prevCart];
        updated[existingIndex].quantity += quantity;
        if (specialInstructions) {
          updated[existingIndex].specialInstructions = specialInstructions;
        }
        return updated;
      } else {
        return [...prevCart, { dish, quantity, specialInstructions }];
      }
    });
  };

  const handleUpdateQuantity = (dishId: string, delta: number) => {
    setCart((prevCart) => {
      return prevCart
        .map((item) => {
          if (item.dish.id === dishId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const handleRemoveItem = (dishId: string) => {
    setCart((prev) => prev.filter((item) => item.dish.id !== dishId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const openCart = () => {
    setCurrentPage('order');
    const lenis = (window as any).__molaqat_lenis;
    if (lenis) {
      lenis.scrollTo(0, { immediate: true });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <FavoritesProvider>
      <div className="min-h-screen bg-[#08080a] text-[#e8e4dc] relative selection:bg-[#c5a059]/30 selection:text-[#f8edd6] luxury-stage-bg flex flex-col justify-between">
        
        {/* Floating Toast Notification System */}
        <ToastContainer />

        {/* Fixed Ambient Luxury Background Frame */}
        <div className="fixed inset-0 pointer-events-none z-0">
          {/* Subtle warm golden ambient orbs */}
          <div className="absolute -top-40 right-1/3 w-[600px] h-[600px] bg-[#c5a059]/[0.035] rounded-full blur-[140px]"></div>
          <div className="absolute top-1/2 left-0 w-[500px] h-[500px] bg-[#8c6b2d]/[0.025] rounded-full blur-[120px]"></div>
          <div className="absolute bottom-10 right-10 w-[600px] h-[600px] bg-[#1a1a2e]/[0.05] rounded-full blur-[160px]"></div>
        </div>

        {/* Persistent Navigation Header */}
        <Navbar
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          cartCount={cartCount}
          openCart={openCart}
        />

        {/* Main Page Body (RTL-first) */}
        <main className="relative z-10 flex-1">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentPage}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.3, ease: 'easeOut' }}
            >
              {currentPage === 'home' && (
                <HomePage
                  setCurrentPage={setCurrentPage}
                  onSelectDish={setSelectedDish}
                  onAddToCart={(dish) => handleAddToCart(dish, 1)}
                />
              )}

              {currentPage === 'menu' && (
                <MenuPage
                  setCurrentPage={setCurrentPage}
                  onSelectDish={setSelectedDish}
                  onAddToCart={(dish) => handleAddToCart(dish, 1)}
                />
              )}

              {currentPage === 'about' && (
                <AboutPage setCurrentPage={setCurrentPage} />
              )}

              {currentPage === 'gallery' && (
                <GalleryPage setCurrentPage={setCurrentPage} />
              )}

              {currentPage === 'reservation' && (
                <ReservationPage setCurrentPage={setCurrentPage} />
              )}

              {currentPage === 'order' && (
                <OrderingPage
                  cart={cart}
                  setCurrentPage={setCurrentPage}
                  onUpdateQuantity={handleUpdateQuantity}
                  onRemoveItem={handleRemoveItem}
                  onClearCart={handleClearCart}
                />
              )}

              {currentPage === 'contact' && (
                <ContactPage setCurrentPage={setCurrentPage} />
              )}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* Dish Detail Modal (Shared element style) */}
        <DishDetailModal
          dish={selectedDish}
          onClose={() => setSelectedDish(null)}
          onAddToCart={(dish, quantity, instructions) =>
            handleAddToCart(dish, quantity, instructions)
          }
        />

        {/* Fixed Quick Access Floating Dock Navigation */}
        <QuickAccessNav
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          cartCount={cartCount}
          openCart={openCart}
        />

        {/* Footer */}
        <Footer setCurrentPage={setCurrentPage} />

      </div>
    </FavoritesProvider>
  );
}
