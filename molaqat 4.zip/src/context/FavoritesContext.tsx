import React, { createContext, useContext, useState, useEffect } from 'react';
import { Dish } from '../types';
import { DISHES } from '../data/restaurantData';

interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  type: 'favorite' | 'cart' | 'info';
  timestamp: number;
}

interface FavoritesContextType {
  favorites: string[]; // dish IDs
  isFavorite: (dishId: string) => boolean;
  toggleFavorite: (dish: Dish) => boolean; // returns new status (true = added, false = removed)
  favoriteDishes: Dish[];
  toasts: ToastMessage[];
  showToast: (title: string, description?: string, type?: 'favorite' | 'cart' | 'info') => void;
  removeToast: (id: string) => void;
}

const FavoritesContext = createContext<FavoritesContextType | undefined>(undefined);

const STORAGE_KEY = 'molaqat_vip_favorites';

export const FavoritesProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : ['filet-mignon-truffe', 'foie-gras-poele']; // pre-favorite top 2 signature dishes
    } catch {
      return ['filet-mignon-truffe', 'foie-gras-poele'];
    }
  });

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(favorites));
    } catch (e) {
      console.error('Failed to save favorites to localStorage', e);
    }
  }, [favorites]);

  const showToast = (title: string, description?: string, type: 'favorite' | 'cart' | 'info' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    const newToast: ToastMessage = {
      id,
      title,
      description,
      type,
      timestamp: Date.now(),
    };

    setToasts((prev) => [...prev.slice(-3), newToast]);

    setTimeout(() => {
      removeToast(id);
    }, 3500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const isFavorite = (dishId: string) => {
    return favorites.includes(dishId);
  };

  const toggleFavorite = (dish: Dish) => {
    const currentlyFav = favorites.includes(dish.id);
    if (currentlyFav) {
      setFavorites((prev) => prev.filter((id) => id !== dish.id));
      showToast(
        'از علاقه‌مندی‌ها حذف شد',
        `بشقاب «${dish.persianName}» از فهرست علاقه‌مندی‌های شما برداشته شد.`,
        'favorite'
      );
      return false;
    } else {
      setFavorites((prev) => [...prev, dish.id]);
      showToast(
        '✦ به علاقه‌مندی‌های VIP افزوده شد',
        `بشقاب «${dish.persianName}» به فهرست اختصاصی شما اضافه گردید.`,
        'favorite'
      );
      return true;
    }
  };

  const favoriteDishes = DISHES.filter((dish) => favorites.includes(dish.id));

  return (
    <FavoritesContext.Provider
      value={{
        favorites,
        isFavorite,
        toggleFavorite,
        favoriteDishes,
        toasts,
        showToast,
        removeToast,
      }}
    >
      {children}
    </FavoritesContext.Provider>
  );
};

export const useFavorites = () => {
  const context = useContext(FavoritesContext);
  if (!context) {
    throw new Error('useFavorites must be used within a FavoritesProvider');
  }
  return context;
};
