export type Page = 
  | 'home'
  | 'menu'
  | 'about'
  | 'dish-detail'
  | 'order'
  | 'gallery'
  | 'reservation'
  | 'contact';

export type MenuCategoryId = 'entrees' | 'plats' | 'fromages' | 'desserts' | 'boissons';

export interface DishImageAngle {
  url: string;
  title: string;
  perspective: string;
}

export interface Dish {
  id: string;
  frenchName: string;
  persianName: string;
  persianSubtitle: string;
  category: MenuCategoryId;
  priceTomans: number;
  formattedPrice: string;
  image: string;
  galleryImages: DishImageAngle[];
  isSignature?: boolean;
  isRotating?: boolean;
  calories?: number;
  prepTimeMinutes: number;
  description: string;
  ingredients: string[];
  sommelierPairing: string;
  chefNote: string;
  serviceRitual?: string;
  originStory?: string;
  dietaryTags: string[];
  rating: number;
  reviewsCount: number;
}

export interface MenuCategory {
  id: MenuCategoryId;
  frenchTitle: string;
  persianTitle: string;
  persianSubtitle: string;
  thumbnail: string;
  icon3D: string;
}

export interface CartItem {
  dish: Dish;
  quantity: number;
  specialInstructions?: string;
}

export interface ReservationData {
  jalaliYear: number;
  jalaliMonth: string;
  jalaliDay: number;
  timeSlot: string;
  guestsCount: number;
  salon: string;
  guestName: string;
  guestPhone: string;
  occasion: string;
  specialNotes?: string;
  vipChauffeurRequired?: boolean;
  chauffeurCarModel?: 'bmw7' | 'mercedes-s' | 'none';
  pickupAddress?: string;
  caviarService?: boolean;
  sommelierConsultation?: boolean;
  floralArrangement?: boolean;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'interior' | 'cuisine' | 'vip' | 'details';
  categoryLabel: string;
  image: string;
  description: string;
}

export interface SalonExperience {
  id: string;
  persianName: string;
  frenchName: string;
  capacity: string;
  image: string;
  description: string;
  features: string[];
  recommendedFor: string;
}

export interface WalkthroughStep {
  id: number;
  title: string;
  frenchTitle: string;
  persianDescription: string;
  image: string;
  highlightText: string;
  soundCue: string;
}

export interface LuxuryGiftCard {
  id: string;
  title: string;
  frenchTitle: string;
  amountTomans: number;
  formattedAmount: string;
  packaging: string;
  perks: string[];
}
