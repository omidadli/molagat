import React, { useState, useEffect } from 'react';
import { Page } from '../types';
import { RESTAURANT_INFO } from '../data/restaurantData';
import { luxuryAudio } from '../utils/audioSynth';
import { MolaqatLogo } from './MolaqatLogo';
import { useFavorites } from '../context/FavoritesContext';
import { 
  ShoppingBag, 
  Calendar, 
  Menu as MenuIcon, 
  X, 
  Phone, 
  UtensilsCrossed, 
  Sparkles, 
  Home, 
  BookOpen, 
  Compass, 
  PhoneCall,
  Crown,
  Volume2,
  VolumeX,
  Music,
  Heart
} from 'lucide-react';

interface NavbarProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  cartCount: number;
  openCart: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  setCurrentPage,
  cartCount,
  openCart,
}) => {
  const { favorites } = useFavorites();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(luxuryAudio.getIsPlaying());

  useEffect(() => {
    const unsubscribe = luxuryAudio.subscribe((playing) => {
      setIsPlayingAudio(playing);
    });
    return () => unsubscribe();
  }, []);

  const toggleAmbianceAudio = () => {
    luxuryAudio.toggle();
  };

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks: { page: Page; label: string; frenchLabel: string; icon: any }[] = [
    { page: 'home', label: 'صفحه اصلی', frenchLabel: 'Accueil', icon: Home },
    { page: 'menu', label: 'منوی اختصاصی', frenchLabel: 'La Carte', icon: UtensilsCrossed },
    { page: 'about', label: 'داستان و سرآشپز', frenchLabel: 'L’Histoire', icon: Crown },
    { page: 'gallery', label: 'گالری عمارت', frenchLabel: 'Galerie', icon: Compass },
    { page: 'reservation', label: 'رزرو اختصاصی', frenchLabel: 'Réservation', icon: Calendar },
    { page: 'contact', label: 'تماس و موقعیت', frenchLabel: 'Contact', icon: PhoneCall },
  ];

  return (
    <>
      {/* =========================================================================
          TOP DESKTOP & MOBILE HEADER WITH FROSTED GLASS
      ========================================================================= */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#09080c]/90 backdrop-blur-2xl border-b border-white/10 shadow-[0_12px_40px_rgba(0,0,0,0.85)] py-2.5 sm:py-3'
            : 'bg-gradient-to-b from-[#09080c]/90 to-transparent backdrop-blur-md border-b border-white/5 py-3.5 sm:py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
          
          {/* Right side in RTL: Brand Logo with uploaded transparent graphic & Typography */}
          <div
            id="brand-logo-btn"
            onClick={() => {
              setCurrentPage('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-3 cursor-pointer group select-none flex-shrink-0"
          >
            {/* Transparent Golden Vector Logo (No background box) */}
            <div className="relative flex items-center justify-center">
              <MolaqatLogo size={44} variant="gold" className="filter drop-shadow-[0_0_12px_rgba(197,160,89,0.5)]" />
            </div>
            
            <div className="flex flex-col text-right">
              <div className="flex items-center gap-1.5">
                <span className="text-lg sm:text-xl font-black tracking-tight text-white group-hover:text-amber-400 transition-colors">
                  {RESTAURANT_INFO.brandNamePersian}
                </span>
                <span className="text-[10px] uppercase tracking-widest text-[#c5a059] font-bold border-r border-white/20 pr-1.5 mr-0.5 font-latin">
                  MOLAQAṮ
                </span>
              </div>
              <span className="text-[10px] text-stone-400 tracking-wider hidden sm:block">
                رستوران فرانسوی فاخر • مشهد، سجاد
              </span>
            </div>
          </div>

          {/* Center (RTL order): Navigation links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2 flex-shrink-0">
            {navLinks.map((item) => {
              const isActive = currentPage === item.page;
              return (
                <button
                  key={item.page}
                  id={`nav-link-${item.page}`}
                  onClick={() => {
                    setCurrentPage(item.page);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className={`relative px-3.5 py-1.5 rounded-full text-xs font-bold transition-all duration-300 group whitespace-nowrap ${
                    isActive
                      ? 'text-black bg-gradient-to-r from-amber-400 to-amber-500 font-extrabold shadow-[0_0_20px_rgba(245,158,11,0.4)]'
                      : 'text-stone-300 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <span className="relative z-10">{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Left side in RTL: Audio + Cart + Reserve CTA */}
          <div className="flex items-center gap-2 sm:gap-2.5 flex-shrink-0">
            
            {/* Ambient Classical Piano Player */}
            <button
              id="ambient-music-btn"
              onClick={toggleAmbianceAudio}
              className={`px-3 py-1.5 rounded-full border transition-all duration-300 flex items-center gap-1.5 whitespace-nowrap ${
                isPlayingAudio
                  ? 'bg-amber-500/20 border-amber-500/60 text-amber-200 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                  : 'bg-white/[0.06] border-white/10 text-stone-300 hover:text-white hover:border-white/30'
              }`}
              title={isPlayingAudio ? 'توقف موسیقی پیانوی عمارت' : 'پخش موسیقی زنده پیانوی فرانسوی'}
            >
              {isPlayingAudio ? (
                <>
                  <div className="flex items-center gap-0.5 h-3">
                    <span className="w-0.5 h-3 bg-amber-400 animate-pulse"></span>
                    <span className="w-0.5 h-2 bg-amber-300 animate-ping"></span>
                    <span className="w-0.5 h-3.5 bg-amber-400 animate-pulse"></span>
                  </div>
                  <span className="text-[11px] font-bold hidden xl:inline">پیانوی زنده</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-[#c5a059]" />
                  <span className="text-[11px] font-medium hidden xl:inline">موسیقی عمارت</span>
                </>
              )}
            </button>

            {/* Favorites Button with Badge */}
            <button
              id="concierge-fav-btn"
              onClick={() => {
                setCurrentPage('menu');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className={`relative px-3 py-1.5 rounded-full border transition-all duration-300 flex items-center gap-1.5 whitespace-nowrap ${
                favorites.length > 0
                  ? 'bg-rose-500/15 border-rose-500/40 text-rose-300 hover:border-rose-400 shadow-[0_0_15px_rgba(244,63,94,0.2)]'
                  : 'bg-white/[0.06] border-white/10 text-stone-300 hover:border-white/30'
              }`}
              title="علاقه‌مندی‌های VIP"
            >
              <Heart className={`w-3.5 h-3.5 ${favorites.length > 0 ? 'fill-rose-500 text-rose-400' : 'text-stone-300'}`} />
              <span className="text-xs font-bold hidden md:inline">علاقه‌مندی‌ها</span>
              {favorites.length > 0 && (
                <span className="w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-black flex items-center justify-center shadow-sm">
                  {favorites.length}
                </span>
              )}
            </button>

            {/* Cart Button with vibrant Glass Badge */}
            <button
              id="concierge-cart-btn"
              onClick={openCart}
              className={`relative px-3.5 py-1.5 rounded-full border transition-all duration-300 flex items-center gap-1.5 whitespace-nowrap ${
                cartCount > 0
                  ? 'bg-amber-500/20 border-amber-500/60 text-white shadow-[0_0_20px_rgba(245,158,11,0.3)]'
                  : 'bg-white/[0.06] border-white/10 text-[#d8d2c4] hover:border-white/30'
              }`}
              title="سبد سفارش"
            >
              <ShoppingBag className={`w-4 h-4 ${cartCount > 0 ? 'text-amber-400' : 'text-[#c5a059]'}`} />
              <span className="text-xs font-bold hidden sm:inline">سبد سفارش</span>
              {cartCount > 0 && (
                <span className="w-5 h-5 rounded-full bg-gradient-to-r from-amber-500 to-orange-600 text-black text-[11px] font-black flex items-center justify-center shadow-md animate-pulse">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Quick Reservation Button */}
            <button
              onClick={() => {
                setCurrentPage('reservation');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hidden sm:flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 hover:from-amber-400 hover:to-orange-600 text-black text-xs font-black shadow-[0_0_20px_rgba(245,158,11,0.35)] hover:scale-105 transition-all whitespace-nowrap"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>رزرو میز</span>
            </button>

            {/* Mobile Menu Hamburger Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-full bg-white/10 border border-white/15 text-[#ccc] hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <MenuIcon className="w-5 h-5" />}
            </button>

          </div>

        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden mt-3 px-4 pt-3 pb-5 bg-[#0e0c12]/98 border-b border-white/10 backdrop-blur-3xl shadow-2xl animate-in slide-in-from-top-4 duration-300">
            <div className="flex flex-col gap-2">
              {navLinks.map((item) => {
                const isActive = currentPage === item.page;
                const Icon = item.icon;
                return (
                  <button
                    key={item.page}
                    onClick={() => {
                      setCurrentPage(item.page);
                      setMobileMenuOpen(false);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={`flex items-center justify-between px-4 py-3 rounded-2xl text-xs font-bold transition-all ${
                      isActive
                        ? 'bg-amber-500 text-black font-extrabold shadow-lg'
                        : 'bg-white/[0.04] text-stone-300 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </div>
                    <span className="text-[10px] font-latin opacity-70">{item.frenchLabel}</span>
                  </button>
                );
              })}

              <div className="pt-2 border-t border-white/10 flex items-center justify-between">
                <button
                  onClick={() => {
                    setCurrentPage('reservation');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-black font-black text-xs flex items-center justify-center gap-2 shadow-lg"
                >
                  <Calendar className="w-4 h-4" />
                  <span>رزرو اختصاصی میز در عمارت</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
