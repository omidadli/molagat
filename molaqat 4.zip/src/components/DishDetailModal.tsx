import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Dish } from '../types';
import { useFavorites } from '../context/FavoritesContext';
import { 
  X, 
  Sparkles, 
  Plus, 
  Minus, 
  Check, 
  Clock, 
  Flame, 
  Wine, 
  Heart, 
  Star, 
  Layers, 
  ChevronLeft, 
  ChevronRight, 
  ShieldCheck, 
  Award,
  RotateCw
} from 'lucide-react';

interface DishDetailModalProps {
  dish: Dish | null;
  onClose: () => void;
  onAddToCart: (dish: Dish, quantity: number, instructions?: string) => void;
}

export const DishDetailModal: React.FC<DishDetailModalProps> = ({
  dish,
  onClose,
  onAddToCart,
}) => {
  const { isFavorite, toggleFavorite, showToast } = useFavorites();
  const [selectedAngleIdx, setSelectedAngleIdx] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedPortion, setSelectedPortion] = useState<'regular' | 'large' | 'xlarge'>('regular');
  const [addTruffle, setAddTruffle] = useState(false);
  const [addGoldLeaf, setAddGoldLeaf] = useState(false);
  const [addCaviar, setAddCaviar] = useState(false);
  const [addSauce, setAddSauce] = useState(true);
  const [specialInstructions, setSpecialInstructions] = useState('');
  const [isAdded, setIsAdded] = useState(false);
  const [heartPopped, setHeartPopped] = useState(false);

  if (!dish) return null;

  const isFav = isFavorite(dish.id);

  const gallery = dish.galleryImages && dish.galleryImages.length > 0 
    ? dish.galleryImages 
    : [{ url: dish.image, title: 'نمای اصلی چیدمان', perspective: 'زاویه دید مهمان سر میز با کلوش طلایی' }];

  const currentImage = gallery[selectedAngleIdx] || gallery[0];
  const angleCount = gallery.length;

  // Portion multiplier
  const portionMultiplier = selectedPortion === 'large' ? 1.4 : selectedPortion === 'xlarge' ? 1.8 : 1.0;
  const truffleFee = addTruffle ? 450000 : 0;
  const goldFee = addGoldLeaf ? 350000 : 0;
  const caviarFee = addCaviar ? 850000 : 0;
  const sauceFee = addSauce ? 120000 : 0;

  const basePrice = dish.priceTomans * portionMultiplier;
  const unitPrice = basePrice + truffleFee + goldFee + caviarFee + sauceFee;
  const totalPrice = unitPrice * quantity;
  const formattedTotalPrice = new Intl.NumberFormat('fa-IR').format(totalPrice) + ' تومان';

  const handleToggleFav = () => {
    setHeartPopped(true);
    toggleFavorite(dish);
    setTimeout(() => setHeartPopped(false), 600);
  };

  const handlePrevAngle = () => {
    setSelectedAngleIdx((prev) => (prev === 0 ? angleCount - 1 : prev - 1));
  };

  const handleNextAngle = () => {
    setSelectedAngleIdx((prev) => (prev === angleCount - 1 ? 0 : prev + 1));
  };

  const handleAdd = () => {
    const customNotes = [
      selectedPortion === 'large' ? 'پرس دو نفره رویال' : selectedPortion === 'xlarge' ? 'پکیج امپریال VIP' : 'پرس استاندارد',
      addTruffle ? 'ترافل سیاه پرودانس' : null,
      addGoldLeaf ? 'ورق طلای ۲۴ عیار' : null,
      addCaviar ? 'خاویار بلوگای خزر' : null,
      addSauce ? 'سس دست‌ساز سرآشپز' : null,
      specialInstructions.trim() ? specialInstructions.trim() : null,
    ].filter(Boolean).join(' • ');

    onAddToCart(dish, quantity, customNotes);
    showToast(
      'به سبد تشریفات افزوده شد',
      `${quantity} پرس «${dish.persianName}» با شخصی‌سازی به سبد اضافه شد.`,
      'cart'
    );
    setIsAdded(true);
    setTimeout(() => {
      setIsAdded(false);
      onClose();
    }, 900);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
        {/* Dark frosted Glass Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed inset-0 bg-black/85 backdrop-blur-2xl"
          onClick={onClose}
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.93, y: 25 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 320 }}
          className="relative w-full max-w-2xl bg-[#141219]/95 border border-white/15 rounded-[32px] sm:rounded-[40px] p-5 sm:p-7 shadow-[0_30px_90px_rgba(0,0,0,0.95)] backdrop-blur-3xl z-10 text-right overflow-hidden max-h-[92vh] flex flex-col justify-between"
        >
          {/* Ambient Warm Orange/Gold Glowing Aura Behind the food */}
          <div className="absolute top-10 right-1/2 translate-x-1/2 w-80 h-80 bg-amber-600/20 rounded-full blur-3xl pointer-events-none" />

          {/* Top Bar: Back/Close & Favorite Heart */}
          <div className="flex items-center justify-between pb-3 relative z-10">
            <button
              onClick={onClose}
              className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white border border-white/10 transition-all flex items-center justify-center"
              title="بستن"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/30 text-amber-300 text-[11px] font-bold">
                {dish.isSignature ? 'امضای سرآشپز پیر لوران' : 'هنر آشپزی فرانسوی'}
              </span>
              <motion.button
                onClick={handleToggleFav}
                whileTap={{ scale: 0.8 }}
                animate={heartPopped ? { scale: [1, 1.4, 0.9, 1] } : { scale: 1 }}
                className={`p-2.5 rounded-full border transition-all ${
                  isFav
                    ? 'bg-rose-500/25 text-rose-400 border-rose-500/60 shadow-lg shadow-rose-500/30'
                    : 'bg-white/10 text-white/70 hover:text-white border-white/10'
                }`}
                title={isFav ? 'حذف از علاقه‌مندی‌ها' : 'افزودن به علاقه‌مندی‌ها'}
              >
                <Heart className={`w-4 h-4 ${isFav ? 'fill-rose-500 text-rose-400' : ''}`} />
              </motion.button>
            </div>
          </div>

          {/* Scrollable Content Body */}
          <div className="overflow-y-auto pr-1 pl-1 space-y-6 relative z-10 no-scrollbar py-2">
            
            {/* Center Visual Platter Showcase with Animated Rotating Rings */}
            <div className="relative flex flex-col items-center justify-center my-2">
              
              {/* Outer Rotating Ring in Modal */}
              <div 
                className="absolute w-60 h-60 sm:w-72 sm:h-72 rounded-full border border-dashed border-amber-400/35 animate-[spin_24s_linear_infinite] pointer-events-none"
              >
                <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full bg-amber-400 shadow-[0_0_10px_#f59e0b]" />
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-amber-400/70" />
              </div>

              {/* Inner Counter-Rotating Ring */}
              <div className="absolute w-56 h-56 sm:w-68 sm:h-68 rounded-full border border-dotted border-white/20 animate-[spin_36s_linear_infinite_reverse] pointer-events-none" />

              {/* Food Image Container */}
              <div className="relative z-10 w-52 h-52 sm:w-64 sm:h-64 rounded-full p-2 bg-gradient-to-b from-white/15 via-[#1a1722] to-black/90 border-2 border-amber-500/40 shadow-[0_20px_50px_rgba(0,0,0,0.95)] flex items-center justify-center overflow-hidden">
                <AnimatePresence mode="wait">
                  <motion.img
                    key={currentImage.url}
                    src={currentImage.url}
                    alt={dish.frenchName}
                    referrerPolicy="no-referrer"
                    initial={{ opacity: 0.3, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0.2, scale: 1.05 }}
                    transition={{ duration: 0.3 }}
                    className="w-full h-full object-cover rounded-full select-none"
                  />
                </AnimatePresence>

                {/* Left / Right Carousel Controls */}
                {angleCount > 1 && (
                  <>
                    <button
                      onClick={handlePrevAngle}
                      aria-label="زاویه قبلی"
                      className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/75 hover:bg-amber-500 hover:text-black text-white border border-white/20 hover:border-amber-400 transition-all flex items-center justify-center z-20 backdrop-blur-md shadow-lg"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <button
                      onClick={handleNextAngle}
                      aria-label="زاویه بعدی"
                      className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/75 hover:bg-amber-500 hover:text-black text-white border border-white/20 hover:border-amber-400 transition-all flex items-center justify-center z-20 backdrop-blur-md shadow-lg"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </>
                )}
              </div>

              {/* Angle Selector Pills & Perspective Note */}
              {angleCount > 1 && (
                <div className="mt-4 flex flex-col items-center gap-2">
                  <div className="flex items-center gap-2 bg-black/60 p-1.5 rounded-2xl border border-white/10 backdrop-blur-md">
                    {gallery.map((img, idx) => (
                      <button
                        key={idx}
                        onClick={() => setSelectedAngleIdx(idx)}
                        className={`px-3 py-1 rounded-xl text-[11px] font-semibold transition-all ${
                          selectedAngleIdx === idx
                            ? 'bg-amber-500 text-black font-extrabold shadow-md'
                            : 'text-stone-400 hover:text-white'
                        }`}
                      >
                        {img.title || `زاویه ${idx + 1}`}
                      </button>
                    ))}
                  </div>
                  {currentImage.perspective && (
                    <span className="text-[11px] text-amber-300/80 italic">
                      ✦ {currentImage.perspective}
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Dish Header Info (Title, Rating, Price) */}
            <div className="space-y-2 border-b border-white/10 pb-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-latin font-bold text-amber-400 block">{dish.frenchName}</span>
                  <h2 className="text-xl sm:text-2xl font-black text-white">{dish.persianName}</h2>
                </div>
                <div className="text-left font-mono">
                  <span className="text-lg sm:text-xl font-black text-amber-300 block">
                    {new Intl.NumberFormat('fa-IR').format(dish.priceTomans)} تومان
                  </span>
                  <span className="text-[10px] text-stone-400">قیمت پایه</span>
                </div>
              </div>

              {/* Star Rating & Meta */}
              <div className="flex items-center gap-4 text-xs text-stone-300 pt-1">
                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 font-bold">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span className="font-mono">۴.۹</span>
                  <span className="text-[10px] text-stone-400">(۱۲۸ نظر)</span>
                </div>

                <div className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>{dish.prepTimeMinutes} دقیقه زمان پخت</span>
                </div>

                {dish.calories && (
                  <div className="flex items-center gap-1">
                    <Flame className="w-3.5 h-3.5 text-orange-400" />
                    <span>{dish.calories} کالری</span>
                  </div>
                )}
              </div>

              <p className="text-xs sm:text-sm text-stone-300 leading-relaxed pt-2">
                {dish.description}
              </p>
            </div>

            {/* CUSTOMIZE SECTION */}
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>شخصی‌سازی بشقاب (Customize)</span>
                </h3>
                <span className="text-[11px] text-stone-400 font-latin">Haute Customization</span>
              </div>

              {/* Portion / Size Selector (Regular, Large, X Large) */}
              <div className="space-y-2">
                <label className="text-xs text-stone-400 font-medium">سایز و حجم پرس:</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'regular', label: 'استاندارد (۱ نفره)', sub: 'Regular' },
                    { id: 'large', label: 'رویال (۲ نفره)', sub: 'Large (+۴۰٪)' },
                    { id: 'xlarge', label: 'امپریال VIP', sub: 'X Large (+۸۰٪)' },
                  ].map((portion) => (
                    <button
                      key={portion.id}
                      type="button"
                      onClick={() => setSelectedPortion(portion.id as any)}
                      className={`p-2.5 rounded-2xl border text-center transition-all ${
                        selectedPortion === portion.id
                          ? 'bg-gradient-to-r from-amber-500 to-orange-600 border-amber-400 text-black font-extrabold shadow-lg shadow-amber-500/20'
                          : 'bg-white/[0.04] border-white/10 hover:bg-white/[0.08] text-stone-300'
                      }`}
                    >
                      <div className="text-xs font-bold">{portion.label}</div>
                      <div className={`text-[10px] ${selectedPortion === portion.id ? 'text-black/80' : 'text-stone-500'}`}>
                        {portion.sub}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Toggle Switches for Premium Add-ons */}
              <div className="space-y-2.5">
                <label className="text-xs text-stone-400 font-medium">افزودنی‌های اشرافی سرآشپز:</label>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {/* Truffle */}
                  <label className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.04] border border-white/10 hover:border-amber-500/40 cursor-pointer transition-all">
                    <div className="flex items-center gap-2.5">
                      <input
                        type="checkbox"
                        checked={addTruffle}
                        onChange={(e) => setAddTruffle(e.target.checked)}
                        className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                      />
                      <span className="text-xs font-semibold text-white">ترافل سیاه پرودانس</span>
                    </div>
                    <span className="text-xs font-mono text-amber-300">+۴۵۰,۰۰۰ تومان</span>
                  </label>

                  {/* Gold Leaf */}
                  <label className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.04] border border-white/10 hover:border-amber-500/40 cursor-pointer transition-all">
                    <div className="flex items-center gap-2.5">
                      <input
                        type="checkbox"
                        checked={addGoldLeaf}
                        onChange={(e) => setAddGoldLeaf(e.target.checked)}
                        className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                      />
                      <span className="text-xs font-semibold text-white">ورق طلای ۲۴ عیار</span>
                    </div>
                    <span className="text-xs font-mono text-amber-300">+۳۵۰,۰۰۰ تومان</span>
                  </label>

                  {/* Beluga Caviar */}
                  <label className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.04] border border-white/10 hover:border-amber-500/40 cursor-pointer transition-all">
                    <div className="flex items-center gap-2.5">
                      <input
                        type="checkbox"
                        checked={addCaviar}
                        onChange={(e) => setAddCaviar(e.target.checked)}
                        className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                      />
                      <span className="text-xs font-semibold text-white">خاویار بلوگای خزر (۱۰ گرم)</span>
                    </div>
                    <span className="text-xs font-mono text-amber-300">+۸۵۰,۰۰۰ تومان</span>
                  </label>

                  {/* Extra Chef Secret Sauce */}
                  <label className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.04] border border-white/10 hover:border-amber-500/40 cursor-pointer transition-all">
                    <div className="flex items-center gap-2.5">
                      <input
                        type="checkbox"
                        checked={addSauce}
                        onChange={(e) => setAddSauce(e.target.checked)}
                        className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                      />
                      <span className="text-xs font-semibold text-white">سس اضافه دست‌ساز</span>
                    </div>
                    <span className="text-xs font-mono text-amber-300">+۱۲۰,۰۰۰ تومان</span>
                  </label>
                </div>
              </div>

              {/* Special Instructions Input */}
              <div className="space-y-1.5">
                <label className="text-xs text-stone-400 font-medium">دستورات پخت یا آلرژی غذایی:</label>
                <input
                  type="text"
                  value={specialInstructions}
                  onChange={(e) => setSpecialInstructions(e.target.value)}
                  placeholder="مثال: پخت مدیوم-ول، بدون سیر، همراه با گل‌آرایی میز..."
                  className="w-full px-4 py-2.5 rounded-2xl bg-black/40 border border-white/10 text-xs text-white placeholder-stone-500 focus:outline-none focus:border-amber-400 transition-colors"
                />
              </div>

              {/* Ingredients & Sommelier Pairing */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 text-xs border-t border-white/10">
                <div className="space-y-2">
                  <h4 className="font-bold text-amber-400 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                    <span>مواد اولیه ارگانیک</span>
                  </h4>
                  <ul className="space-y-1 text-stone-300 list-disc list-inside text-[11px]">
                    {dish.ingredients.map((ing, i) => (
                      <li key={i}>{ing}</li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-2">
                  <h4 className="font-bold text-amber-400 flex items-center gap-1.5">
                    <Wine className="w-3.5 h-3.5 text-amber-400" />
                    <span>پیشنهاد نوشیدنی اکسیر</span>
                  </h4>
                  <p className="text-stone-300 text-[11px] leading-relaxed">
                    {dish.sommelierPairing || 'اکسیر ارگانیک انگور سیاه و انار وحشی با عصاره اسطوخودوس پرودانس'}
                  </p>
                </div>
              </div>

            </div>

          </div>

          {/* Bottom Sticky Action Bar */}
          <div className="pt-4 border-t border-white/15 flex items-center justify-between gap-4 relative z-10 bg-[#141219]/90 backdrop-blur-md">
            
            {/* Stepper */}
            <div className="flex items-center gap-2 bg-white/[0.06] border border-white/10 rounded-2xl p-1.5">
              <button
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="p-2 rounded-xl hover:bg-white/10 text-white transition-colors"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <span className="w-8 text-center text-sm font-bold font-mono text-white">
                {quantity}
              </span>
              <button
                onClick={() => setQuantity((q) => q + 1)}
                className="p-2 rounded-xl hover:bg-white/10 text-white transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Total Price & Add to Cart Button */}
            <div className="flex items-center gap-3 flex-1">
              <div className="text-right hidden sm:block">
                <span className="text-[10px] text-stone-400 block">مبلغ کل قابل پرداخت:</span>
                <span className="text-sm sm:text-base font-black text-amber-300 font-mono">
                  {formattedTotalPrice}
                </span>
              </div>

              <button
                onClick={handleAdd}
                className="flex-1 py-3 px-5 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-black text-xs sm:text-sm shadow-[0_4px_25px_rgba(245,158,11,0.4)] flex items-center justify-center gap-2 transition-all"
              >
                {isAdded ? (
                  <>
                    <Check className="w-4 h-4 text-black" />
                    <span>با موفقیت افزوده شد</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-black" />
                    <span>افزودن به سبد تشریفات ({formattedTotalPrice})</span>
                  </>
                )}
              </button>
            </div>

          </div>

        </motion.div>
      </div>
    </AnimatePresence>
  );
};
