import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useFavorites } from '../context/FavoritesContext';
import { Heart, Sparkles, ShoppingBag, X, Check } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useFavorites();

  return (
    <div className="fixed top-20 sm:top-24 left-1/2 -translate-x-1/2 z-[100] flex flex-col items-center gap-2.5 pointer-events-none w-full max-w-md px-4">
      <AnimatePresence>
        {toasts.map((toast) => (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -15, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 400, damping: 30 }}
            className="pointer-events-auto w-full rounded-2xl bg-[#141219]/95 border border-amber-500/40 p-3.5 shadow-[0_15px_45px_rgba(0,0,0,0.85)] backdrop-blur-2xl text-right flex items-center justify-between gap-3 text-white"
          >
            <div className="flex items-center gap-3 flex-1 min-w-0">
              <div className="p-2 rounded-xl bg-gradient-to-br from-amber-500/25 to-orange-500/25 border border-amber-400/40 text-amber-300 flex-shrink-0">
                {toast.type === 'favorite' ? (
                  <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
                ) : toast.type === 'cart' ? (
                  <ShoppingBag className="w-4 h-4 text-amber-400" />
                ) : (
                  <Sparkles className="w-4 h-4 text-amber-400" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-xs font-bold text-white truncate">{toast.title}</h4>
                {toast.description && (
                  <p className="text-[11px] text-stone-300 truncate mt-0.5">{toast.description}</p>
                )}
              </div>
            </div>

            <button
              onClick={() => removeToast(toast.id)}
              className="p-1 rounded-lg hover:bg-white/10 text-stone-400 hover:text-white transition-colors"
              title="بستن"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};
