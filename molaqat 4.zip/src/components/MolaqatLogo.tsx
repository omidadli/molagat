import React from 'react';

interface MolaqatLogoProps {
  className?: string;
  size?: number | string;
  variant?: 'gold' | 'white' | 'dark' | 'amber';
  showText?: boolean;
  textClassName?: string;
}

export const MolaqatLogo: React.FC<MolaqatLogoProps> = ({
  className = '',
  size = 48,
  variant = 'gold',
  showText = false,
  textClassName = '',
}) => {
  const strokeColor =
    variant === 'gold'
      ? '#c5a059'
      : variant === 'amber'
      ? '#e5a93c'
      : variant === 'white'
      ? '#ffffff'
      : '#1a1815';

  const secondaryColor =
    variant === 'gold'
      ? '#e8cb7a'
      : variant === 'amber'
      ? '#ffd700'
      : variant === 'white'
      ? '#f3f3f3'
      : '#332d24';

  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      {/* Precision Vector Emblem (Faithful to the user's provided logo artwork with zero background) */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 200 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0 transition-transform duration-300 group-hover:scale-105"
      >
        <defs>
          <linearGradient id={`goldGrad-${variant}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={secondaryColor} />
            <stop offset="50%" stopColor={strokeColor} />
            <stop offset="100%" stopColor={secondaryColor} />
          </linearGradient>
          <filter id="goldGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="1.5" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        <g stroke={`url(#goldGrad-${variant})`} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" fill="none">
          
          {/* Top Trefoil / Fleur-de-lis Finial Crown */}
          <path
            d="M100 48 C99 44 98 40 100 36 C102 40 101 44 100 48 Z"
            fill={strokeColor}
            strokeWidth="1.5"
          />
          <path
            d="M98 44 C94 42 92 41 94 45 C96 46 98 46 100 47"
            fill={strokeColor}
            strokeWidth="1.5"
          />
          <path
            d="M102 44 C106 42 108 41 106 45 C104 46 102 46 100 47"
            fill={strokeColor}
            strokeWidth="1.5"
          />

          {/* Architectural Arch Window */}
          <path
            d="M74 120 V88 C74 65 88 50 100 48 C112 50 126 65 126 88 V120"
            strokeWidth="3.2"
          />

          {/* Central Leaf / Flame Sprout inside the Arch */}
          <path
            d="M100 119 C88 105 87 90 98 72 C103 86 112 96 100 119 Z"
            strokeWidth="2.8"
          />
          {/* Center Vein of Leaf */}
          <path
            d="M100 118 C100 104 98 94 99 82"
            strokeWidth="2"
            strokeLinecap="round"
          />

          {/* Left Outstretched Hand & Arm Reaching toward center */}
          <path
            d="M42 144 C62 144 76 138 82 125 C88 123 94 120 100 119 C92 122 84 125 79 123 C72 127 68 132 64 140 C58 152 50 156 46 160"
            strokeWidth="3.2"
          />
          {/* Left Thumb & Finger Detail */}
          <path
            d="M86 118 C92 119 96 119 99 119"
            strokeWidth="2.4"
          />
          <path
            d="M80 123 C85 125 90 125 94 124"
            strokeWidth="2.2"
          />

          {/* Right Outstretched Hand & Arm Reaching toward center */}
          <path
            d="M158 144 C138 144 124 138 118 125 C112 123 106 120 100 119 C108 122 116 125 121 123 C128 127 132 132 136 140 C142 152 150 156 154 160"
            strokeWidth="3.2"
          />
          {/* Right Thumb & Finger Detail */}
          <path
            d="M114 118 C108 119 104 119 101 119"
            strokeWidth="2.4"
          />
          <path
            d="M120 123 C115 125 110 125 106 124"
            strokeWidth="2.2"
          />

          {/* Grounding Base Curved Baseline Horizon */}
          <path
            d="M42 158 C75 158 92 165 100 165 C108 165 125 158 158 158"
            strokeWidth="3"
            strokeLinecap="round"
          />

        </g>
      </svg>

      {/* Optional Typography Text Pair */}
      {showText && (
        <div className={`flex flex-col text-right ${textClassName}`}>
          <div className="flex items-center gap-1.5">
            <span className={`text-lg sm:text-xl font-black tracking-tight ${variant === 'dark' ? 'text-[#1a1713]' : 'text-white'}`}>
              عمارت ملاقات
            </span>
            <span className="text-[10px] uppercase tracking-widest text-[#c5a059] font-bold border-r border-[#c5a059]/30 pr-1.5 mr-0.5">
              MOLAQAṮ
            </span>
          </div>
          <span className={`text-[10px] tracking-wider ${variant === 'dark' ? 'text-[#665e52]' : 'text-[#a8a192]'}`}>
            رستوران فرانسوی فاخر • مشهد، سجاد
          </span>
        </div>
      )}
    </div>
  );
};
