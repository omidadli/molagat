import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Page } from '../types';
import { RESTAURANT_INFO } from '../data/restaurantData';
import { luxuryAudio } from '../utils/audioSynth';
import { useFavorites } from '../context/FavoritesContext';
import {
  Home,
  UtensilsCrossed,
  Calendar,
  ShoppingBag,
  Heart,
  PhoneCall,
  Volume2,
  VolumeX,
  ChevronUp,
  Sparkles,
  Crown
} from 'lucide-react';

interface QuickAccessNavProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  cartCount: number;
  openCart: () => void;
}

export const QuickAccessNav: React.FC<QuickAccessNavProps> = ({
  currentPage,
  setCurrentPage,
  cartCount,
  openCart,
}) => {
  const { favorites } = useFavorites();
  const [isPlayingAudio, setIsPlayingAudio] = useState(luxuryAudio.getIsPlaying());
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    const unsubscribe = luxuryAudio.subscribe((playing) => {
      setIsPlayingAudio(playing);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    const lenis = (window as any).__molaqat_lenis;
    if (lenis) {
      lenis.scrollTo(0, { duration: 1.2 });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const toggleAudio = () => {
    luxuryAudio.toggle();
  };

  const navItems = [
    {
      page: 'home' as Page,
      label: 'خانه',
      sublabel: 'Accueil',
      icon: Home,
      id: 'dock-home-btn',
    },
    {
      page: 'menu' as Page,
      label: 'منو',
      sublabel: 'La Carte',
      icon: UtensilsCrossed,
      id: 'dock-menu-btn',
    },
    {
      page: 'reservation' as Page,
      label: 'رزرو میز',
      sublabel: 'Réservation',
      icon: Calendar,
      highlight: true,
      id: 'dock-reserve-btn',
    },
    {
      page: 'order' as Page,
      label: 'سفارش',
      sublabel: 'Commande',
      icon: ShoppingBag,
      badge: cartCount > 0 ? cartCount : undefined,
      onClick: openCart,
      id: 'dock-order-btn',
    },
  ];

  return (
    <div className="fixed bottom-3 sm:bottom-5 left-1/2 -translate-x-1/2 z-40 max-w-[96vw] sm:max-w-fit pointer-events-none select-none">
      <motion.div
        initial={{ y: 50, opacity: 0, scale: 0.95 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="pointer-events-auto flex items-center gap-1 sm:gap-2 p-1.5 sm:p-2 rounded-full bg-[#0a090e]/92 backdrop-blur-2xl border border-[#c5a059]/35 shadow-[0_16px_45px_rgba(0,0,0,0.9),0_0_25px_rgba(197,160,89,0.15)] ring-1 ring-white/10"
      >
        {/* Main Navigation Items */}
        <div className="flex items-center gap-1 sm:gap-1.5">
          {navItems.map((item) => {
            const isActive = currentPage === item.page;
            const Icon = item.icon;

            return (
              <button
                key={item.page}
                id={item.id}
                onClick={() => {
                  if (item.onClick) {
                    item.onClick();
                  } else {
                    setCurrentPage(item.page);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }
                }}
                className={`relative group px-3 sm:px-4 py-2 rounded-full flex items-center gap-1.5 text-xs font-bold transition-all duration-300 ${
                  item.highlight && !isActive
                    ? 'bg-gradient-to-r from-amber-500/20 via-amber-400/20 to-orange-500/20 border border-amber-400/40 text-amber-200 hover:border-amber-300 hover:scale-105'
                    : isActive
                    ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-black font-black shadow-[0_0_20px_rgba(245,158,11,0.5)] scale-105'
                    : 'text-stone-300 hover:text-white hover:bg-white/10'
                }`}
                title={item.label}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-black' : item.highlight ? 'text-amber-400' : 'text-stone-300 group-hover:text-amber-400'}`} />
                <span className="hidden sm:inline whitespace-nowrap">{item.label}</span>

                {/* Counter Badge for Cart / Orders */}
                {item.badge !== undefined && (
                  <span className={`w-4 h-4 sm:w-5 sm:h-5 rounded-full text-[10px] font-black flex items-center justify-center -mr-1 shadow-md ${
                    isActive ? 'bg-black text-amber-400' : 'bg-gradient-to-r from-amber-500 to-orange-500 text-black animate-pulse'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Vertical Divider */}
        <div className="h-6 w-[1px] bg-white/15 mx-0.5 sm:mx-1"></div>

        {/* Quick Utility Actions */}
        <div className="flex items-center gap-1 sm:gap-1.5">
          
          {/* Favorites VIP Badge Button */}
          <button
            id="dock-favorites-btn"
            onClick={() => {
              setCurrentPage('menu');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`relative p-2 sm:px-3 sm:py-2 rounded-full border transition-all duration-300 flex items-center gap-1.5 text-xs ${
              favorites.length > 0
                ? 'bg-rose-500/20 border-rose-500/50 text-rose-300 hover:border-rose-400'
                : 'bg-white/[0.04] border-white/10 text-stone-300 hover:text-white hover:border-white/25'
            }`}
            title="علاقه‌مندی‌های من"
          >
            <Heart className={`w-4 h-4 ${favorites.length > 0 ? 'fill-rose-500 text-rose-400' : 'text-stone-300'}`} />
            {favorites.length > 0 && (
              <span className="text-[10px] font-bold text-rose-300 hidden md:inline">
                {favorites.length}
              </span>
            )}
          </button>

          {/* Piano Music Toggle */}
          <button
            id="dock-audio-btn"
            onClick={toggleAudio}
            className={`relative p-2 sm:px-3 sm:py-2 rounded-full border transition-all duration-300 flex items-center gap-1.5 text-xs ${
              isPlayingAudio
                ? 'bg-amber-500/20 border-amber-500/60 text-amber-300 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                : 'bg-white/[0.04] border-white/10 text-stone-400 hover:text-white hover:border-white/25'
            }`}
            title={isPlayingAudio ? 'قطع موسیقی پیانو' : 'پخش موسیقی پیانو عمارت'}
          >
            {isPlayingAudio ? (
              <>
                <div className="flex items-center gap-0.5 h-3.5">
                  <span className="w-0.5 h-3 bg-amber-400 animate-pulse"></span>
                  <span className="w-0.5 h-2 bg-amber-300 animate-ping"></span>
                  <span className="w-0.5 h-3.5 bg-amber-400 animate-pulse"></span>
                </div>
                <span className="text-[11px] font-bold hidden lg:inline text-amber-300">موسیقی فعال</span>
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4 text-stone-400" />
                <span className="text-[11px] hidden lg:inline text-stone-400">موسیقی</span>
              </>
            )}
          </button>

          {/* Quick Concierge Call */}
          <a
            id="dock-call-btn"
            href={`tel:${RESTAURANT_INFO.phoneDisplay}`}
            className="p-2 sm:px-3 sm:py-2 rounded-full bg-white/[0.04] border border-white/10 hover:border-emerald-400/50 hover:bg-emerald-500/15 text-stone-300 hover:text-emerald-300 transition-all flex items-center gap-1.5 text-xs"
            title={`تماس مستقیم با تشریفات: ${RESTAURANT_INFO.phoneDisplay}`}
          >
            <PhoneCall className="w-4 h-4 text-emerald-400" />
            <span className="hidden xl:inline text-[11px] font-medium">تماس</span>
          </a>

          {/* Scroll to Top Trigger */}
          <AnimatePresence>
            {showScrollTop && (
              <motion.button
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                id="dock-scroll-top-btn"
                onClick={scrollToTop}
                className="p-2 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 hover:bg-amber-500 hover:text-black transition-all shadow-md"
                title="بازگشت به ابتدای صفحه"
              >
                <ChevronUp className="w-4 h-4" />
              </motion.button>
            )}
          </AnimatePresence>

        </div>
      </motion.div>
    </div>
  );
};
