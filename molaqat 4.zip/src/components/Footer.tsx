import React from 'react';
import { Page } from '../types';
import { RESTAURANT_INFO } from '../data/restaurantData';
import { MolaqatLogo } from './MolaqatLogo';
import { MapPin, Phone, Clock, ShieldCheck, Sparkles, Instagram, Car, Send } from 'lucide-react';

interface FooterProps {
  setCurrentPage: (page: Page) => void;
}

export const Footer: React.FC<FooterProps> = ({ setCurrentPage }) => {
  return (
    <footer className="relative bg-[#08070b] border-t border-white/10 pt-16 pb-12 overflow-hidden text-right">
      {/* Background ambient lighting accents */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-amber-600/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-white/10">
          
          {/* Col 1: Brand & Philosophy */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <MolaqatLogo size={48} variant="gold" className="filter drop-shadow-[0_0_15px_rgba(197,160,89,0.5)]" />
              <div>
                <h3 className="text-2xl font-black text-white">{RESTAURANT_INFO.brandNamePersian}</h3>
                <p className="text-xs font-latin text-[#c5a059] tracking-widest uppercase font-semibold">Haute Cuisine Française</p>
              </div>
            </div>

            <p className="text-sm text-stone-400 leading-relaxed">
              عمارت ملاقات، جلوه‌گاهی از شکوه و اصالت آشپزی ۳ ستاره میشلن در مشهد (بلوار سجاد). میزبانی از ضیافت‌های خصوصی، دیپلماتیک و لحظاتی به یادماندنی در فضایی مدرن و شیشه‌ای.
            </p>

            <div className="pt-2 flex items-center gap-3">
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/[0.06] border border-amber-500/30 text-xs text-amber-300">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>پذیرش با رزرو قبلی</span>
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/[0.06] border border-white/10 text-xs text-stone-300">
                <Car className="w-3.5 h-3.5 text-[#c5a059]" />
                <span>ولت اختصاصی</span>
              </span>
            </div>
          </div>

          {/* Col 2: Quick Links (RTL) */}
          <div className="space-y-4">
            <h4 className="text-base font-bold text-white border-b border-white/10 pb-2 inline-block">
              بخش‌های عمارت
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button
                  onClick={() => {
                    setCurrentPage('home');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-stone-400 hover:text-amber-300 transition-colors flex items-center gap-2 group"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500/40 group-hover:bg-amber-400 transition-colors"></span>
                  <span>صفحه اصلی و عمارت</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentPage('menu');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-stone-400 hover:text-amber-300 transition-colors flex items-center gap-2 group"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500/40 group-hover:bg-amber-400 transition-colors"></span>
                  <span>منوی فصلی و شاهکارهای سرآشپز</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentPage('about');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-stone-400 hover:text-amber-300 transition-colors flex items-center gap-2 group"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500/40 group-hover:bg-amber-400 transition-colors"></span>
                  <span>فلسفه آشپزی و سرآشپز پیر لوران</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentPage('gallery');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-stone-400 hover:text-amber-300 transition-colors flex items-center gap-2 group"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500/40 group-hover:bg-amber-400 transition-colors"></span>
                  <span>گالری تصاویر تالارها و سالن‌های VIP</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentPage('reservation');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-stone-400 hover:text-amber-300 transition-colors flex items-center gap-2 group"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500/40 group-hover:bg-amber-400 transition-colors"></span>
                  <span>رزرو آنلاین میز و تشریفات اختصاصی</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Contact & Hours */}
          <div className="space-y-4">
            <h4 className="text-base font-bold text-white border-b border-white/10 pb-2 inline-block">
              اطلاعات و تماس
            </h4>
            <div className="space-y-3 text-xs sm:text-sm text-stone-300">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-amber-400 mt-1 flex-shrink-0" />
                <span>{RESTAURANT_INFO.addressPersian}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span className="font-mono text-xs">{RESTAURANT_INFO.phoneDisplay}</span>
              </div>
              <div className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-amber-400 mt-1 flex-shrink-0" />
                <div>
                  <p>سانس شام: ۱۹:۳۰ الی ۰۰:۳۰</p>
                  <p className="text-[11px] text-stone-400">جمعه‌ها: ناهار تشریفاتی ۱۲:۳۰ الی ۱۶:۰۰</p>
                </div>
              </div>
            </div>
          </div>

          {/* Col 4: VIP Newsletter & Club */}
          <div className="space-y-4">
            <h4 className="text-base font-bold text-white border-b border-white/10 pb-2 inline-block">
              باشگاه تشریفات ملاقات
            </h4>
            <p className="text-xs text-stone-400 leading-relaxed">
              با عضویت در کلوب نخبگان ملاقات، از منوهای فصلی اختصاصی و ضیافت‌های خصوصی زودتر از دیگران مطلع شوید.
            </p>
            <div className="flex items-center rounded-2xl bg-white/[0.06] border border-white/10 p-1">
              <input
                type="text"
                placeholder="شماره تماس یا ایمیل شما..."
                className="w-full bg-transparent px-3 py-2 text-xs text-white placeholder-stone-500 focus:outline-none"
              />
              <button
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-black text-xs font-bold flex items-center gap-1 shadow-md hover:brightness-110 transition-all flex-shrink-0"
              >
                <span>عضویت</span>
                <Send className="w-3 h-3" />
              </button>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="p-2.5 rounded-full bg-white/[0.06] border border-white/10 text-stone-400 hover:text-amber-300 hover:border-amber-400/40 transition-all"
              >
                <Instagram className="w-4 h-4" />
              </a>
            </div>
          </div>

        </div>

        {/* Bottom copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500 text-center sm:text-right">
          <p>© تمامی حقوق برای عمارت ملاقات (Molaqat Haute Cuisine) محفوظ است.</p>
          <div className="flex items-center gap-4 text-[11px]">
            <span>بلوار سجاد، مشهد</span>
            <span>•</span>
            <span className="font-latin text-stone-400">Gastronomie Française d'Exception</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
