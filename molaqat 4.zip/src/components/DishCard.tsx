import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Dish } from '../types';
import { useFavorites } from '../context/FavoritesContext';
import { 
  Sparkles, 
  Plus, 
  Minus, 
  Check, 
  Clock, 
  Eye, 
  Heart, 
  Flame, 
  Star, 
  Layers,
  ChevronLeft,
  ChevronRight,
  RotateCw
} from 'lucide-react';

interface DishCardProps {
  dish: Dish;
  onSelectDish: (dish: Dish) => void;
  onAddToCart: (dish: Dish, quantity?: number) => void;
  theme?: 'dark' | 'light';
}

export const DishCard: React.FC<DishCardProps> = ({
  dish,
  onSelectDish,
  onAddToCart,
}) => {
  const { isFavorite, toggleFavorite } = useFavorites();
  const [quantity, setQuantity] = useState(1);
  const [isAdded, setIsAdded] = useState(false);
  const [activeAngleIdx, setActiveAngleIdx] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const [heartPopped, setHeartPopped] = useState(false);

  const isFav = isFavorite(dish.id);

  const gallery = dish.galleryImages && dish.galleryImages.length > 0
    ? dish.galleryImages
    : [{ url: dish.image, title: 'نمای اصلی سر میز', perspective: 'چیدمان اصلی پلاتینگ' }];

  const currentAngle = gallery[activeAngleIdx] || gallery[0];
  const angleCount = gallery.length;

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(dish, quantity);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  const handleToggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    setHeartPopped(true);
    toggleFavorite(dish);
    setTimeout(() => setHeartPopped(false), 600);
  };

  const handlePrevAngle = (e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveAngleIdx((prev) => (prev === 0 ? angleCount - 1 : prev - 1));
  };

  const handleNextAngle = (e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveAngleIdx((prev) => (prev === angleCount - 1 ? 0 : prev + 1));
  };

  const handleSelectAngle = (e: React.MouseEvent, idx: number) => {
    e.stopPropagation();
    setActiveAngleIdx(idx);
  };

  const handleDecrement = (e: React.MouseEvent) => {
    e.stopPropagation();
    setQuantity((prev) => Math.max(1, prev - 1));
  };

  const handleIncrement = (e: React.MouseEvent) => {
    e.stopPropagation();
    setQuantity((prev) => prev + 1);
  };

  return (
    <motion.div
      id={`dish-card-${dish.id}`}
      onClick={() => onSelectDish(dish)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ y: -6, scale: 1.015 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      className="group relative rounded-[32px] p-5 flex flex-col justify-between cursor-pointer overflow-hidden text-right transition-all duration-300 bg-gradient-to-b from-white/[0.09] via-white/[0.04] to-black/65 border border-white/15 hover:border-amber-400/60 backdrop-blur-2xl shadow-[0_20px_50px_rgba(0,0,0,0.65)] hover:shadow-[0_25px_60px_rgba(245,158,11,0.28)] select-none"
    >
      {/* Ambient Warm Golden/Orange Glow Backdrop (Reference Mockup Lighting) */}
      <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full bg-amber-500/15 group-hover:bg-amber-500/30 blur-3xl pointer-events-none transition-all duration-500" />
      <div className="absolute -bottom-10 -left-10 w-40 h-40 rounded-full bg-orange-600/10 group-hover:bg-orange-500/20 blur-3xl pointer-events-none transition-all duration-500" />

      {/* Floating Add Confirmation Banner */}
      <AnimatePresence>
        {isAdded && (
          <motion.div
            initial={{ opacity: 0, y: 12, scale: 0.85 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.9 }}
            className="absolute top-4 inset-x-4 z-40 py-2.5 px-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 border border-emerald-400/50 backdrop-blur-2xl text-center text-xs font-bold text-white flex items-center justify-center gap-2 shadow-2xl"
          >
            <Check className="w-4 h-4 text-emerald-200" />
            <span>{quantity} پرس به سبد افزوده شد</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Bar: Badges, Star Rating & Heart Favorite */}
      <div className="flex items-center justify-between mb-3 relative z-10">
        <div className="flex items-center gap-1.5 flex-wrap">
          {dish.isSignature ? (
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/25 to-orange-500/25 border border-amber-400/40 text-amber-300 text-[10px] font-extrabold shadow-sm backdrop-blur-md">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>امضای سرآشپز</span>
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-semibold bg-white/[0.06] text-stone-200 border border-white/10 backdrop-blur-md">
              <span>گاسترونومی فرانسه</span>
            </span>
          )}

          {/* Star Rating Badge */}
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-black/40 text-amber-300 border border-amber-500/30 backdrop-blur-md">
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
            <span className="font-mono">۴.۹</span>
          </span>
        </div>

        {/* Favorite & Angle Count Badges */}
        <div className="flex items-center gap-1.5">
          {angleCount > 1 && (
            <span 
              onClick={(e) => {
                e.stopPropagation();
                handleNextAngle(e);
              }}
              title="کلیک برای مشاهده زاویه بعدی"
              className="px-2 py-0.5 rounded-full text-[10px] flex items-center gap-1 bg-white/[0.08] hover:bg-amber-500/20 text-amber-300 border border-white/10 hover:border-amber-400/40 backdrop-blur-md transition-all cursor-pointer"
            >
              <Layers className="w-2.5 h-2.5 text-amber-400" />
              <span>{activeAngleIdx + 1}/{angleCount}</span>
            </span>
          )}

          {/* Bouncy Heart Favorite Button with Visual Pop Feedback */}
          <motion.button
            id={`fav-btn-${dish.id}`}
            onClick={handleToggleFavorite}
            whileTap={{ scale: 0.75 }}
            animate={heartPopped ? { scale: [1, 1.4, 0.9, 1] } : { scale: 1 }}
            transition={{ duration: 0.4 }}
            className={`p-2 rounded-full backdrop-blur-md transition-all border relative ${
              isFav
                ? 'bg-rose-500/25 text-rose-400 border-rose-500/60 shadow-lg shadow-rose-500/30'
                : 'bg-white/[0.08] hover:bg-white/[0.18] text-stone-300 hover:text-white border-white/15'
            }`}
            title={isFav ? 'حذف از علاقه‌مندی‌ها' : 'افزودن به علاقه‌مندی‌ها'}
          >
            <Heart className={`w-3.5 h-3.5 transition-colors ${isFav ? 'fill-rose-500 text-rose-400' : ''}`} />
            {isFav && (
              <motion.span
                initial={{ scale: 0, opacity: 1 }}
                animate={{ scale: 2, opacity: 0 }}
                transition={{ duration: 0.5 }}
                className="absolute inset-0 rounded-full bg-rose-400/40 pointer-events-none"
              />
            )}
          </motion.button>
        </div>
      </div>

      {/* =========================================================================
          CENTER HERO FOOD IMAGE WITH ROTATING CIRCULAR RINGS & MULTI-ANGLE CAROUSEL
          ========================================================================= */}
      <div className="relative my-2 flex flex-col items-center justify-center h-48 sm:h-52 w-full">
        
        {/* Soft Ambient Grounding Glow */}
        <div className="absolute bottom-2 w-36 sm:w-40 h-6 bg-black/90 rounded-full blur-md scale-y-50 group-hover:scale-110 transition-all duration-300" />
        <div className="absolute inset-4 rounded-full bg-radial from-amber-500/20 via-transparent to-transparent blur-xl pointer-events-none group-hover:from-amber-500/35 transition-all" />

        {/* 1. OUTER ROTATING ORNATE RING (Animated Continuous Spin) */}
        <div 
          className={`absolute w-44 h-44 sm:w-48 sm:h-48 rounded-full border border-dashed border-amber-400/30 group-hover:border-amber-400/60 transition-all duration-700 pointer-events-none ${
            isHovered ? 'animate-[spin_8s_linear_infinite]' : 'animate-[spin_20s_linear_infinite]'
          }`}
        >
          {/* Compass / Astrological Orbit Pips */}
          <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-amber-400 shadow-[0_0_8px_#f59e0b]" />
          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-amber-400/60" />
          <div className="absolute top-1/2 -left-1 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-amber-300" />
          <div className="absolute top-1/2 -right-1 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-amber-300" />
        </div>

        {/* 2. INNER COUNTER-ROTATING DELICATE GOLDEN RING */}
        <div 
          className={`absolute w-40 h-40 sm:w-44 sm:h-44 rounded-full border border-dotted border-white/20 group-hover:border-amber-300/40 pointer-events-none transition-all duration-700 ${
            isHovered ? 'animate-[spin_12s_linear_infinite_reverse]' : 'animate-[spin_32s_linear_infinite_reverse]'
          }`}
        />

        {/* 3. FOOD VISUAL CONTAINER (Cross-fading with smooth angle transitions) */}
        <div className="relative z-10 w-36 h-36 sm:w-40 sm:h-40 rounded-full overflow-hidden p-1.5 bg-gradient-to-b from-[#352c22] via-[#1a1721] to-[#0a090e] border-2 border-amber-500/40 shadow-[0_20px_45px_rgba(0,0,0,0.95)] group-hover:scale-105 transition-transform duration-500 backdrop-blur-xl">
          <AnimatePresence mode="wait">
            <motion.img
              key={currentAngle.url}
              src={currentAngle.url}
              alt={`${dish.frenchName} - ${currentAngle.title}`}
              referrerPolicy="no-referrer"
              initial={{ opacity: 0.3, scale: 0.95, rotate: -3 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              exit={{ opacity: 0.2, scale: 1.03, rotate: 3 }}
              transition={{ duration: 0.35, ease: 'easeOut' }}
              className="w-full h-full object-cover rounded-full select-none"
            />
          </AnimatePresence>

          {/* Quick Angle Switcher Navigation Arrows (Overlaid on hover) */}
          {angleCount > 1 && (
            <>
              <button
                onClick={handlePrevAngle}
                aria-label="زاویه قبلی"
                className="absolute left-1.5 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-black/70 hover:bg-amber-500 hover:text-black text-white border border-white/20 hover:border-amber-400 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100 z-20 backdrop-blur-md shadow-lg"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={handleNextAngle}
                aria-label="زاویه بعدی"
                className="absolute right-1.5 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-black/70 hover:bg-amber-500 hover:text-black text-white border border-white/20 hover:border-amber-400 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100 z-20 backdrop-blur-md shadow-lg"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </>
          )}
        </div>

        {/* 4. MULTI-ANGLE INTERACTIVE DOTS & TITLE BAR (Directly on each card!) */}
        {angleCount > 1 ? (
          <div className="relative z-20 mt-2 flex items-center gap-1.5 bg-black/60 px-3 py-1 rounded-full border border-white/10 backdrop-blur-md">
            {gallery.map((g, idx) => (
              <button
                key={idx}
                onClick={(e) => handleSelectAngle(e, idx)}
                className={`transition-all duration-300 rounded-full flex items-center justify-center ${
                  activeAngleIdx === idx
                    ? 'w-4 h-1.5 bg-gradient-to-r from-amber-400 to-orange-400 rounded-full'
                    : 'w-1.5 h-1.5 bg-white/30 hover:bg-white/70'
                }`}
                title={g.title}
              />
            ))}
            <span className="text-[9px] text-amber-300/90 font-medium mr-1 font-mono">
              {currentAngle.title || `زاویه ${activeAngleIdx + 1}`}
            </span>
          </div>
        ) : (
          <div className="relative z-20 mt-2 flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-white/[0.04] border border-white/5 text-[9px] text-stone-400">
            <RotateCw className="w-2.5 h-2.5 text-amber-400/70" />
            <span>سرو با کلوش طلایی سر میز</span>
          </div>
        )}

      </div>

      {/* Dish Details */}
      <div className="mt-2 space-y-1 text-right relative z-10">
        {/* French Subtitle */}
        <h4 className="text-[11px] font-latin font-bold tracking-wider truncate text-amber-400">
          {dish.frenchName}
        </h4>

        {/* Persian Title */}
        <h3 className="text-base font-black text-white group-hover:text-amber-200 transition-colors leading-snug line-clamp-1">
          {dish.persianName}
        </h3>

        {/* Description snippet */}
        <p className="text-xs text-stone-300 line-clamp-2 leading-relaxed h-8">
          {dish.persianSubtitle || dish.description}
        </p>

        {/* Meta badges: Cooking time & Dietary */}
        <div className="flex items-center justify-between text-[11px] pt-1">
          <div className="flex items-center gap-1 text-stone-300">
            <Clock className="w-3 h-3 text-amber-400" />
            <span>{dish.prepTimeMinutes} دقیقه</span>
          </div>
          <div className="text-[10px] px-2.5 py-0.5 rounded-full bg-white/[0.06] text-stone-200 border border-white/10">
            <span>{dish.dietaryTags[0] || 'حلال ۱۰۰٪'}</span>
          </div>
        </div>
      </div>

      {/* Bottom Controls: Price + Stepper + Modern Glassy Orange CTA Button */}
      <div className="mt-3.5 pt-3 border-t border-white/10 flex flex-col gap-2.5 relative z-10">
        
        {/* Price Row */}
        <div className="flex items-center justify-between">
          <span className="text-[11px] text-stone-400">بهای تشریفات:</span>
          <span className="text-sm sm:text-base font-black font-mono tracking-tight text-amber-300">
            {dish.formattedPrice}
          </span>
        </div>

        {/* Controls Row */}
        <div className="flex items-center justify-between gap-2">
          
          {/* Stepper Capsule */}
          <div className="flex items-center rounded-2xl p-1 bg-white/[0.06] border border-white/10 backdrop-blur-md">
            <button
              onClick={handleDecrement}
              className="p-1.5 rounded-xl hover:bg-white/15 text-stone-300 hover:text-white transition-colors"
              title="کاهش تعداد"
            >
              <Minus className="w-3 h-3" />
            </button>
            <span className="w-6 text-center text-xs font-bold font-mono text-white">
              {quantity}
            </span>
            <button
              onClick={handleIncrement}
              className="p-1.5 rounded-xl hover:bg-white/15 text-stone-300 hover:text-white transition-colors"
              title="افزایش تعداد"
            >
              <Plus className="w-3 h-3" />
            </button>
          </div>

          {/* Quick View / Customize 360 Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onSelectDish(dish);
            }}
            className="p-2.5 rounded-2xl bg-white/[0.06] hover:bg-white/[0.15] text-amber-300 border border-white/10 hover:border-amber-400/40 transition-all backdrop-blur-md"
            title="مشاهده زوایا، کالری و شخصی‌سازی"
          >
            <Eye className="w-4 h-4" />
          </button>

          {/* Modern Orange/Amber Gradient Add to Cart Button */}
          <motion.button
            id={`add-dish-btn-${dish.id}`}
            onClick={handleAdd}
            whileTap={{ scale: 0.96 }}
            className={`flex-1 py-2.5 px-3 rounded-2xl text-xs font-black flex items-center justify-center gap-1.5 transition-all duration-300 ${
              isAdded
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                : 'bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-black shadow-[0_4px_20px_rgba(245,158,11,0.4)]'
            }`}
          >
            {isAdded ? (
              <>
                <Check className="w-3.5 h-3.5 text-white" />
                <span>افزوده شد!</span>
              </>
            ) : (
              <>
                <Plus className="w-3.5 h-3.5 text-black stroke-[3]" />
                <span>سفارش</span>
              </>
            )}
          </motion.button>

        </div>

      </div>

    </motion.div>
  );
};
