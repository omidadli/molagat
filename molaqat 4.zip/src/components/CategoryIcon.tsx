import React from 'react';
import { Sparkles, Crown, Utensils, Flame, Wine, Award, Star, Layers, Coffee, GlassWater } from 'lucide-react';

interface CategoryIconProps {
  name: string;
  className?: string;
}

export const CategoryIcon: React.FC<CategoryIconProps> = ({ name, className = 'w-5 h-5' }) => {
  switch (name.toLowerCase()) {
    case 'sparkles':
      return <Sparkles className={className} />;
    case 'crown':
      return <Crown className={className} />;
    case 'cheese':
      return <Layers className={className} />;
    case 'flame':
      return <Flame className={className} />;
    case 'wine':
      return <Wine className={className} />;
    case 'coffee':
    case 'infusions':
      return <Coffee className={className} />;
    case 'glass':
      return <GlassWater className={className} />;
    case 'award':
      return <Award className={className} />;
    case 'star':
      return <Star className={className} />;
    case 'utensils':
    default:
      return <Utensils className={className} />;
  }
};
