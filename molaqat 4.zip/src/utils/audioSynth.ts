// Realistic Grand Piano Ambient Synthesizer using Web Audio API
// Synthesizes realistic acoustic piano harmonics (hammer strike transient, fundamental + harmonic overtones, decay envelope, and reverbed resonance)
// Plays soothing classical impressionist melodies (Erik Satie: Gymnopédie No.1 & Claude Debussy: Clair de Lune motifs)

class LuxuryGrandPianoAudio {
  private ctx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private noteTimeouts: any[] = [];
  private loopTimeout: any = null;
  private masterGain: GainNode | null = null;
  private volume: number = 0.35;
  private currentPieceName: string = 'Gymnopédie No. 1 (Erik Satie)';
  private listeners: Set<(isPlaying: boolean) => void> = new Set();
  private autoPlayInitialized: boolean = false;

  // Erik Satie: Gymnopédie No. 1 - Melodic Phrases (Frequencies in Hz)
  // Left hand chords (soft, warm low registers) + Right hand graceful melody
  private gymnoSequence = [
    // Measure 1: Gmaj7 bass chord + melody pause
    { notes: [{ f: 98.00, dur: 3.5, vel: 0.4 }, { f: 196.00, dur: 3.0, vel: 0.3 }, { f: 246.94, dur: 3.0, vel: 0.35 }, { f: 293.66, dur: 3.0, vel: 0.35 }, { f: 369.99, dur: 3.0, vel: 0.35 }], delay: 0 },
    // Measure 2: Melody entrance (B4 -> A4)
    { notes: [{ f: 493.88, dur: 2.8, vel: 0.6 }], delay: 1.2 },
    { notes: [{ f: 440.00, dur: 2.5, vel: 0.55 }], delay: 2.8 },
    
    // Measure 3: Dmaj7 bass chord
    { notes: [{ f: 73.42, dur: 3.5, vel: 0.4 }, { f: 146.83, dur: 3.0, vel: 0.3 }, { f: 220.00, dur: 3.0, vel: 0.35 }, { f: 277.18, dur: 3.0, vel: 0.35 }, { f: 329.63, dur: 3.0, vel: 0.35 }], delay: 4.2 },
    // Measure 4: Melody (G4 -> F#4)
    { notes: [{ f: 392.00, dur: 2.6, vel: 0.55 }], delay: 5.4 },
    { notes: [{ f: 369.99, dur: 2.8, vel: 0.5 }], delay: 6.8 },

    // Measure 5: Em7 bass chord
    { notes: [{ f: 82.41, dur: 3.5, vel: 0.4 }, { f: 164.81, dur: 3.0, vel: 0.3 }, { f: 246.94, dur: 3.0, vel: 0.35 }, { f: 293.66, dur: 3.0, vel: 0.35 }, { f: 392.00, dur: 3.0, vel: 0.35 }], delay: 8.4 },
    // Measure 6: Melody ascending (E4 -> F#4 -> G4 -> B4)
    { notes: [{ f: 329.63, dur: 1.8, vel: 0.45 }], delay: 9.6 },
    { notes: [{ f: 369.99, dur: 1.8, vel: 0.5 }], delay: 10.8 },
    { notes: [{ f: 392.00, dur: 2.2, vel: 0.55 }], delay: 12.0 },
    { notes: [{ f: 493.88, dur: 3.2, vel: 0.65 }], delay: 13.4 },

    // Measure 7: A7sus4 to Dmaj9 resolution
    { notes: [{ f: 110.00, dur: 3.5, vel: 0.4 }, { f: 220.00, dur: 3.0, vel: 0.3 }, { f: 293.66, dur: 3.0, vel: 0.35 }, { f: 349.23, dur: 3.0, vel: 0.35 }, { f: 440.00, dur: 3.0, vel: 0.35 }], delay: 15.2 },
    { notes: [{ f: 440.00, dur: 2.5, vel: 0.5 }], delay: 16.6 },
    { notes: [{ f: 369.99, dur: 3.5, vel: 0.55 }], delay: 18.0 },
    { notes: [{ f: 293.66, dur: 4.5, vel: 0.45 }], delay: 19.8 },
  ];

  public subscribe(callback: (isPlaying: boolean) => void) {
    this.listeners.add(callback);
    callback(this.isPlaying);
    return () => {
      this.listeners.delete(callback);
    };
  }

  private notify() {
    this.listeners.forEach((cb) => {
      try {
        cb(this.isPlaying);
      } catch (e) {
        console.warn('Audio listener error:', e);
      }
    });
  }

  public init() {
    if (typeof window === 'undefined') return;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
        this.masterGain.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  // Setup auto-play default behavior with browser autoplay unlock
  public setupAutoPlay() {
    if (this.autoPlayInitialized || typeof window === 'undefined') return;
    this.autoPlayInitialized = true;

    // Try starting immediately
    this.start();

    // In case browser policy suspended the initial audio context without user gesture,
    // seamlessly resume and start playing on the very first gesture (click, scroll, touch, keydown)
    const unlockAutoPlay = () => {
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx.resume().then(() => {
          if (this.isPlaying) {
            this.clearAllScheduled();
            this.playFullPiece();
          }
        });
      }
      if (!this.isPlaying) {
        // If not playing, keep user's choice
      }
      // Remove listeners once interacted
      window.removeEventListener('pointerdown', unlockAutoPlay);
      window.removeEventListener('touchstart', unlockAutoPlay);
      window.removeEventListener('scroll', unlockAutoPlay);
      window.removeEventListener('keydown', unlockAutoPlay);
      window.removeEventListener('click', unlockAutoPlay);
    };

    window.addEventListener('pointerdown', unlockAutoPlay, { passive: true });
    window.addEventListener('touchstart', unlockAutoPlay, { passive: true });
    window.addEventListener('scroll', unlockAutoPlay, { passive: true });
    window.addEventListener('keydown', unlockAutoPlay, { passive: true });
    window.addEventListener('click', unlockAutoPlay, { passive: true });
  }

  // Synthesize an acoustic grand piano note with hammer strike transient and harmonic spectrum
  public playPianoNote(freq: number, duration: number, velocity: number = 0.5, timeOffset: number = 0) {
    if (!this.ctx || !this.masterGain) return;

    try {
      const now = this.ctx.currentTime + timeOffset;

      // 1. Harmonics configuration (Grand Piano harmonic series decay)
      // Fundamental + 2nd, 3rd, 4th, 5th, 6th overtones
      const harmonics = [
        { mult: 1, gain: 1.0 * velocity, decay: duration },
        { mult: 2, gain: 0.45 * velocity, decay: duration * 0.8 },
        { mult: 3, gain: 0.22 * velocity, decay: duration * 0.6 },
        { mult: 4, gain: 0.12 * velocity, decay: duration * 0.45 },
        { mult: 5, gain: 0.06 * velocity, decay: duration * 0.3 },
      ];

      // Master note gain node
      const noteGain = this.ctx.createGain();
      
      // Warm low-pass filter to emulate the acoustic piano body and felt hammer
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      // Higher velocities make the tone slightly brighter
      filter.frequency.setValueAtTime(1400 + velocity * 1800, now);
      filter.Q.setValueAtTime(1.2, now);

      noteGain.connect(filter);
      filter.connect(this.masterGain);

      // Trigger harmonics
      harmonics.forEach(({ mult, gain: hGain, decay: hDecay }) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const oscGain = this.ctx.createGain();

        // Slight micro-detuning for chorus/natural string richness
        const detune = (Math.random() - 0.5) * 3; 
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq * mult, now);
        osc.detune.setValueAtTime(detune, now);

        // Realistic piano envelope: Instant hammer strike (5ms), rapid initial decay, long smooth sustain release
        oscGain.gain.setValueAtTime(0, now);
        oscGain.gain.linearRampToValueAtTime(hGain * 0.18, now + 0.006); // Fast percussive strike
        oscGain.gain.exponentialRampToValueAtTime(hGain * 0.11, now + 0.08); // Felt strike decay
        oscGain.gain.exponentialRampToValueAtTime(0.0001, now + hDecay); // String vibration tail

        osc.connect(oscGain);
        oscGain.connect(noteGain);

        osc.start(now);
        osc.stop(now + hDecay + 0.05);
      });

      // 2. Soft felt hammer thud transient for realistic touch
      const hammer = this.ctx.createOscillator();
      const hammerGain = this.ctx.createGain();
      hammer.type = 'triangle';
      hammer.frequency.setValueAtTime(120, now);
      hammerGain.gain.setValueAtTime(0.02 * velocity, now);
      hammerGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.03);
      hammer.connect(hammerGain);
      hammerGain.connect(filter);
      hammer.start(now);
      hammer.stop(now + 0.04);

    } catch (e) {
      console.warn('Piano audio synthesis notice:', e);
    }
  }

  public setVolume(val: number) {
    this.volume = Math.max(0, Math.min(1, val));
    if (this.ctx && this.masterGain) {
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
    }
  }

  public getVolume(): number {
    return this.volume;
  }

  public getCurrentPiece(): string {
    return this.currentPieceName;
  }

  public toggle(): boolean {
    if (this.isPlaying) {
      this.stop();
      return false;
    } else {
      this.start();
      return true;
    }
  }

  public start() {
    this.init();
    if (!this.ctx) return;
    this.isPlaying = true;
    this.notify();

    this.clearAllScheduled();
    this.playFullPiece();
  }

  private playFullPiece() {
    if (!this.isPlaying) return;

    // Schedule all notes in sequence
    this.gymnoSequence.forEach((event) => {
      const tId = setTimeout(() => {
        if (!this.isPlaying) return;
        event.notes.forEach((n) => {
          this.playPianoNote(n.f, n.dur, n.vel, 0);
        });
      }, event.delay * 1000);
      this.noteTimeouts.push(tId);
    });

    // Total sequence loop duration (~22 seconds)
    this.loopTimeout = setTimeout(() => {
      if (this.isPlaying) {
        this.playFullPiece();
      }
    }, 22500);
  }

  private clearAllScheduled() {
    this.noteTimeouts.forEach((t) => clearTimeout(t));
    this.noteTimeouts = [];
    if (this.loopTimeout) {
      clearTimeout(this.loopTimeout);
      this.loopTimeout = null;
    }
  }

  public stop() {
    this.isPlaying = false;
    this.clearAllScheduled();
    this.notify();
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }
}

export const luxuryAudio = new LuxuryGrandPianoAudio();
