import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Page, ReservationData } from '../types';
import { 
  JALALI_MONTHS, 
  TIME_SLOTS, 
  OCCASIONS, 
  SALONS, 
  RESTAURANT_INFO,
  VIP_CHAUFFEUR_OPTIONS
} from '../data/restaurantData';
import { MolaqatLogo } from '../components/MolaqatLogo';
import { 
  Calendar, 
  Clock, 
  Users, 
  Sparkles, 
  CheckCircle2, 
  ShieldCheck, 
  Phone, 
  Car, 
  Download, 
  ArrowLeft, 
  AlertCircle,
  Crown,
  Wine,
  Gift
} from 'lucide-react';
import interiorImg from '../assets/images/molaqat_interior_hall_1786224218757.jpg';

interface ReservationPageProps {
  setCurrentPage: (page: Page) => void;
}

export const ReservationPage: React.FC<ReservationPageProps> = ({ setCurrentPage }) => {
  const currentJalaliYear = 1404;
  const [selectedMonthIndex, setSelectedMonthIndex] = useState(4); // مرداد
  const [selectedDay, setSelectedDay] = useState(18);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState(TIME_SLOTS[1].id);
  const [guestsCount, setGuestsCount] = useState(2);
  const [selectedSalon, setSelectedSalon] = useState(SALONS[0].id);
  const [selectedOccasion, setSelectedOccasion] = useState(OCCASIONS[0]);
  
  // VIP Enhancements
  const [vipChauffeur, setVipChauffeur] = useState(true);
  const [selectedCarModel, setSelectedCarModel] = useState(VIP_CHAUFFEUR_OPTIONS[0].id);
  const [pickupAddress, setPickupAddress] = useState('مشهد، بلوار سجاد');
  const [addCaviarService, setAddCaviarService] = useState(false);
  const [addSommelierService, setAddSommelierService] = useState(false);
  const [addFloralService, setAddFloralService] = useState(false);

  // Guest Info
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [specialNotes, setSpecialNotes] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [bookingReference, setBookingReference] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const getDaysInMonth = (monthIdx: number) => {
    if (monthIdx < 6) return 31;
    if (monthIdx < 11) return 30;
    return 29;
  };

  const daysCount = getDaysInMonth(selectedMonthIndex);
  const daysArray = Array.from({ length: daysCount }, (_, i) => i + 1);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !phoneNumber.trim()) {
      setErrorMessage('لطفاً نام و نام خانوادگی و شماره تلفن همراه خود را وارد فرمایید.');
      return;
    }
    setErrorMessage(null);
    const refCode = 'MLQ-' + Math.floor(100000 + Math.random() * 900000);
    setBookingReference(refCode);
    setIsSubmitted(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const selectedMonthName = JALALI_MONTHS[selectedMonthIndex];
  const selectedSalonObj = SALONS.find((s) => s.id === selectedSalon) || SALONS[0];
  const selectedSlotObj = TIME_SLOTS.find((t) => t.id === selectedTimeSlot) || TIME_SLOTS[0];
  const selectedCarObj = VIP_CHAUFFEUR_OPTIONS.find((c) => c.id === selectedCarModel) || VIP_CHAUFFEUR_OPTIONS[0];

  return (
    <div className="w-full relative overflow-hidden bg-[#09080c] text-white">

      {/* Contextual High-Resolution Background */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <img
          src={interiorImg}
          alt="Palace Interior"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover filter brightness-[0.20] contrast-125"
        />
        <div className="absolute inset-0 bg-[#09080c]/85 backdrop-blur-md"></div>
      </div>

      <div className="relative pt-32 pb-20 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12 text-right z-10">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-white/[0.06] border border-amber-500/30 text-xs font-semibold text-white backdrop-blur-xl shadow-lg">
            <MolaqatLogo size={20} variant="gold" />
            <span>پذیرایی صرفاً بر پایه هماهنگی قبلی</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
            رزرو اختصاصی میز و سالن‌های VIP
          </h1>
          <p className="text-xs sm:text-sm text-stone-300">
            انتخاب تاریخ در تقویم خورشیدی جلالی، سالن تشریفاتی و هماهنگی ترانسفر ب‌ام‌و/مرسدس با کانسیرژ
          </p>
        </div>

        {!isSubmitted ? (
          <form onSubmit={handleSubmit} className="space-y-8">
            
            {/* =========================================================================
                STEP 1: JALALI CALENDAR PICKER
                ========================================================================= */}
            <div className="rounded-[32px] bg-white/[0.04] border border-white/10 p-6 sm:p-8 backdrop-blur-2xl space-y-6 shadow-2xl">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div className="flex items-center gap-2 text-base font-bold text-white">
                  <Calendar className="w-5 h-5 text-amber-400" />
                  <span>۱. انتخاب تاریخ ضیافت (تقویم شمسی جلالی ۱۴۰۴)</span>
                </div>
                <span className="text-xs text-amber-300 font-mono font-bold">
                  {selectedDay} {selectedMonthName} {currentJalaliYear}
                </span>
              </div>

              {/* Jalali Months Bar */}
              <div className="space-y-2">
                <label className="text-xs font-medium text-stone-400">ماه مورد نظر:</label>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {JALALI_MONTHS.map((month, idx) => (
                    <button
                      type="button"
                      key={month}
                      onClick={() => setSelectedMonthIndex(idx)}
                      className={`py-2 px-3 rounded-2xl text-xs font-semibold transition-all ${
                        selectedMonthIndex === idx
                          ? 'bg-amber-500 text-black shadow-md font-bold'
                          : 'bg-white/[0.05] hover:bg-white/[0.1] text-stone-300 border border-white/10'
                      }`}
                    >
                      {month}
                    </button>
                  ))}
                </div>
              </div>

              {/* Jalali Days Grid */}
              <div className="space-y-2 pt-2">
                <label className="text-xs font-medium text-stone-400">روز ماه ({selectedMonthName}):</label>
                <div className="grid grid-cols-7 gap-2 text-center">
                  {daysArray.map((day) => {
                    const isDaySelected = selectedDay === day;
                    return (
                      <button
                        type="button"
                        key={day}
                        onClick={() => setSelectedDay(day)}
                        className={`h-11 sm:h-12 rounded-2xl text-xs sm:text-sm font-mono flex items-center justify-center transition-all ${
                          isDaySelected
                            ? 'bg-gradient-to-br from-amber-400 to-orange-500 text-black font-black shadow-lg shadow-amber-500/30 scale-105'
                            : 'bg-white/[0.04] hover:bg-white/[0.08] text-stone-200 border border-white/10'
                        }`}
                      >
                        {day}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* =========================================================================
                STEP 2: TIME SLOTS & GUESTS COUNT
                ========================================================================= */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Time Slot Picker */}
              <div className="rounded-[32px] bg-white/[0.04] border border-white/10 p-6 space-y-4 backdrop-blur-2xl">
                <div className="flex items-center gap-2 text-sm font-bold text-white border-b border-white/10 pb-3">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span>۲. سانس زمانی پذیرایی</span>
                </div>

                <div className="space-y-2">
                  {TIME_SLOTS.map((slot) => (
                    <button
                      type="button"
                      key={slot.id}
                      onClick={() => setSelectedTimeSlot(slot.id)}
                      className={`w-full p-3.5 rounded-2xl text-right flex items-center justify-between border transition-all ${
                        selectedTimeSlot === slot.id
                          ? 'bg-amber-500/20 border-amber-400 text-white'
                          : 'bg-black/30 border-white/10 hover:bg-white/[0.06] text-stone-400'
                      }`}
                    >
                      <div>
                        <span className="text-xs font-bold block text-white">{slot.label}</span>
                      </div>
                      <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-white/10 text-amber-300 font-bold">
                        {slot.badge}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Guests Count Picker */}
              <div className="rounded-[32px] bg-white/[0.04] border border-white/10 p-6 space-y-4 backdrop-blur-2xl">
                <div className="flex items-center gap-2 text-sm font-bold text-white border-b border-white/10 pb-3">
                  <Users className="w-4 h-4 text-amber-400" />
                  <span>۳. تعداد مهمانان</span>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-2">
                    {[2, 4, 6, 8, 10, 12].map((num) => (
                      <button
                        type="button"
                        key={num}
                        onClick={() => setGuestsCount(num)}
                        className={`py-3 rounded-2xl text-sm font-mono font-bold transition-all ${
                          guestsCount === num
                            ? 'bg-amber-500 text-black shadow-md'
                            : 'bg-black/30 hover:bg-white/[0.06] text-stone-300 border border-white/10'
                        }`}
                      >
                        {num} نفر
                      </button>
                    ))}
                  </div>
                  <p className="text-[11px] text-stone-400">
                    * برای ضیافت‌های بالای ۱۲ نفر یا قرق کامل عمارت، کانسیرژ اختصاصی هماهنگی خواهد نمود.
                  </p>
                </div>
              </div>

            </div>

            {/* =========================================================================
                STEP 3: SALON SELECTION
                ========================================================================= */}
            <div className="rounded-[32px] bg-white/[0.04] border border-white/10 p-6 sm:p-8 space-y-4 backdrop-blur-2xl">
              <div className="flex items-center gap-2 text-sm font-bold text-white border-b border-white/10 pb-3">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>۴. انتخاب فضای سالن اختصاصی</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {SALONS.map((salon) => {
                  const isSalonActive = selectedSalon === salon.id;
                  return (
                    <div
                      key={salon.id}
                      onClick={() => setSelectedSalon(salon.id)}
                      className={`rounded-2xl border p-4 cursor-pointer transition-all flex flex-col justify-between ${
                        isSalonActive
                          ? 'bg-amber-500/20 border-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.25)]'
                          : 'bg-black/30 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="space-y-2">
                        <span className="text-[10px] font-latin text-amber-400 font-bold">{salon.frenchName}</span>
                        <h4 className="text-xs font-bold text-white">{salon.persianName}</h4>
                        <p className="text-[11px] text-stone-400 line-clamp-2">{salon.description}</p>
                      </div>
                      <div className="pt-3 flex items-center justify-between text-[10px] text-amber-300">
                        <span>{salon.capacity}</span>
                        {isSalonActive && <CheckCircle2 className="w-4 h-4 text-amber-400" />}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* =========================================================================
                STEP 4: VIP SERVICES & CHAUFFEUR SELECTION
                ========================================================================= */}
            <div className="rounded-[32px] bg-white/[0.04] border border-white/10 p-6 sm:p-8 space-y-6 backdrop-blur-2xl">
              <div className="flex items-center gap-2 text-sm font-bold text-white border-b border-white/10 pb-3">
                <Crown className="w-4 h-4 text-amber-400" />
                <span>۵. خدمات تشریفاتی و VIP مازاد</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Chauffeur Toggle & Options */}
                <div className={`p-5 rounded-2xl border transition-all ${vipChauffeur ? 'bg-amber-500/10 border-amber-400' : 'bg-black/30 border-white/10'}`}>
                  <div className="flex items-center justify-between cursor-pointer" onClick={() => setVipChauffeur(!vipChauffeur)}>
                    <div className="flex items-center gap-2.5">
                      <Car className="w-5 h-5 text-amber-400" />
                      <div>
                        <span className="text-xs font-bold text-white block">ترانسفر با خودروی تشریفات و شوفر</span>
                        <span className="text-[10px] text-stone-400">رفت و برگشت در مشهد</span>
                      </div>
                    </div>
                    <span className={`text-xs font-bold px-3 py-1 rounded-full ${vipChauffeur ? 'bg-amber-500 text-black' : 'bg-white/10 text-stone-400'}`}>
                      {vipChauffeur ? 'فعال' : 'غیرفعال'}
                    </span>
                  </div>

                  {vipChauffeur && (
                    <div className="mt-4 pt-3 border-t border-white/10 space-y-3">
                      <div className="space-y-1">
                        <label className="text-[11px] text-amber-300">انتخاب خودرو:</label>
                        <select 
                          value={selectedCarModel} 
                          onChange={(e) => setSelectedCarModel(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-xs text-white"
                        >
                          {VIP_CHAUFFEUR_OPTIONS.map((car) => (
                            <option key={car.id} value={car.id} className="bg-stone-900 text-white">
                              {car.name} ({car.formattedPrice})
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[11px] text-amber-300">نشانی سوار شدن در مشهد:</label>
                        <input 
                          type="text" 
                          value={pickupAddress} 
                          onChange={(e) => setPickupAddress(e.target.value)}
                          placeholder="مشهد، سجاد، کوثر، احمدآباد یا هتل..."
                          className="w-full px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-xs text-white"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Caviar Service Add-on */}
                <div 
                  onClick={() => setAddCaviarService(!addCaviarService)}
                  className={`p-5 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
                    addCaviarService ? 'bg-amber-500/10 border-amber-400' : 'bg-black/30 border-white/10'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Sparkles className="w-5 h-5 text-amber-400" />
                    <div>
                      <span className="text-xs font-bold text-white block">تشریفات خاویار بار بلوگای خزر روی میز</span>
                      <span className="text-[10px] text-stone-400">سرو در ظروف مروارید و یخ بلورین (+ ۲,۵۰۰,۰۰۰ تومان)</span>
                    </div>
                  </div>
                  <span className={`text-xs font-bold px-3 py-1 rounded-full ${addCaviarService ? 'bg-amber-500 text-black' : 'bg-white/10 text-stone-400'}`}>
                    {addCaviarService ? 'افزوده شد' : 'افزودن'}
                  </span>
                </div>

                {/* Sommelier Consultation */}
                <div 
                  onClick={() => setAddSommelierService(!addSommelierService)}
                  className={`p-5 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
                    addSommelierService ? 'bg-amber-500/10 border-amber-400' : 'bg-black/30 border-white/10'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Wine className="w-5 h-5 text-rose-400" />
                    <div>
                      <span className="text-xs font-bold text-white block">مشاوره اختصاصی سرپیشخدمت نوشیدنی</span>
                      <span className="text-[10px] text-stone-400">همراهی در انتخاب عصاره‌های گیاهی و ماکتیل‌ها</span>
                    </div>
                  </div>
                  <span className={`text-xs font-bold px-3 py-1 rounded-full ${addSommelierService ? 'bg-amber-500 text-black' : 'bg-white/10 text-stone-400'}`}>
                    {addSommelierService ? 'افزوده شد' : 'افزودن'}
                  </span>
                </div>

                {/* Floral Arrangement */}
                <div 
                  onClick={() => setAddFloralService(!addFloralService)}
                  className={`p-5 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
                    addFloralService ? 'bg-amber-500/10 border-amber-400' : 'bg-black/30 border-white/10'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Gift className="w-5 h-5 text-emerald-400" />
                    <div>
                      <span className="text-xs font-bold text-white block">چیدمان گل رز هلندی و شمع‌های دست‌ساز</span>
                      <span className="text-[10px] text-stone-400">ویژه سالگرد، تولد یا دیدارهای کاری مهم (+ ۸۵۰,۰۰۰ تومان)</span>
                    </div>
                  </div>
                  <span className={`text-xs font-bold px-3 py-1 rounded-full ${addFloralService ? 'bg-amber-500 text-black' : 'bg-white/10 text-stone-400'}`}>
                    {addFloralService ? 'افزوده شد' : 'افزودن'}
                  </span>
                </div>

              </div>

            </div>

            {/* =========================================================================
                STEP 5: OCCASION & GUEST CONTACT
                ========================================================================= */}
            <div className="rounded-[32px] bg-white/[0.04] border border-white/10 p-6 sm:p-8 space-y-6 backdrop-blur-2xl">
              <div className="flex items-center gap-2 text-sm font-bold text-white border-b border-white/10 pb-3">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>۶. اطلاعات هماهنگی و کانسیرژ VIP</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Full Name */}
                <div className="space-y-2">
                  <label className="text-xs font-medium text-stone-300 block">نام و نام خانوادگی میزبان محترم:</label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="جناب آقای / سرکار خانم دکتر..."
                    className="w-full px-4 py-3 rounded-2xl bg-black/40 border border-white/10 text-xs sm:text-sm text-white placeholder-stone-500 focus:outline-none focus:border-amber-400"
                  />
                </div>

                {/* Mobile Phone */}
                <div className="space-y-2">
                  <label className="text-xs font-medium text-stone-300 block">شماره تلفن همراه (۰۹۱۵...) جهت تماس کانسیرژ:</label>
                  <input
                    type="tel"
                    required
                    dir="ltr"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="0915 123 4567"
                    className="w-full px-4 py-3 rounded-2xl bg-black/40 border border-white/10 text-left font-mono text-xs sm:text-sm text-white placeholder-stone-500 focus:outline-none focus:border-amber-400"
                  />
                </div>

                {/* Occasion Selection */}
                <div className="space-y-2">
                  <label className="text-xs font-medium text-stone-300 block">مناسبت ضیافت:</label>
                  <select
                    value={selectedOccasion}
                    onChange={(e) => setSelectedOccasion(e.target.value)}
                    className="w-full px-4 py-3 rounded-2xl bg-black/40 border border-white/10 text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400"
                  >
                    {OCCASIONS.map((occ) => (
                      <option key={occ} value={occ} className="bg-stone-900 text-white">
                        {occ}
                      </option>
                    ))}
                  </select>
                </div>

              </div>

              {/* Special notes */}
              <div className="space-y-2">
                <label className="text-xs font-medium text-stone-300 block">
                  درخواست‌های اختصاصی یا پرهیزهای غذایی (اختیاری):
                </label>
                <textarea
                  rows={2}
                  value={specialNotes}
                  onChange={(e) => setSpecialNotes(e.target.value)}
                  placeholder="توضیحات تکمیلی پیرامون نوع میز، چیدمان و هماهنگی‌های مد نظر..."
                  className="w-full px-4 py-3 rounded-2xl bg-black/40 border border-white/10 text-xs text-white placeholder-stone-500 focus:outline-none focus:border-amber-400"
                ></textarea>
              </div>

              {/* Validation Error Message */}
              <AnimatePresence>
                {errorMessage && (
                  <motion.div
                    initial={{ opacity: 0, y: -8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    className="p-3.5 rounded-2xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs flex items-center gap-2"
                  >
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{errorMessage}</span>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Submit Button */}
              <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-xs text-stone-400">
                  <span>پس از ثبت، کانسیرژ اختصاصی ظرف حداکثر ۳۰ دقیقه جهت تایید نهایی تماس خواهد گرفت.</span>
                </div>

                <button
                  type="submit"
                  id="submit-reservation-btn"
                  className="w-full sm:w-auto px-10 py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 text-black font-black text-sm shadow-[0_4px_25px_rgba(245,158,11,0.4)] hover:scale-105 active:scale-95 transition-all"
                >
                  ثبت قطعی درخواست رزرو تشریفات
                </button>
              </div>

            </div>

          </form>
        ) : (
          /* =========================================================================
              CEREMONIAL VIP CONFIRMATION PASSPORT CARD
              ========================================================================= */
          <div className="space-y-8 animate-fade-in">
            <div className="relative max-w-2xl mx-auto rounded-[36px] bg-gradient-to-b from-[#221c12] via-[#15141c] to-[#0a0a0e] border-2 border-amber-400 p-8 sm:p-12 shadow-[0_25px_80px_rgba(245,158,11,0.25)] text-right space-y-6">
              
              {/* Header Badge */}
              <div className="flex items-center justify-between border-b border-amber-500/30 pb-6">
                <div className="flex items-center gap-3">
                  <MolaqatLogo size={40} variant="gold" />
                  <div>
                    <h2 className="text-xl font-bold text-white">گذرنامه تشریفات عمارت ملاقات</h2>
                    <span className="text-[10px] font-latin text-amber-300 font-bold">MOLAQAṮ VIP RESERVATION PASSPORT</span>
                  </div>
                </div>

                <div className="text-left font-mono">
                  <span className="text-[10px] text-stone-400 block">کد رهگیری VIP:</span>
                  <span className="text-sm font-bold text-amber-300">{bookingReference}</span>
                </div>
              </div>

              {/* Guest Summary Info */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
                <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10">
                  <span className="text-[10px] text-stone-400 block">میزبان محترم:</span>
                  <span className="font-bold text-white text-sm">{fullName}</span>
                </div>

                <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10">
                  <span className="text-[10px] text-stone-400 block">تاریخ ضیافت (شمسی):</span>
                  <span className="font-bold text-amber-300">{selectedDay} {selectedMonthName} {currentJalaliYear}</span>
                </div>

                <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10">
                  <span className="text-[10px] text-stone-400 block">سانس پذیرایی:</span>
                  <span className="font-bold text-white">{selectedSlotObj.label.split('-')[0]}</span>
                </div>

                <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10">
                  <span className="text-[10px] text-stone-400 block">فضای سالن:</span>
                  <span className="font-bold text-white">{selectedSalonObj.persianName}</span>
                </div>

                <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10">
                  <span className="text-[10px] text-stone-400 block">تعداد مهمانان:</span>
                  <span className="font-bold text-white">{guestsCount} نفر</span>
                </div>

                <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10">
                  <span className="text-[10px] text-stone-400 block">سرویس ترانسفر:</span>
                  <span className="font-bold text-amber-300">{vipChauffeur ? selectedCarObj.name : 'شخصی'}</span>
                </div>
              </div>

              {/* Additional Services Badge */}
              {(addCaviarService || addSommelierService || addFloralService) && (
                <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-400/30 text-xs text-white space-y-1">
                  <span className="font-bold text-amber-300 block">خدمات افزوده VIP:</span>
                  <div className="flex flex-wrap gap-2 text-[11px]">
                    {addCaviarService && <span className="px-2.5 py-1 rounded-full bg-black/50 border border-white/10">✦ میز خاویار بلوگا</span>}
                    {addSommelierService && <span className="px-2.5 py-1 rounded-full bg-black/50 border border-white/10">✦ مشاوره نوشیدنی</span>}
                    {addFloralService && <span className="px-2.5 py-1 rounded-full bg-black/50 border border-white/10">✦ چیدمان گل رز</span>}
                  </div>
                </div>
              )}

              {/* Dress code & Valet Reminders */}
              <div className="p-4 rounded-2xl bg-black/50 border border-white/10 space-y-2 text-xs text-stone-300">
                <div className="flex items-center gap-2 text-white font-bold">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <span>یادداشت‌های تشریفاتی و حضور:</span>
                </div>
                <ul className="space-y-1 text-[11px] list-disc list-inside text-stone-400">
                  <li>{RESTAURANT_INFO.dressCode}</li>
                  <li>{RESTAURANT_INFO.valetService}</li>
                  <li>آدرس: {RESTAURANT_INFO.addressPersian}</li>
                </ul>
              </div>

              {/* Actions */}
              <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-4">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-6 py-3 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 text-xs font-semibold text-white flex items-center gap-2"
                >
                  <Download className="w-4 h-4 text-amber-400" />
                  <span>چاپ یا ذخیره گذرنامه VIP</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsSubmitted(false)}
                  className="px-6 py-3 rounded-2xl bg-amber-500 text-black text-xs font-bold shadow-md"
                >
                  ثبت رزرو جدید
                </button>
              </div>

            </div>
          </div>
        )}

      </div>

      {/* =========================================================================
          WHITE ALABASTER SECTION: CEREMONIAL PROTOCOLS & DRESS CODE
          ========================================================================= */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#faf8f5] text-stone-900 border-t-2 border-stone-200 relative z-10">
        <div className="max-w-4xl mx-auto space-y-8 text-right">
          
          <div className="text-center max-w-xl mx-auto space-y-2">
            <h3 className="text-2xl font-black text-stone-900">
              پروتکل‌های تشریفاتی و منشور میزبانی عمارت ملاقات
            </h3>
            <p className="text-xs text-stone-600">
              تعهد متقابل برای خلق خاطره‌ای جاودان و آرامش‌بخش در قلب مشهد
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs text-stone-700">
            <div className="p-6 rounded-3xl bg-white border border-stone-200 shadow-sm space-y-2">
              <h4 className="font-bold text-stone-900 text-sm">کد پوشش (Dress Code)</h4>
              <p className="leading-relaxed">کت و شلوار یا پوشش اسمارت کژوال آراسته برای آقایان، و لباس رسمی و پوشش شایسته برای بانوان ارجمند الزامی است.</p>
            </div>
            <div className="p-6 rounded-3xl bg-white border border-stone-200 shadow-sm space-y-2">
              <h4 className="font-bold text-stone-900 text-sm">پارکینگ و ولت اختصاصی</h4>
              <p className="leading-relaxed">سرویس تحویل خودرو (Valet Parking) با بیمه اختصاصی درب عمارت ملاقات مهیاست.</p>
            </div>
            <div className="p-6 rounded-3xl bg-white border border-stone-200 shadow-sm space-y-2">
              <h4 className="font-bold text-stone-900 text-sm">آرامش اکوستیک فضا</h4>
              <p className="leading-relaxed">به منظور حفظ تمرکز مهمانان و نوای زنده پیانو، لطفاً تلفن‌های همراه را در حالت بی‌صدا قرار دهید.</p>
            </div>
          </div>

        </div>
      </section>

    </div>
  );
};
