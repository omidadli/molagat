import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Page, GalleryItem } from '../types';
import { GALLERY_ITEMS } from '../data/restaurantData';
import { MolaqatLogo } from '../components/MolaqatLogo';
import { Sparkles, Maximize2, X, ChevronRight, ChevronLeft, Camera, Eye, ArrowLeft } from 'lucide-react';
import interiorImg from '../assets/images/molaqat_interior_hall_1786224218757.jpg';

interface GalleryPageProps {
  setCurrentPage: (page: Page) => void;
}

export const GalleryPage: React.FC<GalleryPageProps> = ({ setCurrentPage }) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'interior' | 'cuisine' | 'vip' | 'details'>('all');
  const [selectedItem, setSelectedItem] = useState<GalleryItem | null>(null);

  const filters = [
    { id: 'all', label: 'همه قاب‌ها' },
    { id: 'interior', label: 'تالار و عمارت' },
    { id: 'cuisine', label: 'هنر آشپزی' },
    { id: 'vip', label: 'سالن‌های خصوصی VIP' },
    { id: 'details', label: 'جزئیات معماری و ظروف' },
  ];

  const filteredItems = GALLERY_ITEMS.filter((item) => {
    if (activeFilter === 'all') return true;
    return item.category === activeFilter;
  });

  const handleNext = () => {
    if (!selectedItem) return;
    const currentIndex = filteredItems.findIndex((i) => i.id === selectedItem.id);
    const nextIndex = (currentIndex + 1) % filteredItems.length;
    setSelectedItem(filteredItems[nextIndex]);
  };

  const handlePrev = () => {
    if (!selectedItem) return;
    const currentIndex = filteredItems.findIndex((i) => i.id === selectedItem.id);
    const prevIndex = (currentIndex - 1 + filteredItems.length) % filteredItems.length;
    setSelectedItem(filteredItems[prevIndex]);
  };

  // Keyboard navigation for lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!selectedItem) return;
      if (e.key === 'Escape') setSelectedItem(null);
      if (e.key === 'ArrowRight') handlePrev();
      if (e.key === 'ArrowLeft') handleNext();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedItem, filteredItems]);

  return (
    <div className="w-full relative overflow-hidden bg-[#09080c] text-white">

      {/* Contextual High-Resolution Background */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <img
          src={interiorImg}
          alt="Palace Interior"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover filter brightness-[0.20] contrast-125"
        />
        <div className="absolute inset-0 bg-[#09080c]/85 backdrop-blur-md"></div>
      </div>

      <div className="relative pt-32 pb-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12 text-right z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-white/[0.06] border border-amber-500/30 text-xs font-semibold text-white backdrop-blur-xl shadow-lg">
            <MolaqatLogo size={20} variant="gold" />
            <span>روایت تصویری از شکوه و نور</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
            گالری عکس‌های اختصاصی عمارت
          </h1>
          <p className="text-xs sm:text-sm text-stone-300">
            نگاهی به جزئیات تالارها، هنر چیدمان سرآشپز و اتمسفر شب‌های ملاقات در مشهد
          </p>
        </div>

        {/* Filter Tabs in Frosted Style */}
        <div className="flex items-center justify-center gap-2 overflow-x-auto pb-2 no-scrollbar">
          {filters.map((f) => (
            <button
              key={f.id}
              onClick={() => setActiveFilter(f.id as any)}
              className={`px-4 py-2 rounded-2xl text-xs font-semibold transition-all backdrop-blur-xl ${
                activeFilter === f.id
                  ? 'bg-amber-500 text-black font-black shadow-lg shadow-amber-500/25 scale-105'
                  : 'bg-white/[0.04] hover:bg-white/[0.08] text-stone-300 border border-white/10'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Responsive Grid with Modern Frosted Glass Borders */}
        <motion.div
          key={activeFilter}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filteredItems.map((item) => (
            <motion.div
              key={item.id}
              onClick={() => setSelectedItem(item)}
              whileHover={{ y: -6 }}
              transition={{ duration: 0.3 }}
              className="group relative rounded-[28px] overflow-hidden bg-white/[0.03] border border-white/10 hover:border-amber-400/60 shadow-2xl cursor-pointer backdrop-blur-xl"
            >
              <div className="relative aspect-4/3 overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-85 group-hover:opacity-95 transition-opacity flex flex-col justify-between p-5">
                  <div className="flex justify-between items-center">
                    <span className="px-3 py-1 rounded-full bg-black/70 backdrop-blur-md text-[11px] font-bold text-amber-200 border border-white/10">
                      {item.categoryLabel}
                    </span>
                    <div className="w-8 h-8 rounded-full bg-black/70 backdrop-blur-md flex items-center justify-center text-white/80 group-hover:text-amber-400 transition-colors">
                      <Maximize2 className="w-4 h-4" />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-sm font-bold text-white group-hover:text-amber-200">
                      {item.title}
                    </h3>
                    <p className="text-[11px] text-stone-300 line-clamp-2">
                      {item.description}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

      </div>

      {/* =========================================================================
          WHITE ALABASTER SECTION: PHOTO & RECORDING GUIDELINES
          ========================================================================= */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#faf8f5] text-stone-900 border-t-2 border-stone-200 relative z-10">
        <div className="max-w-5xl mx-auto space-y-8 text-right">
          
          <div className="flex items-center gap-3 border-b border-stone-300 pb-4">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-800">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-stone-900">سیاست ثبت خاطرات و عکاسی در عمارت ملاقات</h3>
              <p className="text-xs text-stone-600">رعایت حریم خصوصی مهمانان ارجمند اولویت نخست ماست</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-stone-700 leading-relaxed">
            <div className="p-5 rounded-2xl bg-white border border-stone-200 shadow-sm space-y-2">
              <h4 className="font-bold text-stone-900 text-sm">عکاسی شخصی بر سر میز</h4>
              <p>عکاسی از بشقاب‌های غذا و همراهان گرامی بر سر میز آزاد است. تقاضا می‌شود از فلش مستقیم در تالار اصلی به منظور حفظ آرامش سایر مهمانان خودداری فرمایید.</p>
            </div>
            <div className="p-5 rounded-2xl bg-white border border-stone-200 shadow-sm space-y-2">
              <h4 className="font-bold text-stone-900 text-sm">عکاسی تشریفاتی و سالگردها</h4>
              <p>برای عکاسی حرفه‌ای سالگرد، عقد یا تولد در سالن‌های VIP ورسای، امکان هماهنگی پیش از ساعت پذیرایی با تیم تشریفات فراهم می‌باشد.</p>
            </div>
          </div>

          <div className="text-center pt-2">
            <button
              onClick={() => setCurrentPage('reservation')}
              className="px-8 py-3 rounded-2xl bg-stone-900 hover:bg-black text-white hover:text-amber-300 font-bold text-xs shadow-md transition-all inline-flex items-center gap-2"
            >
              <span>رزرو تالار یا سالن اختصاصی</span>
              <ArrowLeft className="w-4 h-4 text-amber-400" />
            </button>
          </div>

        </div>
      </section>

      {/* Lightbox Modal with AnimatePresence */}
      <AnimatePresence>
        {selectedItem && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/95 backdrop-blur-2xl"
              onClick={() => setSelectedItem(null)}
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: 15 }}
              transition={{ type: 'spring', damping: 28, stiffness: 320 }}
              className="relative z-10 max-w-5xl w-full bg-[#111116] border border-amber-500/30 rounded-[32px] overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
            >
              
              {/* Top Bar */}
              <div className="p-4 flex items-center justify-between border-b border-white/10 bg-[#0d0d12]">
                <span className="text-xs text-amber-400 font-bold">
                  {selectedItem.categoryLabel}
                </span>
                <button
                  onClick={() => setSelectedItem(null)}
                  className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Image Stage */}
              <div className="relative flex-1 bg-black flex items-center justify-center overflow-hidden min-h-[350px] sm:min-h-[500px]">
                <AnimatePresence mode="wait">
                  <motion.img
                    key={selectedItem.id}
                    src={selectedItem.image}
                    alt={selectedItem.title}
                    referrerPolicy="no-referrer"
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 1.02 }}
                    transition={{ duration: 0.25 }}
                    className="max-h-[70vh] w-auto max-w-full object-contain"
                  />
                </AnimatePresence>

                <button
                  onClick={handlePrev}
                  className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-black/70 hover:bg-amber-500 text-white hover:text-black transition-colors"
                  title="تصویر قبلی"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
                <button
                  onClick={handleNext}
                  className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-black/70 hover:bg-amber-500 text-white hover:text-black transition-colors"
                  title="تصویر بعدی"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
              </div>

              {/* Bottom Caption */}
              <div className="p-6 bg-[#111116] border-t border-white/10 text-right space-y-1">
                <h3 className="text-base font-bold text-white">{selectedItem.title}</h3>
                <p className="text-xs text-stone-400">{selectedItem.description}</p>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};
