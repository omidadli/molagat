import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Page, Dish } from '../types';
import { 
  MENU_CATEGORIES, 
  DISHES, 
  SALON_EXPERIENCES, 
  RESTAURANT_INFO, 
  VIP_CHAUFFEUR_OPTIONS, 
  LUXURY_GIFT_CARDS,
  WALKTHROUGH_STEPS 
} from '../data/restaurantData';
import { DishCard } from '../components/DishCard';
import { MolaqatLogo } from '../components/MolaqatLogo';

import facadeImg from '../assets/images/molaqat_hero_facade_1786224208172.jpg';
import interiorImg from '../assets/images/molaqat_interior_hall_1786224218757.jpg';
import filetImg from '../assets/images/molaqat_dish_filet_1786224230750.jpg';
import foieGrasImg from '../assets/images/molaqat_foie_gras_1786236101403.jpg';
import duckImg from '../assets/images/molaqat_duck_dish_1786236138172.jpg';
import salmonCaviarImg from '../assets/images/molaqat_salmon_caviar_1786236153159.jpg';
import dessertImg from '../assets/images/molaqat_dish_dessert_1786224242352.jpg';
import cheeseBoardImg from '../assets/images/molaqat_cheese_board_1786236113806.jpg';
import elixirImg from '../assets/images/molaqat_elixir_drink_1786236126492.jpg';
import chefImg from '../assets/images/molaqat_chef_art_1786224255487.jpg';
import terraceImg from '../assets/images/molaqat_terrace_night_1786236165643.jpg';

import { 
  Sparkles, 
  ChevronLeft, 
  ChevronRight, 
  Calendar, 
  Award, 
  ShieldCheck, 
  ArrowLeft, 
  Wine, 
  Clock, 
  Crown, 
  Car, 
  MapPin, 
  CheckCircle2, 
  PhoneCall, 
  Search, 
  Heart, 
  Star, 
  Plus, 
  ShoppingBag,
  Flame,
  Users,
  Compass,
  Gift,
  CreditCard,
  Utensils,
  Layers,
  Volume2
} from 'lucide-react';

interface HomePageProps {
  setCurrentPage: (page: Page) => void;
  onSelectDish: (dish: Dish) => void;
  onAddToCart: (dish: Dish) => void;
}

const HERO_SHOWCASE_DISHES = [
  {
    id: 'filet-mignon-truffe',
    persianTitle: 'فیله مینیون با سس ترافل سیاه و فلفل ماداگاسکار',
    frenchTitle: 'Filet Mignon Sauce Truffe Noire & Poivre Vert',
    persianSubtitle: 'راسته گوساله بلژیکی با پوره کره‌ای ژوئل روبوشون و ورق طلای ۲۴ عیار',
    price: '۳,۸۵۰,۰۰۰ تومان',
    dish: DISHES[0],
    image: filetImg,
    badge: 'شاهکار سرآشپز پیر لوران',
    accentColor: '#c5a059',
  },
  {
    id: 'foie-gras-poele',
    persianTitle: 'فوا گرا با انجیر کاراملی و ادویه اعلا',
    frenchTitle: 'Foie Gras Poêlé aux Figues et Pain d’Épices',
    persianSubtitle: 'جگر غاز اعلای پرودانس با سس احیاشده انگور و نان بریوش گرم',
    price: '۲,۹۵۰,۰۰۰ تومان',
    dish: DISHES[1],
    image: foieGrasImg,
    badge: 'اصالت گاسترونومی فرانسه',
    accentColor: '#d4af37',
  },
  {
    id: 'tartare-saumon-caviar',
    persianTitle: 'تارتار سالمون نروژ با خاویار امپریال بلوگا',
    frenchTitle: 'Tartare de Saumon Sauvage et Caviar Impérial',
    persianSubtitle: 'سالمون دست‌چین با آووکادو هاس و مرواریدهای خاویار خزر در ظرف یخ',
    price: '۳,۴۰۰,۰۰۰ تومان',
    dish: DISHES[2],
    image: salmonCaviarImg,
    badge: 'خاویار امپریال بلوگا',
    accentColor: '#38bdf8',
  },
  {
    id: 'magret-de-canard',
    persianTitle: 'سینه اردک برشته با عسل وحشی و شاه‌توت',
    frenchTitle: 'Magret de Canard Rôti au Miel et Épices Douces',
    persianSubtitle: 'سینه اردک بارباری با پوست کاراملی و پوره کدو حلوایی',
    price: '۳,۲۵۰,۰۰۰ تومان',
    dish: DISHES[3],
    image: duckImg,
    badge: 'کلاسیک جنوب فرانسه',
    accentColor: '#f97316',
  },
];

export const HomePage: React.FC<HomePageProps> = ({
  setCurrentPage,
  onSelectDish,
  onAddToCart,
}) => {
  const [activeHeroIdx, setActiveHeroIdx] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGiftCard, setSelectedGiftCard] = useState<string>('carte-or');

  // Auto rotate hero dish showcase
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveHeroIdx((prev) => (prev + 1) % HERO_SHOWCASE_DISHES.length);
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  const currentHero = HERO_SHOWCASE_DISHES[activeHeroIdx];

  const filteredDishes = DISHES.filter((dish) => {
    const matchesCategory = selectedCategory === 'all' || dish.category === selectedCategory;
    const matchesSearch = searchQuery === '' || 
      dish.persianName.includes(searchQuery) || 
      dish.frenchName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dish.description.includes(searchQuery);
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="w-full relative overflow-hidden bg-[#08080b] text-[#f5ecd7]">

      {/* =========================================================================
          1. HERO SECTION WITH CONTEXTUAL MANSION FACADE BACKGROUND & GLASS OVERLAY
          ========================================================================= */}
      <section className="relative min-h-[95vh] flex items-center justify-center pt-28 sm:pt-36 pb-20 px-4 sm:px-6 lg:px-12 overflow-hidden">
        
        {/* Contextual High-Resolution Background Image of Mansion */}
        <div className="absolute inset-0 z-0">
          <img
            src={facadeImg}
            alt="Molaqat Grand Mansion"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover filter brightness-[0.38] contrast-110 scale-105"
          />
          {/* Frosted Dark Glass Layer */}
          <div className="absolute inset-0 bg-gradient-to-b from-[#09080c]/85 via-[#09080c]/70 to-[#08080b] backdrop-blur-[6px]"></div>
        </div>

        {/* Ambient Glowing Highlights */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
          <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-amber-500/15 rounded-full blur-[140px]"></div>
          <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-orange-600/10 rounded-full blur-[120px]"></div>
        </div>

        <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
          
          {/* RIGHT COLUMN (in RTL): Big Bold Headline & Service CTAs */}
          <div className="lg:col-span-6 space-y-7 text-right">
            
            {/* Top Luxury Pill with Transparent Logo Emblem */}
            <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-white/[0.06] border border-amber-500/30 text-xs font-semibold text-white backdrop-blur-xl shadow-[0_0_25px_rgba(245,158,11,0.2)]">
              <MolaqatLogo size={20} variant="gold" />
              <span>عمارت اشرافی ملاقات • مشهد، بلوار سجاد</span>
              <span className="text-amber-400">✦</span>
              <span className="text-[11px] font-bold text-amber-300 font-latin">Haute Gastronomie</span>
            </div>

            {/* Bold Hero Headline */}
            <div className="space-y-3">
              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white leading-[1.25] tracking-tight">
                شکوه و اصالت <br />
                <span className="bg-gradient-to-r from-amber-400 via-amber-200 to-yellow-500 bg-clip-text text-transparent">
                  آشپزی ۳ ستاره میشلن
                </span> <br />
                <span className="text-white">در قلب مشهد</span>
              </h1>
              <p className="text-stone-300 text-sm sm:text-base leading-relaxed max-w-xl">
                تجربه ضیافت در فضایی شیشه‌ای و رویایی با نوای زنده پیانو، شاهکارهای آشپزی سرآشپز پیر لوران و سرویس ترانسفر اختصاصی با رانندگان تشریفاتی در سراسر مشهد.
              </p>
            </div>

            {/* Service & Delivery Info Strip in Frosted Glass */}
            <div className="grid grid-cols-3 gap-3 p-4 rounded-3xl bg-white/[0.05] border border-white/10 backdrop-blur-2xl text-xs shadow-2xl">
              <div className="text-right border-l border-white/10 pl-2">
                <div className="text-stone-400 text-[10px]">ساعات پذیرایی:</div>
                <div className="font-bold text-white mt-0.5">۱۹:۳۰ الی ۰۰:۳۰</div>
              </div>
              <div className="text-right border-l border-white/10 pl-2">
                <div className="text-stone-400 text-[10px]">موقعیت عمارت:</div>
                <div className="font-bold text-white mt-0.5">مشهد، بلوار سجاد</div>
              </div>
              <div className="text-right">
                <div className="text-stone-400 text-[10px]">تماس تشریفات:</div>
                <div className="font-bold text-amber-300 font-mono mt-0.5">۰۵۱-۳۷۶۵۹۹۸۸</div>
              </div>
            </div>

            {/* Dual CTA Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-1">
              <button
                id="hero-reserve-btn"
                onClick={() => setCurrentPage('reservation')}
                className="px-8 py-3.5 rounded-full bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 hover:from-amber-400 hover:to-orange-600 text-black font-black text-sm flex items-center gap-2.5 shadow-[0_0_30px_rgba(245,158,11,0.4)] hover:scale-105 transition-all duration-300"
              >
                <Calendar className="w-4 h-4" />
                <span>رزرو اختصاصی میز و سالن</span>
              </button>

              <button
                id="hero-menu-btn"
                onClick={() => setCurrentPage('menu')}
                className="px-7 py-3.5 rounded-full bg-white/[0.06] hover:bg-white/[0.12] text-white border border-white/15 hover:border-amber-400/50 font-bold text-sm flex items-center gap-2 transition-all duration-300 shadow-lg backdrop-blur-xl"
              >
                <span>مشاهده منوی کامل</span>
                <ArrowLeft className="w-4 h-4 text-amber-400" />
              </button>
            </div>

            {/* Trust Badges */}
            <div className="flex items-center gap-6 pt-2 text-xs text-stone-400">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>گواهی حلال ۱۰۰٪ بین‌المللی</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Crown className="w-4 h-4 text-amber-400" />
                <span>مواد اولیه دست‌چین پرودانس و زاگرس</span>
              </div>
            </div>

          </div>

          {/* LEFT COLUMN: Hero Platter Showcase with Modern Frosted Glass Disc */}
          <div className="lg:col-span-6 flex flex-col items-center justify-center relative">
            
            {/* Center Stage Glowing Aura */}
            <div className="absolute inset-0 bg-radial from-amber-500/20 via-transparent to-transparent blur-3xl pointer-events-none"></div>

            {/* Circular Stage */}
            <div className="relative w-72 h-72 sm:w-96 sm:h-96 flex items-center justify-center">
              
              {/* Outer Golden Glow Ring */}
              <div 
                className="absolute -inset-4 rounded-full border-2 border-transparent border-t-amber-400 border-r-orange-500 border-b-transparent animate-spin"
                style={{ animationDuration: '12s' }}
              ></div>

              {/* Secondary dashed ring */}
              <div 
                className="absolute -inset-8 rounded-full border border-dashed border-white/15 animate-spin"
                style={{ animationDuration: '24s', animationDirection: 'reverse' }}
              ></div>

              {/* Stable Food Photo Frame */}
              <div 
                className="relative z-10 w-full h-full rounded-full overflow-hidden p-2.5 bg-gradient-to-b from-white/15 via-[#1a171e]/90 to-[#0a090e] border-2 border-amber-400/40 shadow-[0_30px_90px_rgba(0,0,0,0.98)] cursor-pointer backdrop-blur-2xl"
                onClick={() => onSelectDish(currentHero.dish)}
              >
                <img
                  src={currentHero.image}
                  alt={currentHero.frenchTitle}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover rounded-full transition-transform duration-700 hover:scale-105"
                />
              </div>

              {/* Floating Signature Badge */}
              <div className="absolute -top-3 right-4 z-20 px-4 py-1.5 rounded-full bg-black/85 border border-amber-400/50 text-[11px] font-bold text-amber-200 backdrop-blur-xl shadow-2xl flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>{currentHero.badge}</span>
              </div>

              {/* Floating Price Pill */}
              <div className="absolute -bottom-4 left-6 z-20 px-4 py-1.5 rounded-full bg-[#121118]/95 border border-white/20 text-xs font-black text-amber-300 font-mono backdrop-blur-xl shadow-2xl">
                {currentHero.price}
              </div>
            </div>

            {/* Showcase Selector Tabs (4 Hero Dishes) */}
            <div className="mt-8 flex items-center gap-2 flex-wrap justify-center relative z-10">
              {HERO_SHOWCASE_DISHES.map((item, idx) => (
                <button
                  key={item.id}
                  onClick={() => setActiveHeroIdx(idx)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-all duration-300 flex items-center gap-2 border backdrop-blur-xl ${
                    activeHeroIdx === idx
                      ? 'bg-amber-500/30 border-amber-400 text-white shadow-[0_0_20px_rgba(245,158,11,0.35)] scale-105'
                      : 'bg-white/[0.05] border-white/10 text-stone-400 hover:text-white'
                  }`}
                >
                  <img 
                    src={item.image} 
                    alt={item.persianTitle} 
                    referrerPolicy="no-referrer"
                    className="w-5 h-5 rounded-full object-cover" 
                  />
                  <span>{item.persianTitle.split(' ')[0]} {item.persianTitle.split(' ')[1]}</span>
                </button>
              ))}
            </div>

          </div>

        </div>

      </section>

      {/* =========================================================================
          2. LUXURY DARK GLASSMORPHISM SECTION (شاهکارهای منوی سرآشپز پیر لوران)
          Deep Dark Obsidian with Frosted Glass Cards, Glowing Badges & Modern Accents
          ========================================================================= */}
      <section className="py-24 px-4 sm:px-6 lg:px-12 bg-[#0d0c13] text-white relative overflow-hidden border-t border-b border-white/10">
        
        {/* Dynamic Ambient Warm Golden/Orange Light Orbs (Matching Reference UI) */}
        <div className="absolute -top-32 right-1/4 w-[600px] h-[600px] bg-amber-500/10 rounded-full blur-[160px] pointer-events-none" />
        <div className="absolute -bottom-32 left-1/4 w-[500px] h-[500px] bg-orange-600/10 rounded-full blur-[140px] pointer-events-none" />

        <div className="max-w-7xl mx-auto space-y-12 relative z-10">
          
          {/* Section Header & Quick Search Bar */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 border-b border-white/10 pb-8">
            <div className="space-y-2 text-right">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/15 border border-amber-400/30 text-xs font-bold text-amber-300 backdrop-blur-md">
                <Utensils className="w-3.5 h-3.5 text-amber-400" />
                <span>کارت منوی فاخر ۳ ستاره میشلن</span>
              </div>
              <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
                شاهکارهای آشپزی فرانسوی عمارت ملاقات
              </h2>
              <p className="text-xs sm:text-sm text-stone-300">
                هر بشقاب به همراه گالری تصاویر زوایای مختلف، جدول کالری و گزینه‌های شخصی‌سازی اختصاصی
              </p>
            </div>

            {/* Quick Search Input (Glassmorphic) */}
            <div className="w-full md:w-72 relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="جستجو در بشقاب‌ها و مواد اولیه..."
                className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white/[0.06] border border-white/10 text-xs text-white placeholder-stone-400 backdrop-blur-xl focus:outline-none focus:border-amber-400 transition-all"
              />
              <Search className="w-4 h-4 text-amber-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          {/* =========================================================================
              FEATURED CHEF'S COMBO / PROMO BANNER (Inspired by Reference UI)
              ========================================================================= */}
          <div className="relative rounded-[36px] bg-gradient-to-r from-amber-500/15 via-white/[0.05] to-orange-500/10 border border-white/15 p-6 sm:p-8 backdrop-blur-3xl overflow-hidden shadow-[0_25px_60px_rgba(0,0,0,0.7)] flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="space-y-4 text-right max-w-lg relative z-10">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-500/20 border border-orange-400/40 text-orange-300 text-[11px] font-extrabold">
                <Flame className="w-3.5 h-3.5 text-orange-400" />
                <span>پیشنهاد ویژه افتتاحیه • ضیافت ۵ پرده‌ای سرآشپز</span>
              </div>
              
              <h3 className="text-xl sm:text-3xl font-black text-white leading-tight">
                پکیج رویال فیله مینیون و خاویار بلوگا
              </h3>
              
              <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
                همراه با دسر شوکولات ارگانیک والورونا، اکسیر گیاهی و ترانسفر رایگان رفت و برگشت با ب‌ام‌و سری ۷ در مشهد
              </p>

              <div className="flex items-center gap-4 pt-2">
                <button
                  onClick={() => setCurrentPage('reservation')}
                  className="px-7 py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 text-black font-black text-xs shadow-[0_4px_25px_rgba(245,158,11,0.4)] hover:scale-105 transition-all"
                >
                  رزرو ضیافت اختصاصی
                </button>
                <div className="flex items-center gap-2">
                  <span className="text-xs line-through text-stone-500 font-mono">۴,۹۰۰,۰۰۰</span>
                  <span className="text-sm sm:text-base font-black text-amber-300 font-mono">۳,۹۲۰,۰۰۰ تومان</span>
                  <span className="px-2 py-0.5 rounded-full bg-red-500/20 border border-red-500/40 text-red-300 text-[10px] font-bold">۲۰٪ تخفیف</span>
                </div>
              </div>
            </div>

            {/* Visual Platter Floating Graphic */}
            <div className="relative w-48 h-48 sm:w-60 sm:h-60 rounded-full flex-shrink-0 flex items-center justify-center">
              <div className="absolute inset-0 bg-radial from-amber-500/30 via-transparent to-transparent blur-2xl pointer-events-none" />
              <div className="relative z-10 w-full h-full rounded-full p-2 bg-gradient-to-b from-white/20 via-black/50 to-black/90 border-2 border-amber-400/50 shadow-[0_20px_50px_rgba(0,0,0,0.9)] overflow-hidden">
                <img
                  src={filetImg}
                  alt="Filet Mignon"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
            </div>
          </div>

          {/* Category Navigation Bar (Modern Frosted Glass Pills) */}
          <div className="flex items-center justify-between gap-4 flex-wrap border-b border-white/10 pb-4">
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
              <button
                onClick={() => setSelectedCategory('all')}
                className={`px-4 py-2.5 rounded-2xl text-xs font-bold transition-all whitespace-nowrap backdrop-blur-xl border ${
                  selectedCategory === 'all'
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-black border-amber-400 font-extrabold shadow-lg shadow-amber-500/25 scale-105'
                    : 'bg-white/[0.04] text-stone-300 hover:text-white border-white/10 hover:bg-white/[0.08]'
                }`}
              >
                همه بشقاب‌ها ({DISHES.length})
              </button>
              {MENU_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-4 py-2.5 rounded-2xl text-xs font-bold transition-all whitespace-nowrap backdrop-blur-xl border flex items-center gap-2 ${
                    selectedCategory === cat.id
                      ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-black border-amber-400 font-extrabold shadow-lg shadow-amber-500/25 scale-105'
                      : 'bg-white/[0.04] text-stone-300 hover:text-white border-white/10 hover:bg-white/[0.08]'
                  }`}
                >
                  <span>{cat.persianTitle}</span>
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 text-xs text-stone-400">
              <span className="text-amber-400">✦</span>
              <span>نمایش {filteredDishes.length} بشقاب منتخب</span>
            </div>
          </div>

          {/* Dish Grid with Modern Glassmorphic Cards (Exact style from Reference UI) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredDishes.slice(0, 8).map((dish) => (
              <DishCard
                key={dish.id}
                dish={dish}
                onSelectDish={onSelectDish}
                onAddToCart={onAddToCart}
              />
            ))}
          </div>

          {/* View Full Menu CTA Button */}
          <div className="text-center pt-4">
            <button
              onClick={() => {
                setCurrentPage('menu');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-8 py-3.5 rounded-2xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/15 hover:border-amber-400/50 text-white hover:text-amber-300 text-xs sm:text-sm font-bold inline-flex items-center gap-2.5 shadow-xl transition-all backdrop-blur-xl"
            >
              <span>مشاهده و سفارش از تمام دسته‌بندی‌های منو ({DISHES.length} بشقاب فاخر)</span>
              <ArrowLeft className="w-4 h-4 text-amber-400" />
            </button>
          </div>

        </div>
      </section>

      {/* =========================================================================
          3. VIP CHAUFFEUR & PRIVATE TRANSFER (Nocturnal Dark Sapphire Glassmorphism)
          ========================================================================= */}
      <section className="py-24 px-4 sm:px-6 lg:px-12 bg-[#090b12] text-white border-t border-white/10 relative overflow-hidden">
        
        {/* Ambient Dark Aura */}
        <div className="absolute top-1/2 -right-40 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-7xl mx-auto space-y-12 relative z-10">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-500/15 border border-blue-400/30 text-xs font-bold text-blue-300 backdrop-blur-md">
              <Car className="w-3.5 h-3.5 text-blue-400" />
              <span>خدمات ترانسفر اختصاصی در سراسر مشهد</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white">
              سرویس شوفر و خودروهای تشریفات عمارت ملاقات
            </h2>
            <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
              برای مهمانان گرامی عمارت، امکان انتقال رفت و برگشت از درب منزل، هتل‌های ۵ ستاره یا فرودگاه با ب‌ام‌و سری ۷ و مرسدس بنز اس کلاس با رانندگان ملبس به لباس تشریفات رسمی مهیاست.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {VIP_CHAUFFEUR_OPTIONS.map((car) => (
              <div 
                key={car.id}
                className="rounded-[32px] bg-white/[0.04] border border-white/10 hover:border-blue-400/40 p-6 sm:p-8 flex flex-col justify-between space-y-6 backdrop-blur-2xl shadow-[0_20px_50px_rgba(0,0,0,0.6)] transition-all group"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-blue-500/20 border border-blue-400/40 flex items-center justify-center text-blue-300 shadow-md">
                        <Car className="w-6 h-6" />
                      </div>
                      <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-blue-300 transition-colors">
                        {car.name}
                      </h3>
                    </div>
                    <span className="text-xs font-mono font-bold text-amber-300 bg-black/60 px-3.5 py-1.5 rounded-full border border-white/10">
                      {car.formattedPrice}
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
                    {car.description}
                  </p>

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-stone-400">
                    <div className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
                      <span>راننده تشریفات مسلط به زبان</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
                      <span>پذیرایی نوشیدنی داخل خودرو</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
                      <span>پوشش کامل تمام مناطق مشهد</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
                      <span>پارکینگ و ولت VIP درب عمارت</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setCurrentPage('reservation')}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-blue-600/30 to-indigo-600/30 hover:from-blue-600/50 hover:to-indigo-600/50 border border-blue-400/40 text-blue-200 text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-lg"
                >
                  <span>انتخاب این خودرو در فرم رزرو</span>
                  <ArrowLeft className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* =========================================================================
          4. PRIVATE SALONS & VERSAILLES ATMOSPHERE (Deep Obsidian & Frosted Glass)
          ========================================================================= */}
      <section className="py-24 px-4 sm:px-6 lg:px-12 bg-[#09080e] text-white border-t border-white/10 relative overflow-hidden">
        
        {/* Ambient Warm Golden/Amber Glow */}
        <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-[160px] pointer-events-none" />

        <div className="max-w-7xl mx-auto space-y-12 relative z-10">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/15 border border-amber-400/30 text-xs font-bold text-amber-300 backdrop-blur-md">
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              <span>فضاهای اختصاصی و ضیافت‌های خصوصی</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              تالارها و سالن‌های VIP عمارت ملاقات
            </h2>
            <p className="text-xs sm:text-sm text-stone-300">
              از تالار مرکزی ورسای با لوسترهای باکارای قرن نوزدهم تا سالن الماس با ورودی مجزا از باغ برای قرارهای محرمانه
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {SALON_EXPERIENCES.map((salon) => (
              <div 
                key={salon.id}
                className="rounded-[32px] bg-gradient-to-b from-white/[0.08] via-white/[0.03] to-black/60 border border-white/15 hover:border-amber-400/60 overflow-hidden flex flex-col justify-between shadow-[0_20px_50px_rgba(0,0,0,0.7)] hover:shadow-[0_25px_60px_rgba(245,158,11,0.25)] transition-all group backdrop-blur-2xl"
              >
                <div className="relative h-60 w-full overflow-hidden">
                  <img
                    src={salon.image}
                    alt={salon.persianName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  <div className="absolute top-4 right-4 px-3.5 py-1.5 rounded-full bg-black/75 backdrop-blur-md border border-white/20 text-xs font-bold text-white shadow-lg">
                    {salon.capacity}
                  </div>
                </div>

                <div className="p-6 space-y-4 text-right">
                  <div>
                    <span className="text-[11px] font-latin font-bold text-amber-400">{salon.frenchName}</span>
                    <h3 className="text-lg font-black text-white mt-0.5">{salon.persianName}</h3>
                  </div>

                  <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
                    {salon.description}
                  </p>

                  <div className="space-y-1.5 pt-3 border-t border-white/10 text-xs text-stone-300">
                    {salon.features.map((feat, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <span className="text-amber-400">✦</span>
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>

                  <div className="p-3 rounded-2xl bg-white/[0.04] border border-white/10 text-xs text-stone-300">
                    مناسب برای: {salon.recommendedFor}
                  </div>

                  <button
                    onClick={() => setCurrentPage('reservation')}
                    className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black font-black text-xs shadow-[0_4px_20px_rgba(245,158,11,0.35)] transition-all"
                  >
                    رزرو این سالن اختصاصی
                  </button>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* =========================================================================
          5. BLACK CARD VIP & BESPOKE GIFT INVITATIONS (Frosted Dark Glass)
          ========================================================================= */}
      <section className="py-24 px-4 sm:px-6 lg:px-12 bg-[#0a090e] border-t border-white/10 relative">
        <div className="max-w-7xl mx-auto space-y-12">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            {/* Left Column: Molaqat Black Card Club */}
            <div className="lg:col-span-6 space-y-6 text-right">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/15 border border-amber-400/30 text-xs font-bold text-amber-200">
                <CreditCard className="w-3.5 h-3.5 text-amber-400" />
                <span>باشگاه نخبگان و بلک کارت ملاقات</span>
              </div>

              <h2 className="text-2xl sm:text-4xl font-extrabold text-white leading-tight">
                عضویت اختصاصی در کلوپ اشرافی عمارت
              </h2>

              <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
                کلوپ VIP ملاقات ویژه مدیران ارشد، پزشکان برجسته و نخبگان مشهد طراحی شده است. دارندگان این کارت از اولویت رزرو سالن ورسای در شب‌های شلوغ، پیشخدمت شخصی، خاویار بار هدیه در سالگردها و خط مستقیم با سرآشپز بهره‌مند می‌شوند.
              </p>

              {/* VIP Card Graphic with Custom Logo */}
              <div className="relative w-full max-w-md rounded-[32px] p-7 bg-gradient-to-br from-[#2a241b] via-[#15131a] to-[#0a090e] border-2 border-amber-400/50 shadow-[0_25px_60px_rgba(0,0,0,0.9)] space-y-6 overflow-hidden">
                <div className="absolute top-0 right-0 w-36 h-36 bg-amber-500/15 rounded-full blur-2xl"></div>
                <div className="flex items-center justify-between relative z-10">
                  <div className="text-right">
                    <span className="text-[10px] text-amber-400 uppercase tracking-widest block font-bold font-latin">MOLAQAṮ CLUB</span>
                    <span className="text-xs font-bold text-white">کارت عضویت طلایی عمارت</span>
                  </div>
                  <MolaqatLogo size={36} variant="gold" />
                </div>

                <div className="py-2 relative z-10">
                  <div className="font-mono text-base sm:text-lg text-amber-200 tracking-widest">
                    •••• •••• •••• ۷۷۸۸
                  </div>
                  <div className="text-[10px] text-stone-400 mt-1">MEMBER SINCE 2026 • VIP PATRON</div>
                </div>

                <div className="flex items-center justify-between text-[11px] border-t border-white/10 pt-3 text-amber-300 relative z-10">
                  <span>مشهد • بلوار سجاد</span>
                  <span className="font-latin font-bold">HAUTE GASTRONOMIE</span>
                </div>
              </div>

            </div>

            {/* Right Column: Luxury Velvet Gift Card Boxes */}
            <div className="lg:col-span-6 space-y-6 text-right">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-red-500/15 border border-red-400/30 text-xs font-bold text-red-300">
                <Gift className="w-3.5 h-3.5 text-red-400" />
                <span>کارت هدیه ضیافت اشرافی (Luxury Gift Invitation)</span>
              </div>

              <h3 className="text-xl sm:text-2xl font-bold text-white">
                هدیه‌ای شاهانه برای شرکای تجاری و عزیزان
              </h3>

              <div className="space-y-4">
                {LUXURY_GIFT_CARDS.map((card) => (
                  <div 
                    key={card.id}
                    onClick={() => setSelectedGiftCard(card.id)}
                    className={`rounded-2xl border p-5 cursor-pointer transition-all ${
                      selectedGiftCard === card.id
                        ? 'bg-amber-950/20 border-amber-400 shadow-[0_0_25px_rgba(245,158,11,0.25)]'
                        : 'bg-white/[0.04] border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center justify-between border-b border-white/10 pb-3">
                      <div>
                        <h4 className="text-sm font-bold text-white">{card.title}</h4>
                        <span className="text-[10px] font-latin text-amber-400">{card.frenchTitle}</span>
                      </div>
                      <span className="text-sm font-black text-amber-300 font-mono">
                        {card.formattedAmount}
                      </span>
                    </div>

                    <p className="text-[11px] text-stone-400 mt-2.5">
                      بسته‌بندی: {card.packaging}
                    </p>

                    <div className="space-y-1 mt-3 text-[11px] text-stone-300">
                      {card.perks.map((perk, idx) => (
                        <div key={idx} className="flex items-center gap-1.5">
                          <CheckCircle2 className="w-3 h-3 text-amber-400" />
                          <span>{perk}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <button
                onClick={() => setCurrentPage('contact')}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 text-black font-black text-xs shadow-xl hover:scale-105 transition-all"
              >
                سفارش و تحویل کارت هدیه با پیک تشریفات در مشهد
              </button>

            </div>

          </div>

        </div>
      </section>

      {/* =========================================================================
          6. ATMOSPHERE WALKTHROUGH JOURNEY (Modern Frosted Glass Cards)
          ========================================================================= */}
      <section className="py-24 px-4 sm:px-6 lg:px-12 bg-[#060609] border-t border-white/10 relative">
        <div className="max-w-7xl mx-auto space-y-12">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/[0.06] border border-white/15 text-xs font-bold text-amber-300">
              <Compass className="w-3.5 h-3.5 text-amber-400" />
              <span>روایت ۴ پرده‌ای از یک شب در عمارت</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white">
              سفر حسی شما در شب‌های ملاقات
            </h2>
            <p className="text-xs sm:text-sm text-stone-400">
              از لحظه ورود به محوطه اختصاصی سجاد تا بدرقه گرم با خاطره‌ای جاودان
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {WALKTHROUGH_STEPS.map((step) => (
              <div 
                key={step.id}
                className="rounded-[28px] bg-white/[0.04] border border-white/10 overflow-hidden flex flex-col justify-between shadow-2xl hover:border-amber-400/50 backdrop-blur-2xl transition-all group"
              >
                <div className="relative h-44 w-full overflow-hidden">
                  <img
                    src={step.image}
                    alt={step.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/80 border border-amber-400 flex items-center justify-center text-xs font-bold text-amber-300 shadow-md">
                    {step.id}
                  </div>
                </div>

                <div className="p-5 space-y-3 text-right">
                  <div>
                    <span className="text-[10px] font-latin font-bold text-amber-400">{step.frenchTitle}</span>
                    <h3 className="text-sm font-bold text-white">{step.title}</h3>
                  </div>

                  <p className="text-xs text-stone-400 leading-relaxed">
                    {step.persianDescription}
                  </p>

                  <div className="p-2.5 rounded-2xl bg-black/40 border border-white/5 text-[10px] text-amber-300">
                    ✦ {step.highlightText}
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

    </div>
  );
};
