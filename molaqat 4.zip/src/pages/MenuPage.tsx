import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Page, Dish, MenuCategoryId } from '../types';
import { MENU_CATEGORIES, DISHES } from '../data/restaurantData';
import { DishCard } from '../components/DishCard';
import { CategoryIcon } from '../components/CategoryIcon';
import { MolaqatLogo } from '../components/MolaqatLogo';
import { useFavorites } from '../context/FavoritesContext';
import { 
  Search, 
  Sparkles, 
  SlidersHorizontal, 
  ArrowRight, 
  Utensils, 
  Check, 
  Star, 
  Award, 
  Flame, 
  Clock,
  Wine,
  ShieldCheck,
  ChevronLeft,
  Heart
} from 'lucide-react';

import interiorImg from '../assets/images/molaqat_interior_hall_1786224218757.jpg';

interface MenuPageProps {
  setCurrentPage: (page: Page) => void;
  onSelectDish: (dish: Dish) => void;
  onAddToCart: (dish: Dish) => void;
}

export const MenuPage: React.FC<MenuPageProps> = ({
  setCurrentPage,
  onSelectDish,
  onAddToCart,
}) => {
  const { favorites, isFavorite } = useFavorites();
  const [activeCategory, setActiveCategory] = useState<MenuCategoryId | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | 'all'>('all');

  const filterTags = [
    { id: 'all', label: 'همه بشقاب‌ها' },
    { id: 'favorites', label: `علاقه‌مندی‌های من (${favorites.length})` },
    { id: 'signature', label: 'امضای سرآشپز پیر لوران' },
    { id: 'halal', label: 'حلال ۱۰۰٪' },
    { id: 'gluten-free', label: 'بدون گلوتن' },
    { id: 'dessert', label: 'هنر قنادی والورونا' },
  ];

  const filteredDishes = DISHES.filter((dish) => {
    const matchesCategory = activeCategory === 'all' || dish.category === activeCategory;
    const matchesSearch =
      searchQuery === '' ||
      dish.persianName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dish.frenchName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dish.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dish.ingredients.some((ing) => ing.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesTag =
      selectedTag === 'all' ||
      (selectedTag === 'favorites' && isFavorite(dish.id)) ||
      (selectedTag === 'signature' && dish.isSignature) ||
      (selectedTag === 'halal' && dish.dietaryTags.some((t) => t.includes('حلال'))) ||
      (selectedTag === 'gluten-free' && dish.dietaryTags.some((t) => t.includes('گلوتن'))) ||
      (selectedTag === 'dessert' && dish.category === 'desserts');

    return matchesCategory && matchesSearch && matchesTag;
  });

  const activeCategoryObj = MENU_CATEGORIES.find((c) => c.id === activeCategory);

  return (
    <div className="w-full relative overflow-hidden bg-[#09080c] text-white">

      {/* =========================================================================
          HERO & MENU DISHES WITH CONTEXTUAL GASTRONOMY BACKGROUND IMAGE & FROSTED GLASS
          ========================================================================= */}
      <div className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-10 text-right z-10">
        
        {/* Contextual Background Image with Frosted Glass Overlay */}
        <div className="fixed inset-0 z-0 pointer-events-none">
          <img
            src="https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=1600&auto=format&fit=crop"
            alt="Culinary background"
            className="w-full h-full object-cover filter brightness-[0.25] contrast-125"
          />
          <div className="absolute inset-0 bg-[#09080c]/80 backdrop-blur-md"></div>
        </div>

        {/* Page Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 relative z-10">
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-white/[0.06] border border-amber-500/30 text-xs font-bold text-white backdrop-blur-xl shadow-lg">
            <MolaqatLogo size={20} variant="gold" />
            <span>منوی اصیل گاسترونومی ۳ ستاره فرانسه</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
            کارت منوی فاخر عمارت ملاقات
          </h1>
          <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
            هر بشقاب، جلوه‌ای از خلاقیت سرآشپز پیر لوران با نایاب‌ترین مواد اولیه ارگانیک پرودانس و بافت‌های شگفت‌انگیز
          </p>
        </div>

        {/* =========================================================================
            CATEGORY NAVIGATION (Modern Glassmorphic Capsules inspired by Image 2)
            ========================================================================= */}
        <div className="space-y-4 relative z-10">
          <div className="flex items-center justify-center gap-3 sm:gap-4 overflow-x-auto pb-4 pt-2 no-scrollbar">
            
            {/* "All" Category Pill */}
            <button
              onClick={() => setActiveCategory('all')}
              className={`flex items-center gap-3 px-5 py-3 rounded-2xl border backdrop-blur-2xl transition-all duration-300 flex-shrink-0 ${
                activeCategory === 'all'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-black border-amber-400 font-extrabold shadow-lg shadow-amber-500/25 scale-105'
                  : 'bg-white/[0.04] text-stone-300 hover:text-white border-white/10 hover:bg-white/[0.08]'
              }`}
            >
              <Utensils className={`w-4 h-4 ${activeCategory === 'all' ? 'text-black' : 'text-amber-400'}`} />
              <div className="text-right">
                <span className="text-xs font-bold block">تمام منو</span>
                <span className={`text-[10px] font-latin ${activeCategory === 'all' ? 'text-black/80' : 'text-stone-500'}`}>
                  Tout le Menu
                </span>
              </div>
            </button>

            {/* Individual Categories */}
            {MENU_CATEGORIES.map((cat) => {
              const isSelected = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  id={`cat-btn-${cat.id}`}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`flex items-center gap-3 px-4 py-2.5 rounded-2xl border backdrop-blur-2xl transition-all duration-300 flex-shrink-0 ${
                    isSelected
                      ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-black border-amber-400 font-extrabold shadow-lg shadow-amber-500/25 scale-105'
                      : 'bg-white/[0.04] text-stone-300 hover:text-white border-white/10 hover:bg-white/[0.08]'
                  }`}
                >
                  <div className="w-8 h-8 rounded-full overflow-hidden border border-white/20 flex-shrink-0">
                    <img
                      src={cat.thumbnail}
                      alt={cat.frenchTitle}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold block">{cat.persianTitle}</span>
                    <span className={`text-[10px] font-latin ${isSelected ? 'text-black/80' : 'text-stone-500'}`}>
                      {cat.frenchTitle}
                    </span>
                  </div>
                </button>
              );
            })}

          </div>

          {/* Active Category Description Banner */}
          <AnimatePresence mode="wait">
            {activeCategoryObj && (
              <motion.div
                key={activeCategoryObj.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.25 }}
                className="p-4 rounded-3xl bg-white/[0.05] border border-amber-500/30 backdrop-blur-2xl text-center max-w-2xl mx-auto flex items-center justify-center gap-3 shadow-xl"
              >
                <div className="p-2 rounded-2xl bg-amber-500/20 text-amber-300">
                  <CategoryIcon name={activeCategoryObj.icon3D} className="w-5 h-5" />
                </div>
                <div className="text-right">
                  <h3 className="text-sm font-bold text-white">
                    {activeCategoryObj.persianTitle} ({activeCategoryObj.frenchTitle})
                  </h3>
                  <p className="text-xs text-stone-300 mt-0.5">{activeCategoryObj.persianSubtitle}</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* =========================================================================
            SEARCH & FILTER TOOLBAR (Modern Glass Capsule)
            ========================================================================= */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-white/[0.04] backdrop-blur-2xl p-4 rounded-3xl border border-white/10 relative z-10 shadow-2xl">
          
          {/* Search Field */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-amber-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="جستجوی غذا، ترافل، خاویار، سالمون..."
              className="w-full pr-10 pl-4 py-2.5 rounded-2xl bg-black/40 border border-white/10 text-xs text-white placeholder-stone-500 focus:outline-none focus:border-amber-400 transition-colors"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto no-scrollbar pb-1">
            {filterTags.map((tag) => {
              const isTagActive = selectedTag === tag.id;
              return (
                <button
                  key={tag.id}
                  onClick={() => setSelectedTag(tag.id)}
                  className={`px-3.5 py-1.5 rounded-2xl text-xs font-semibold whitespace-nowrap transition-all ${
                    isTagActive
                      ? 'bg-amber-500 text-black font-black shadow-md'
                      : 'bg-white/[0.05] hover:bg-white/[0.1] text-stone-300 border border-white/10'
                  }`}
                >
                  {tag.label}
                </button>
              );
            })}
          </div>

        </div>

        {/* =========================================================================
            DISHES GRID (Modern Frosted Glass Cards with Stepper & Rating)
            ========================================================================= */}
        <div className="space-y-6 relative z-10">
          <div className="flex items-center justify-between text-xs text-stone-400 border-b border-white/10 pb-3">
            <span>نمایش {filteredDishes.length} بشقاب دست‌ساز سرآشپز</span>
            <span>بهای تشریفات به تومان با سرویس کامل عمارت</span>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={`${activeCategory}-${selectedTag}-${searchQuery}`}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -18 }}
              transition={{ duration: 0.3 }}
            >
              {filteredDishes.length === 0 ? (
                <div className="text-center py-16 space-y-3 bg-white/[0.03] rounded-3xl border border-white/10 backdrop-blur-xl">
                  <Utensils className="w-10 h-10 text-stone-500 mx-auto" />
                  <h3 className="text-base font-bold text-white">بشقابی با این مشخصات یافت نشد</h3>
                  <p className="text-xs text-stone-400">لطفاً عبارت جستجو یا فیلترهای اعمال شده را تغییر دهید.</p>
                  <button
                    onClick={() => {
                      setActiveCategory('all');
                      setSelectedTag('all');
                      setSearchQuery('');
                    }}
                    className="px-4 py-2 rounded-2xl bg-amber-500 text-black text-xs font-bold shadow-md hover:brightness-110 transition-all"
                  >
                    نمایش تمام منو
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                  {filteredDishes.map((dish) => (
                    <DishCard
                      key={dish.id}
                      dish={dish}
                      onSelectDish={onSelectDish}
                      onAddToCart={onAddToCart}
                    />
                  ))}
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

      </div>

      {/* =========================================================================
          WHITE LUXURY DEGUSTATION COURSE SECTION (Pristine White Background Contrast)
          ========================================================================= */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-[#faf8f5] text-stone-900 border-t-2 border-stone-200 relative z-20">
        <div className="max-w-7xl mx-auto space-y-10 text-right">
          
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-100 border border-amber-300 text-xs font-bold text-amber-900 shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-amber-700" />
              <span>دگوستاسیون اختصاصی ۷ مرحله‌ای</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-stone-900">
              سفره تست شاهانه سرآشپز (Menu Dégustation)
            </h2>
            <p className="text-xs sm:text-sm text-stone-600">
              سفری بی‌همتا در هنر ذائقه فرانسوی با ۷ شاهکار پیاپی، دسر دست‌ساز و معجون‌های ارگانیک
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: 'دگوستاسیون نقره‌ای ۵ مرحله‌ای',
                french: 'Menu Découverte 5 Services',
                price: '۶,۲۰۰,۰۰۰ تومان برای هر مهمان',
                courses: ['آموزبوش خاویار و کرم لیمو', 'فوا گرای تفت‌داده با انجیر', 'فیله مینیون با پوره ترواگروس', 'سینی پنیرهای کمیاب فرانسه', 'سوفله شکلات والورونا گرم'],
                badge: 'پیشنهاد شب‌های کاری',
              },
              {
                title: 'دگوستاسیون طلایی ۷ مرحله‌ای (رویال)',
                french: 'Menu Prestige 7 Services',
                price: '۹,۸۰۰,۰۰۰ تومان برای هر مهمان',
                courses: ['مرواریدهای خاویار بلوگا روی یخ', 'سوپ لابستر با زعفران گناباد', 'تارتار سالمون نروژ', 'سوربه شامپاین برای تصفیه کام', 'اردک برشته با عسل وحشی', 'ترافل سیاه روی کاناپه', 'گلدن میل‌فوی با ورق طلا'],
                badge: 'محبوب‌ترین ضیافت VIP',
              },
              {
                title: 'دگوستاسیون امپریال ورسای ۹ مرحله‌ای',
                french: 'Menu Impérial Versailles 9 Services',
                price: '۱۴,۵۰۰,۰۰۰ تومان برای هر مهمان',
                courses: ['سرو اختصاصی سر میز توسط سرآشپز پیر لوران', 'خاویار امپریال طلایی با قاشق مادر مروارید', 'شاه‌میگو با کره ترافل', 'فیله گوساله واگیو A5', 'مجموعه دسرهای سفارشی با نیتروژن مایع', 'هدیه جعبه مخمل ماکارون دست‌ساز'],
                badge: 'نهایت شکوه میشلن ۳ ستاره',
              },
            ].map((deg, i) => (
              <div
                key={i}
                className="rounded-[32px] bg-white border border-stone-200/90 p-7 flex flex-col justify-between shadow-[0_15px_40px_rgba(0,0,0,0.06)] hover:shadow-[0_20px_50px_rgba(197,160,89,0.25)] hover:border-amber-500/70 transition-all space-y-6"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                    <span className="text-[11px] font-bold px-3 py-1 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                      {deg.badge}
                    </span>
                    <span className="font-latin text-xs text-amber-700 font-bold">{deg.french}</span>
                  </div>

                  <h3 className="text-lg font-black text-stone-900">{deg.title}</h3>
                  <div className="font-mono text-sm sm:text-base font-black text-amber-700">
                    {deg.price}
                  </div>

                  <div className="space-y-2 pt-2 text-xs text-stone-700">
                    {deg.courses.map((c, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-600 flex-shrink-0"></span>
                        <span>{c}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => setCurrentPage('reservation')}
                  className="w-full py-3 rounded-2xl bg-stone-900 hover:bg-black text-white hover:text-amber-300 text-xs font-bold transition-all shadow-md"
                >
                  رزرو این منوی دگوستاسیون
                </button>
              </div>
            ))}
          </div>

        </div>
      </section>

    </div>
  );
};
