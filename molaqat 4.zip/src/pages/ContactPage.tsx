import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Page } from '../types';
import { RESTAURANT_INFO } from '../data/restaurantData';
import { MolaqatLogo } from '../components/MolaqatLogo';
import facadeImg from '../assets/images/molaqat_hero_facade_1786224208172.jpg';
import { 
  MapPin, 
  Phone, 
  Clock, 
  Car, 
  Shield, 
  Send, 
  Sparkles, 
  Instagram, 
  Mail, 
  MessageSquare, 
  AlertCircle,
  Navigation,
  Hotel,
  Plane,
  CheckCircle2
} from 'lucide-react';

interface ContactPageProps {
  setCurrentPage: (page: Page) => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({ setCurrentPage }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [isSent, setIsSent] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      setErrorMessage('لطفاً نام و شماره همراه خود را وارد فرمایید.');
      return;
    }
    setErrorMessage(null);
    setIsSent(true);
  };

  return (
    <div className="w-full relative overflow-hidden bg-[#09080c] text-white">

      {/* Contextual High-Resolution Background */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <img
          src={facadeImg}
          alt="Palace Facade"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover filter brightness-[0.20] contrast-125"
        />
        <div className="absolute inset-0 bg-[#09080c]/85 backdrop-blur-md"></div>
      </div>

      <div className="relative pt-32 pb-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16 text-right z-10">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-white/[0.06] border border-amber-500/30 text-xs font-semibold text-white backdrop-blur-xl shadow-lg">
            <MolaqatLogo size={20} variant="gold" />
            <span>ارتباط با دفتر تشریفات و کانسیرژ</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
            موقعیت مکانی و راه‌های ارتباطی
          </h1>
          <p className="text-xs sm:text-sm text-stone-300">
            پاسخگویی به هماهنگی‌های ضیافت‌های خصوصی، رویدادهای دیپلماتیک و رزرو سالن‌ها
          </p>
        </div>

        {/* Main 2-Column */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Info & Map Preview */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Contact Details Card */}
            <div className="p-8 rounded-[32px] bg-white/[0.04] border border-white/10 space-y-6 shadow-2xl backdrop-blur-2xl">
              <h2 className="text-lg font-bold text-white border-b border-white/10 pb-4">
                اطلاعات عمارت اختصاصی ملاقات
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs text-stone-300">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-white font-bold text-sm">
                    <MapPin className="w-4 h-4 text-amber-400" />
                    <span>نشانی عمارت در مشهد:</span>
                  </div>
                  <p className="leading-relaxed text-stone-300">
                    {RESTAURANT_INFO.addressPersian}
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-white font-bold text-sm">
                    <Phone className="w-4 h-4 text-amber-400" />
                    <span>خطوط تلفن VIP:</span>
                  </div>
                  <div className="font-mono text-sm text-amber-300">
                    <div>{RESTAURANT_INFO.phoneDisplay}</div>
                    <div className="text-xs text-stone-400">{RESTAURANT_INFO.vipPhoneConcierge} (واتس‌اپ)</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-white font-bold text-sm">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span>ساعات پذیرایی:</span>
                  </div>
                  <p className="leading-relaxed text-stone-300">
                    {RESTAURANT_INFO.workingHours}
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-white font-bold text-sm">
                    <Car className="w-4 h-4 text-amber-400" />
                    <span>خدمات پارک و ولت:</span>
                  </div>
                  <p className="leading-relaxed text-stone-300">
                    {RESTAURANT_INFO.valetService}
                  </p>
                </div>
              </div>

              {/* Instagram & Social Bar */}
              <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-amber-400">
                  <Instagram className="w-4 h-4" />
                  <span className="font-mono text-white">@molaqat.mashhad</span>
                </div>
                <div className="flex items-center gap-2 text-stone-400">
                  <Mail className="w-4 h-4 text-amber-400" />
                  <span className="font-mono text-white">concierge@molaqat.ir</span>
                </div>
              </div>
            </div>

            {/* Architectural Facade Preview */}
            <div className="relative rounded-[32px] overflow-hidden border border-white/10 aspect-16/9 shadow-2xl">
              <img
                src={facadeImg}
                alt="عمارت ملاقات مشهد"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-6">
                <div className="flex items-center gap-3">
                  <MolaqatLogo size={24} variant="gold" />
                  <div>
                    <span className="text-sm font-bold text-white block">عمارت اختصاصی ملاقات</span>
                    <span className="text-xs text-amber-300">مشهد، بلوار سجاد، انتهای بهارستان</span>
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Contact Form */}
          <div className="lg:col-span-5">
            <div className="p-8 rounded-[32px] bg-white/[0.04] border border-white/10 space-y-6 shadow-2xl backdrop-blur-2xl">
              <div className="flex items-center gap-2 text-base font-bold text-white border-b border-white/10 pb-4">
                <MessageSquare className="w-5 h-5 text-amber-400" />
                <span>پیام مستقیم به مدیریت تشریفات</span>
              </div>

              {!isSent ? (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-stone-300">نام و نام خانوادگی:</label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="جناب آقای / سرکار خانم..."
                      className="w-full px-4 py-3 rounded-2xl bg-black/40 border border-white/10 text-xs text-white placeholder-stone-500 focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-stone-300">شماره تلفن همراه:</label>
                    <input
                      type="tel"
                      required
                      dir="ltr"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="0915..."
                      className="w-full px-4 py-3 rounded-2xl bg-black/40 border border-white/10 text-left font-mono text-xs text-white placeholder-stone-500 focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-stone-300">موضوع و متن پیام:</label>
                    <textarea
                      rows={4}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="درخواست قرق تالار، هماهنگی مراسم یا پرسش‌های تشریفات..."
                      className="w-full px-4 py-3 rounded-2xl bg-black/40 border border-white/10 text-xs text-white placeholder-stone-500 focus:outline-none focus:border-amber-400"
                    ></textarea>
                  </div>

                  {/* Error Notification */}
                  <AnimatePresence>
                    {errorMessage && (
                      <motion.div
                        initial={{ opacity: 0, y: -6 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -6 }}
                        className="p-3 rounded-2xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs flex items-center gap-2"
                      >
                        <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                        <span>{errorMessage}</span>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <button
                    type="submit"
                    className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 text-black font-black text-xs shadow-lg hover:scale-105 transition-all flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>ارسال پیام به کانسیرژ</span>
                  </button>
                </form>
              ) : (
                <div className="py-12 text-center space-y-4">
                  <div className="w-14 h-14 rounded-full bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300 mx-auto">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <h3 className="text-base font-bold text-white">پیام شما با موفقیت ثبت شد</h3>
                  <p className="text-xs text-stone-400 leading-relaxed">
                    تیم کانسیرژ عمارت در اسرع وقت با شماره همراه وارد شده تماس حاصل خواهند نمود.
                  </p>
                  <button
                    onClick={() => setIsSent(false)}
                    className="px-6 py-2 rounded-2xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white"
                  >
                    ارسال پیام جدید
                  </button>
                </div>
              )}
            </div>
          </div>

        </div>

      </div>

      {/* =========================================================================
          WHITE ALABASTER SECTION: ACCESS ROUTES & LUXURY HOTELS NEARBY
          ========================================================================= */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#faf8f5] text-stone-900 border-t-2 border-stone-200 relative z-10">
        <div className="max-w-7xl mx-auto space-y-8 text-right">
          
          <div className="text-center max-w-xl mx-auto space-y-2">
            <h3 className="text-2xl font-black text-stone-900">
              مسیرهای دسترسی و هتل‌های ۵ ستاره همجوار
            </h3>
            <p className="text-xs text-stone-600">
              دسترسی سریع با شوفر عمارت یا خودروی شخصی از سراسر کلان‌شهر مشهد
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs text-stone-700">
            <div className="p-6 rounded-3xl bg-white border border-stone-200 shadow-sm space-y-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-800">
                <Navigation className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-stone-900 text-sm">از هتل بین‌المللی هما ۱ و ۲</h4>
              <p className="leading-relaxed">فاصله زمانی کمتر از ۵ الی ۱۰ دقیقه با ترانسفر رایگان عمارت ملاقات برای مهمانان مقیم سوئیت‌های رویال هتل هما.</p>
            </div>

            <div className="p-6 rounded-3xl bg-white border border-stone-200 shadow-sm space-y-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-800">
                <Plane className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-stone-900 text-sm">از فرودگاه بین‌المللی مشهد (MHD)</h4>
              <p className="leading-relaxed">انتقال بدون معطلی از پاویون اختصاصی و سالن CIP فرودگاه شهید هاشمی‌نژاد تا درب عمارت در مدت ۲۰ دقیقه.</p>
            </div>

            <div className="p-6 rounded-3xl bg-white border border-stone-200 shadow-sm space-y-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-800">
                <Hotel className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-stone-900 text-sm">از هتل قصر طلایی و درویشی</h4>
              <p className="leading-relaxed">مسیر سرراست از بزرگراه کلانتری به سمت بلوار سجاد مشهد در مدت زمان تقریبی ۱۵ دقیقه با خودروی تشریفات.</p>
            </div>
          </div>

        </div>
      </section>

    </div>
  );
};
