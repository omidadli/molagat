import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Page, CartItem, Dish } from '../types';
import { JALALI_MONTHS, RESTAURANT_INFO } from '../data/restaurantData';
import { ShoppingBag, Trash2, Plus, Minus, ShieldCheck, Car, PackageCheck, Sparkles, Check, ArrowRight, ArrowLeft, AlertCircle } from 'lucide-react';

interface OrderingPageProps {
  cart: CartItem[];
  setCurrentPage: (page: Page) => void;
  onUpdateQuantity: (dishId: string, delta: number) => void;
  onRemoveItem: (dishId: string) => void;
  onClearCart: () => void;
}

export const OrderingPage: React.FC<OrderingPageProps> = ({
  cart,
  setCurrentPage,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [deliveryMethod, setDeliveryMethod] = useState<'chauffeur' | 'takeaway'>('chauffeur');
  const [guestName, setGuestName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [deliveryTimeSlot, setDeliveryTimeSlot] = useState('۲۰:۰۰ الی ۲۱:۰۰');
  const [conciergeNotes, setConciergeNotes] = useState('');
  const [isOrdered, setIsOrdered] = useState(false);
  const [orderReference, setOrderReference] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const subtotal = cart.reduce((sum, item) => sum + item.dish.priceTomans * item.quantity, 0);
  const packagingFee = cart.length > 0 ? 150000 : 0; // Silk-lined isothermal packaging
  const chauffeurFee = deliveryMethod === 'chauffeur' ? 250000 : 0;
  const grandTotal = subtotal + packagingFee + chauffeurFee;

  const formattedSubtotal = new Intl.NumberFormat('fa-IR').format(subtotal) + ' تومان';
  const formattedPackaging = new Intl.NumberFormat('fa-IR').format(packagingFee) + ' تومان';
  const formattedChauffeur = new Intl.NumberFormat('fa-IR').format(chauffeurFee) + ' تومان';
  const formattedGrandTotal = new Intl.NumberFormat('fa-IR').format(grandTotal) + ' تومان';

  const handleCompleteOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName.trim() || !guestPhone.trim()) {
      setErrorMessage('لطفاً نام و نام خانوادگی و شماره همراه خود را وارد فرمایید.');
      return;
    }
    if (deliveryMethod === 'chauffeur' && !deliveryAddress.trim()) {
      setErrorMessage('لطفاً نشانی دقیق تحویل تشریفاتی را وارد فرمایید.');
      return;
    }
    setErrorMessage(null);
    const code = 'MLQ-VIP-' + Math.floor(1000 + Math.random() * 9000);
    setOrderReference(code);
    setIsOrdered(true);
    const lenis = (window as any).__molaqat_lenis;
    if (lenis) {
      lenis.scrollTo(0, { duration: 1 });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="pt-28 pb-24 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12 text-right">
      
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#c5a059]/15 border border-[#c5a059]/40 text-xs font-semibold text-[#f5ecd7]">
          <Sparkles className="w-3.5 h-3.5 text-[#c5a059]" />
          <span>سرویس سفارش تشریفاتی و ارسال ایزوترمال</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-[#f7efe0] tracking-tight">
          سبد سفارش و کانسیرژ ملاقات
        </h1>
        <p className="text-xs sm:text-sm text-[#aba496]">
          بسته‌بندی در جعبه‌های سیلک عایق حرارت با ارسال مستقیم توسط راننده اختصاصی تشریفات
        </p>
      </div>

      {!isOrdered ? (
        cart.length === 0 ? (
          <div className="text-center py-20 bg-[#121218] rounded-3xl border border-white/5 space-y-4">
            <ShoppingBag className="w-12 h-12 text-[#666] mx-auto" />
            <h3 className="text-lg font-bold text-[#f5ecd7]">سبد سفارش تشریفاتی شما خالی است</h3>
            <p className="text-xs text-[#8f897d]">
              شاهکارهای فرانسوی مورد نظر خود را از منوی اختصاصی انتخاب فرمایید.
            </p>
            <button
              onClick={() => {
                setCurrentPage('menu');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-6 py-3 rounded-full bg-gradient-to-r from-[#c5a059] to-[#b38f49] text-[#09090b] font-bold text-xs shadow-lg"
            >
              مشاهده کارت منوی عمارت
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left Col in RTL (Right side of screen): Order Form */}
            <form onSubmit={handleCompleteOrder} className="lg:col-span-7 space-y-6">
              
              {/* Delivery method selector */}
              <div className="p-6 rounded-3xl bg-[#121219]/90 border border-white/10 space-y-4">
                <h3 className="text-sm font-bold text-[#f5ecd7] flex items-center gap-2 border-b border-white/10 pb-3">
                  <Car className="w-4 h-4 text-[#c5a059]" />
                  <span>۱. شیوه دریافت سفارش</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setDeliveryMethod('chauffeur')}
                    className={`p-4 rounded-2xl border text-right transition-all ${
                      deliveryMethod === 'chauffeur'
                        ? 'bg-[#221c13] border-[#c5a059] text-[#f5ecd7] shadow-md'
                        : 'bg-[#181822] border-white/5 text-[#888]'
                    }`}
                  >
                    <span className="text-xs font-bold block text-[#f5ecd7]">ارسال با خودروی تشریفات</span>
                    <span className="text-[11px] text-[#9c9689] block mt-1">بسته‌بندی ایزوترمال و تحویل با دستکش سفید</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setDeliveryMethod('takeaway')}
                    className={`p-4 rounded-2xl border text-right transition-all ${
                      deliveryMethod === 'takeaway'
                        ? 'bg-[#221c13] border-[#c5a059] text-[#f5ecd7] shadow-md'
                        : 'bg-[#181822] border-white/5 text-[#888]'
                    }`}
                  >
                    <span className="text-xs font-bold block text-[#f5ecd7]">تحویل حضوری در عمارت</span>
                    <span className="text-[11px] text-[#9c9689] block mt-1">مشهد، بلوار سجاد، بزرگمهر (درب تشریفات)</span>
                  </button>
                </div>
              </div>

              {/* Guest Details */}
              <div className="p-6 rounded-3xl bg-[#121219]/90 border border-white/10 space-y-4">
                <h3 className="text-sm font-bold text-[#f5ecd7] flex items-center gap-2 border-b border-white/10 pb-3">
                  <ShieldCheck className="w-4 h-4 text-[#c5a059]" />
                  <span>۲. اطلاعات دریافت‌کننده محترم</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs text-[#a59f92]">نام و نام خانوادگی:</label>
                    <input
                      type="text"
                      required
                      value={guestName}
                      onChange={(e) => setGuestName(e.target.value)}
                      placeholder="جناب آقای / سرکار خانم..."
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#181822] border border-white/10 text-xs text-[#f5ecd7] focus:outline-none focus:border-[#c5a059]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs text-[#a59f92]">شماره تلفن همراه (۰۹۱۵...):</label>
                    <input
                      type="tel"
                      required
                      dir="ltr"
                      value={guestPhone}
                      onChange={(e) => setGuestPhone(e.target.value)}
                      placeholder="0915 123 4567"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#181822] border border-white/10 font-mono text-left text-xs text-[#f5ecd7] focus:outline-none focus:border-[#c5a059]"
                    />
                  </div>
                </div>

                {deliveryMethod === 'chauffeur' && (
                  <div className="space-y-1.5">
                    <label className="text-xs text-[#a59f92]">نشانی دقیق تحویل تشریفاتی:</label>
                    <input
                      type="text"
                      required
                      value={deliveryAddress}
                      onChange={(e) => setDeliveryAddress(e.target.value)}
                      placeholder="مشهد، بلوار سجاد / احمدآباد / وکیل‌آباد، خیابان، پلاک، واحد..."
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#181822] border border-white/10 text-xs text-[#f5ecd7] focus:outline-none focus:border-[#c5a059]"
                    />
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs text-[#a59f92]">بازه زمانی ارسال امشب:</label>
                    <select
                      value={deliveryTimeSlot}
                      onChange={(e) => setDeliveryTimeSlot(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#181822] border border-white/10 text-xs text-[#f5ecd7] focus:outline-none focus:border-[#c5a059]"
                    >
                      <option value="۱۹:۳۰ الی ۲۰:۳۰">۱۹:۳۰ الی ۲۰:۳۰</option>
                      <option value="۲۰:۳۰ الی ۲۱:۳۰">۲۰:۳۰ الی ۲۱:۳۰</option>
                      <option value="۲۱:۳۰ الی ۲۲:۳۰">۲۱:۳۰ الی ۲۲:۳۰</option>
                      <option value="۲۲:۳۰ الی ۲۳:۳۰">۲۲:۳۰ الی ۲۳:۳۰</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs text-[#a59f92]">یادداشت اختصاصی برای سرآشپز:</label>
                    <input
                      type="text"
                      value={conciergeNotes}
                      onChange={(e) => setConciergeNotes(e.target.value)}
                      placeholder="نکات رژیمی یا چیدمان ویژه..."
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#181822] border border-white/10 text-xs text-[#f5ecd7] focus:outline-none focus:border-[#c5a059]"
                    />
                  </div>
                </div>
              </div>

              {/* Validation Error Banner */}
              <AnimatePresence>
                {errorMessage && (
                  <motion.div
                    initial={{ opacity: 0, y: -8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    className="p-3.5 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs flex items-center gap-2"
                  >
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{errorMessage}</span>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Submit CTA */}
              <button
                type="submit"
                id="complete-order-btn"
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#c5a059] via-[#d4af37] to-[#b38f49] text-[#09090b] font-bold text-sm shadow-[0_4px_25px_rgba(197,160,89,0.4)] hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2"
              >
                <PackageCheck className="w-4 h-4" />
                <span>تایید و ارسال تشریفاتی سفارش ({formattedGrandTotal})</span>
              </button>
            </form>

            {/* Right Col in RTL (Left side of screen): Cart Items & Invoice */}
            <div className="lg:col-span-5 space-y-6">
              <div className="p-6 rounded-3xl bg-[#121219]/90 border border-[#c5a059]/30 space-y-6 shadow-xl">
                <div className="flex items-center justify-between border-b border-white/10 pb-4">
                  <h3 className="text-sm font-bold text-[#f5ecd7]">فهرست اقلام سفارش</h3>
                  <span className="text-xs text-[#c5a059] font-mono">{cart.length} نوع بشقاب</span>
                </div>

                {/* Items List */}
                <div className="space-y-4 max-h-80 overflow-y-auto pr-1">
                  {cart.map((item) => (
                    <div
                      key={item.dish.id}
                      className="p-3 rounded-2xl bg-[#181824] border border-white/5 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={item.dish.image}
                          alt={item.dish.frenchName}
                          referrerPolicy="no-referrer"
                          className="w-12 h-12 rounded-full object-cover border border-[#c5a059]/40 flex-shrink-0"
                        />
                        <div className="space-y-0.5">
                          <h4 className="text-xs font-bold text-[#f5ecd7] line-clamp-1">{item.dish.persianName}</h4>
                          <span className="text-[10px] font-latin text-[#c5a059] block">{item.dish.frenchName}</span>
                          <span className="text-xs font-mono text-[#f1dda4]">{item.dish.formattedPrice}</span>
                        </div>
                      </div>

                      {/* Quantity Controls */}
                      <div className="flex items-center gap-1 bg-[#101016] border border-white/10 rounded-xl p-1">
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.dish.id, -1)}
                          className="p-1 hover:text-white text-[#888]"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-5 text-center text-xs font-mono font-bold text-[#f5ecd7]">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.dish.id, 1)}
                          className="p-1 hover:text-white text-[#888]"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Financial breakdown */}
                <div className="pt-4 border-t border-white/10 space-y-2 text-xs text-[#a8a294]">
                  <div className="flex justify-between">
                    <span>جمع اقلام منو:</span>
                    <span className="font-mono text-[#f5ecd7]">{formattedSubtotal}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>بسته‌بندی سیلک ایزوترمال:</span>
                    <span className="font-mono text-[#f5ecd7]">{formattedPackaging}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>سرویس خودروی تشریفات:</span>
                    <span className="font-mono text-[#f5ecd7]">
                      {deliveryMethod === 'chauffeur' ? formattedChauffeur : 'رایگان (تحویل حضوری)'}
                    </span>
                  </div>
                  <div className="pt-3 border-t border-[#c5a059]/30 flex justify-between text-sm font-bold text-[#f1dda4]">
                    <span>مبلغ نهایی قابل پرداخت:</span>
                    <span className="font-mono text-base">{formattedGrandTotal}</span>
                  </div>
                </div>

              </div>
            </div>

          </div>
        )
      ) : (
        /* =========================================================================
            CEREMONIAL VIP ORDER CONFIRMATION
            ========================================================================= */
        <div className="max-w-2xl mx-auto rounded-3xl sm:rounded-[36px] bg-gradient-to-b from-[#201a12] via-[#14141c] to-[#0a0a0e] border-2 border-[#c5a059] p-8 sm:p-12 text-right space-y-6 shadow-2xl animate-fade-in">
          
          <div className="flex items-center justify-between border-b border-[#c5a059]/30 pb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-[#100e0a] border border-[#c5a059] flex items-center justify-center">
                <span className="text-[#f1dda4] text-2xl font-serif font-bold">M</span>
              </div>
              <div>
                <h2 className="text-xl font-bold text-[#f5ecd7]">سفارش تشریفاتی ثبت گردید</h2>
                <span className="text-[10px] font-latin text-[#c5a059]">MOLAQAṮ CEREMONIAL CONCIERGE ORDER</span>
              </div>
            </div>

            <div className="text-left font-mono">
              <span className="text-[10px] text-[#938d81] block">کد رهگیری سفارش:</span>
              <span className="text-sm font-bold text-[#f1dda4]">{orderReference}</span>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-[#cfc7b8] leading-relaxed">
            جناب آقای / سرکار خانم <strong className="text-[#f5ecd7]">{guestName}</strong>، سفارش شما جهت طبخ فوری به سرآشپز پیر لوران ابلاغ گردید و در بازه زمانی <strong className="text-[#c5a059]">{deliveryTimeSlot}</strong> با بسته‌بندی ایزوترمال و خودروی تشریفاتی تحویل خواهد شد.
          </p>

          <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-2 text-xs">
            <div className="flex justify-between text-[#8f897d]">
              <span>مبلغ کل پرداخت شده:</span>
              <span className="font-mono font-bold text-[#f1dda4]">{formattedGrandTotal}</span>
            </div>
            <div className="flex justify-between text-[#8f897d]">
              <span>شیوه تحویل:</span>
              <span className="text-[#f5ecd7]">{deliveryMethod === 'chauffeur' ? 'ارسال تشریفاتی به نشانی' : 'تحویل حضوری درب عمارت'}</span>
            </div>
          </div>

          <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-4">
            <button
              onClick={() => {
                onClearCart();
                setIsOrdered(false);
                setCurrentPage('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-6 py-2.5 rounded-full bg-[#c5a059] text-[#09090b] text-xs font-bold"
            >
              بازگشت به صفحه اصلی
            </button>

            <div className="text-xs text-[#9c9689]">
              کانسیرژ آنلاین: <span className="font-mono text-[#c5a059] font-bold">{RESTAURANT_INFO.phoneDisplay}</span>
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
