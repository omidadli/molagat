import React from 'react';
import { Page } from '../types';
import { RESTAURANT_INFO } from '../data/restaurantData';
import { MolaqatLogo } from '../components/MolaqatLogo';
import facadeImg from '../assets/images/molaqat_hero_facade_1786224208172.jpg';
import interiorImg from '../assets/images/molaqat_interior_hall_1786224218757.jpg';
import chefImg from '../assets/images/molaqat_chef_art_1786224255487.jpg';
import filetImg from '../assets/images/molaqat_dish_filet_1786224230750.jpg';
import { Sparkles, Award, Compass, Shield, Clock, HeartHandshake, ArrowLeft, Crown, CheckCircle2 } from 'lucide-react';

interface AboutPageProps {
  setCurrentPage: (page: Page) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ setCurrentPage }) => {
  return (
    <div className="w-full relative overflow-hidden bg-[#09080c] text-white">

      {/* Contextual High-Resolution Background with Frosted Overlay */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <img
          src={interiorImg}
          alt="Palace Interior"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover filter brightness-[0.22] contrast-125"
        />
        <div className="absolute inset-0 bg-[#09080c]/85 backdrop-blur-md"></div>
      </div>

      <div className="relative pt-32 pb-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-20 text-right z-10">
        
        {/* Hero Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-white/[0.06] border border-amber-500/30 text-xs font-semibold text-white backdrop-blur-xl shadow-lg">
            <MolaqatLogo size={20} variant="gold" />
            <span>داستان اصالت و فلسفه مهمان‌نوازی</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
            میراث شکوه پاریسی در قلب مشهد
          </h1>
          <p className="text-sm sm:text-base text-stone-300 leading-relaxed">
            «ملاقات»، پیوند جاودانه میان ظرافت‌های کهن هنر آشپزی فرانسه و مهمان‌نوازی اشرافی ایران است. فضایی خلق شده برای آنان که تعالی را نه یک انتخاب، بلکه یک ضرورت می‌دانند.
          </p>
        </div>

        {/* =========================================================================
            SECTION 1: THE MANOR & HERITAGE (Modern Frosted Glass Card)
            ========================================================================= */}
        <div className="rounded-[36px] bg-white/[0.04] border border-white/10 p-8 sm:p-12 shadow-[0_20px_60px_rgba(0,0,0,0.8)] backdrop-blur-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            {/* Column 1 (RTL Right side): Text Narrative */}
            <div className="lg:col-span-7 space-y-5">
              <span className="text-xs font-latin text-amber-400 tracking-widest uppercase font-bold">
                L'HISTOIRE DU MANOIR
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-white leading-tight">
                عمارت ملاقات؛ خلق خلوتگاهی برای نخبگان و صاحبان اندیشه
              </h2>
              <p className="text-sm text-stone-300 leading-loose">
                ایده تاسیس عمارت ملاقات، از این باور سرچشمه گرفت که مشهد و کهن‌دیار خراسان شایسته فضایی در تراز بالاترین خانه‌های گاسترونومی پاریس و موناکوست. ساختمانی در دنج‌ترین محله بلوار سجاد مشهد با معماری الهام‌گرفته از کاخ‌های قرن هجدهم ورسای، آمیخته با مصالح مدرن و نورپردازی حساب‌شده.
              </p>
              <p className="text-sm text-stone-400 leading-loose">
                در ملاقات، هیچ میزی بیش از ظرفیت پذیرفته نمی‌شود. حریم خصوصی، آرامش اکوستیک فضا و حضور پیشخدمت‌های آموزش‌دیده در آکادمی‌های هتلداری لوزان سوئیس، تضمین‌کننده تجربه‌ای بی‌همتاست.
              </p>

              <div className="pt-2 flex items-center gap-6 text-xs text-amber-300">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-amber-400" />
                  <span>حریم خصوصی ۱۰۰٪ تضمین شده</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span>پذیرش فقط ۴۰ مهمان در هر شب</span>
                </div>
              </div>
            </div>

            {/* Column 2 (RTL Left side): Image */}
            <div className="lg:col-span-5">
              <div className="relative rounded-3xl overflow-hidden border border-amber-500/30 aspect-4/3 shadow-2xl">
                <img
                  src={facadeImg}
                  alt="عمارت ملاقات در مشهد"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

          </div>
        </div>

        {/* =========================================================================
            SECTION 2: EXECUTIVE CHEF PIERRE LAURENT (Modern Frosted Glass Card)
            ========================================================================= */}
        <div className="rounded-[36px] bg-white/[0.04] border border-white/10 p-8 sm:p-12 shadow-[0_20px_60px_rgba(0,0,0,0.8)] backdrop-blur-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            {/* Column 1 (RTL Right side): Chef Narrative */}
            <div className="lg:col-span-7 space-y-5">
              <span className="text-xs font-latin text-amber-400 tracking-widest uppercase font-bold">
                MAÎTRE DE CUISINE
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-white leading-tight">
                سرآشپز پیر لوران؛ پرچمدار دقت و هارمونی طعم‌ها
              </h2>
              <p className="text-sm text-stone-300 leading-loose">
                پیر لوران فارغ‌التحصیل انستیتو پول بوکوز (Institut Paul Bocuse) در لیون فرانسه است. او سال‌ها در آشپزخانه‌های رستوران‌های برنده ۳ ستاره میشلن در پاریس مشغول به کار بوده و درک عمیقی از شیمی طعم‌ها، دمای پخت و چیدمان معماری غذا دارد.
              </p>
              <p className="text-sm text-stone-400 leading-loose">
                «غذای خوب نیاز به اغراق ندارد؛ نیازمند صداقت است. وقتی بهترین گوشت، زلال‌ترین کره و اصیل‌ترین ترافل را در اختیار دارید، وظیفه شما تنها این است که اجازه دهید طعم واقعی مواد بدرخشد.»
              </p>

              <div className="p-4 rounded-2xl bg-black/40 border border-white/10">
                <span className="text-xs font-bold text-amber-300 block">افتخارات و مدارک بین‌المللی:</span>
                <ul className="text-xs text-stone-300 space-y-1 mt-2">
                  <li>• مدال طلای مسابقات بین‌المللی سرآشپزان جوان اروپا ۲۰۱۴</li>
                  <li>• عضو دائم انجمن گاسترونومی آگوست اسکوفیه فرانسه</li>
                  <li>• سوملیه تایید شده پنیر و نکتارهای دست‌ساز از انستیتو بوردو</li>
                </ul>
              </div>
            </div>

            {/* Column 2 (RTL Left side): Chef Image */}
            <div className="lg:col-span-5">
              <div className="relative rounded-3xl overflow-hidden border border-amber-500/30 aspect-4/3 shadow-2xl">
                <img
                  src={chefImg}
                  alt="سرآشپز پیر لوران"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-6">
                  <div>
                    <span className="text-xs font-bold text-white block">پیر لوران (Pierre Laurent)</span>
                    <span className="text-[11px] text-amber-300">سرآشپز اجرایی عمارت ملاقات</span>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>

      {/* =========================================================================
          SECTION 3: WHITE ALABASTER MARBLE SECTION (Sourcing & Ingredients Philosophy)
          ========================================================================= */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-[#faf8f5] text-stone-900 border-t-2 border-stone-200 relative z-10">
        <div className="max-w-7xl mx-auto space-y-12 text-right">
          
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-latin text-amber-800 tracking-widest uppercase font-bold">
              LE TERROIR & LES MATIÈRES
            </span>
            <h3 className="text-2xl sm:text-4xl font-black text-stone-900">
              خاستگاه اصیل مواد اولیه و مزرعه‌های اختصاصی
            </h3>
            <p className="text-xs sm:text-sm text-stone-600">
              تعهد ما به عدم استفاده از هرگونه جایگزین صنعتی و تاکید بر تازگی بی حد و حصر
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-7 rounded-3xl bg-white border border-stone-200 shadow-[0_15px_35px_rgba(0,0,0,0.06)] hover:border-amber-500/70 transition-all space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-300 flex items-center justify-center text-xl shadow-sm">
                🍄
              </div>
              <h4 className="text-base font-bold text-stone-900">ترافل سیاه و سفید پرون</h4>
              <p className="text-xs text-stone-600 leading-relaxed">
                قارچ‌های دنبلان کوهی کمیاب که هفتگی از جنگل‌های پرون و پیدمونت با پرواز اختصاصی در محفظه‌های خنک به مشهد ارسال می‌شوند.
              </p>
            </div>

            <div className="p-7 rounded-3xl bg-white border border-stone-200 shadow-[0_15px_35px_rgba(0,0,0,0.06)] hover:border-amber-500/70 transition-all space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-300 flex items-center justify-center text-xl shadow-sm">
                🍫
              </div>
              <h4 className="text-base font-bold text-stone-900">شکلات گرند کرو والورونا</h4>
              <p className="text-xs text-stone-600 leading-relaxed">
                دانه‌های دست‌چین کاکائو فرآوری شده در شهر تین لهرمیت فرانسه با بافت مخملی و درصدهای خلوص ۶۶ الی ۸۵ درصد.
              </p>
            </div>

            <div className="p-7 rounded-3xl bg-white border border-stone-200 shadow-[0_15px_35px_rgba(0,0,0,0.06)] hover:border-amber-500/70 transition-all space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-300 flex items-center justify-center text-xl shadow-sm">
                🧈
              </div>
              <h4 className="text-base font-bold text-stone-900">کره اشیره و نمک برتانی</h4>
              <p className="text-xs text-stone-600 leading-relaxed">
                کره طلایی دست‌ساز منطقه نورماندی و برتانی با بافت غنی از چربی طبیعی و نمک فلور دو سل کریستالی اقیانوس اطلس.
              </p>
            </div>
          </div>

          {/* Call to action */}
          <div className="text-center pt-8">
            <button
              onClick={() => {
                setCurrentPage('reservation');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-9 py-4 rounded-2xl bg-stone-900 hover:bg-black text-white hover:text-amber-300 font-bold text-sm shadow-xl hover:scale-105 active:scale-95 transition-all inline-flex items-center gap-2"
            >
              <span>رزرو میز و حضور در این ضیافت</span>
              <ArrowLeft className="w-4 h-4 text-amber-400" />
            </button>
          </div>

        </div>
      </section>

    </div>
  );
};
