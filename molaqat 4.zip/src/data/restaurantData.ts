import { Dish, MenuCategory, GalleryItem, SalonExperience, WalkthroughStep, LuxuryGiftCard } from '../types';

import facadeImg from '../assets/images/molaqat_hero_facade_1786224208172.jpg';
import interiorImg from '../assets/images/molaqat_interior_hall_1786224218757.jpg';
import filetImg from '../assets/images/molaqat_dish_filet_1786224230750.jpg';
import dessertImg from '../assets/images/molaqat_dish_dessert_1786224242352.jpg';
import chefImg from '../assets/images/molaqat_chef_art_1786224255487.jpg';
import foieGrasImg from '../assets/images/molaqat_foie_gras_1786236101403.jpg';
import cheeseBoardImg from '../assets/images/molaqat_cheese_board_1786236113806.jpg';
import elixirImg from '../assets/images/molaqat_elixir_drink_1786236126492.jpg';
import duckImg from '../assets/images/molaqat_duck_dish_1786236138172.jpg';
import salmonCaviarImg from '../assets/images/molaqat_salmon_caviar_1786236153159.jpg';
import terraceImg from '../assets/images/molaqat_terrace_night_1786236165643.jpg';

export const RESTAURANT_INFO = {
  brandNamePersian: 'ملاقات',
  brandNameFrench: 'MOLAQAṮ',
  taglinePersian: 'اوج هنر آشپزی فاخر فرانسوی در قلب مشهد (بلوار سجاد)',
  taglineFrench: 'Haute Gastronomie Française à Mashhad',
  addressPersian: 'مشهد، بلوار سجاد، خیابان بزرگمهر جنوبی، پلاک ۱۸، عمارت اختصاصی ملاقات',
  phoneDisplay: '۰۵۱-۳۷۶۵۹۹۸۸',
  vipPhoneConcierge: '۰۹۱۵-۰۰۰۰۰۸۸',
  workingHours: 'هر شب از ساعت ۱۹:۰۰ الی ۲۴:۰۰ (پذیرش صرفاً با هماهنگی و رزرو قبلی)',
  valetService: 'سرویس پارکینگ اختصاصی و ولت تشریفات درب عمارت برقرار است.',
  dressCode: 'پوشش رسمی (Formal / Black Tie Optional) - برای حفظ حریم و وقار ضیافت‌ها',
  instagram: '@molaqat.restaurant',
};

export const MENU_CATEGORIES: MenuCategory[] = [
  {
    id: 'entrees',
    frenchTitle: 'Entrées',
    persianTitle: 'پیش‌غذاهای اصیل',
    persianSubtitle: 'آغاز باشکوه با طعم‌های ناب پاریسی',
    thumbnail: foieGrasImg,
    icon3D: 'sparkles',
  },
  {
    id: 'plats',
    frenchTitle: 'Plats Principaux',
    persianTitle: 'غذاهای اصلی شاهانه',
    persianSubtitle: 'تلفیق شاهکارهای گوشت، صید روز و ترافل',
    thumbnail: filetImg,
    icon3D: 'crown',
  },
  {
    id: 'fromages',
    frenchTitle: 'Fromages Affinés',
    persianTitle: 'تخته پنیرهای کهن',
    persianSubtitle: 'منتخبی از نایاب‌ترین پنیرهای دست‌ساز فرانسه',
    thumbnail: cheeseBoardImg,
    icon3D: 'cheese',
  },
  {
    id: 'desserts',
    frenchTitle: 'Desserts & Pâtisserie',
    persianTitle: 'دسرهای دست‌ساز فاخر',
    persianSubtitle: 'شکلات والورونا، تارت تاتن و وانیل ماداگاسکار',
    thumbnail: dessertImg,
    icon3D: 'flame',
  },
  {
    id: 'boissons',
    frenchTitle: 'Nectars & Infusions',
    persianTitle: 'اکسیرها و نوشیدنی‌ها',
    persianSubtitle: 'عصاره‌های میوه‌ای گازدار، موکتیل‌های دست‌چین و دمنوش‌ها',
    thumbnail: elixirImg,
    icon3D: 'wine',
  },
];

export const DISHES: Dish[] = [
  {
    id: 'filet-mignon-truffe',
    frenchName: 'Filet Mignon Sauce Truffe Noire & Poivre Vert',
    persianName: 'فیله مینیون با سس ترافل سیاه و فلفل سبز ماداگاسکار',
    persianSubtitle: 'راسته گوساله بلژیکی با پوره ابریشمی کره فرانسوی ژوئل روبوشون و ورق طلای ۲۴ عیار',
    category: 'plats',
    priceTomans: 3850000,
    formattedPrice: '۳,۸۵۰,۰۰۰ تومان',
    image: filetImg,
    galleryImages: [
      {
        url: filetImg,
        title: 'نمای بالا و چیدمان شاهانه',
        perspective: 'پلاتینگ اصلی سر میز با ورق طلای خوراکی ۲۴ عیار و پوره ژوئل روبوشون'
      },
      {
        url: 'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=800&auto=format&fit=crop',
        title: 'برش مغزپخت مدیوم-ریر',
        perspective: 'بافت آبدار و لطیف راسته بلک آنگوس با مرینیت سبزیجات آلپ'
      },
      {
        url: 'https://images.unsplash.com/photo-1558030006-450675393462?q=80&w=800&auto=format&fit=crop',
        title: 'سس ترافل در حال چکیدن',
        perspective: 'عصاره غلیظ دنبلان کوهی پرودانس با کره قهوه‌ای برتانی'
      },
      {
        url: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=800&auto=format&fit=crop',
        title: 'مواد اولیه اعلا و هم‌نشین‌ها',
        perspective: 'فلفل سبز معطر ماداگاسکار و سبزیجات مینیاتوری بخارپز'
      }
    ],
    isSignature: true,
    isRotating: true,
    prepTimeMinutes: 28,
    calories: 680,
    description: 'شاهکار سرآشپز پیر لوران؛ فیله مینیون دست‌چین با مرینیت ۴۸ ساعته سبزیجات آلپ، پخته شده به شیوه سو-وید و تفت داده شده با کره نورماندی. همراه با عصاره غلیظ ترافل سیاه پرودانس، فلفل سبز تازه و ورقه‌های طلای خوراکی.',
    ingredients: [
      'فیله گوساله اعلا درجه یک (Black Angus)',
      'سس قارچ دنبلان (ترافل سیاه پرون)',
      'پوره سیب‌زمینی ابریشمی با کره اشیره فرانسوی',
      'فلفل سبز معطر ماداگاسکار',
      'ورق طلای خوراکی ۲۴ عیار',
      'سبزیجات مینیاتوری بخارپز'
    ],
    sommelierPairing: 'نوشیدنی گازدار عصاره انگور سیاه روبر شاتلو با نت‌های وانیل و بلوط فرانسوی',
    chefNote: 'برای درک عمق طعم، درجه پخت مدیوم-ریر (Medium Rare) را اکیداً پیشنهاد می‌کنیم.',
    serviceRitual: 'سرو پای میز با کلوش سیلور گرم و پاشیدن نمک دانه درشت فلور دو سل در برابر مهمان.',
    originStory: 'الهام‌گرفته از منوی تاریخی رستوران لا تور دارژان پاریس در دهه ۱۹۶۰.',
    dietaryTags: ['حلال ۱۰۰٪', 'بدون گلوتن', 'امضای سرآشپز'],
    rating: 4.98,
    reviewsCount: 142,
  },
  {
    id: 'foie-gras-poele',
    frenchName: 'Foie Gras Poêlé aux Figues et Pain d’Épices',
    persianName: 'فوا گرا تفت‌داده با انجیر کاراملی و ادویه‌جات اعلا',
    persianSubtitle: 'جگر غاز اعلای پرودانس با سس احیاشده انگور و نان تست عسلی',
    category: 'entrees',
    priceTomans: 2950000,
    formattedPrice: '۲,۹۵۰,۰۰۰ تومان',
    image: foieGrasImg,
    galleryImages: [
      {
        url: foieGrasImg,
        title: 'چیدمان اصلی کلاسیک',
        perspective: 'تفت طلایی روی ظروف سنگ گرانیت سیاه عمارت'
      },
      {
        url: 'https://images.unsplash.com/photo-1514944298352-2b87e221d6eb?q=80&w=800&auto=format&fit=crop',
        title: 'جزئیات کارامل انجیر',
        perspective: 'انجیر سیاه پخته در سرکه بالزامیک ۲۰ ساله مودنا'
      },
      {
        url: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=800&auto=format&fit=crop',
        title: 'تست بریوش معطر',
        perspective: 'نان تست عسلی کره‌ای برشته شده روی تابه مسی'
      }
    ],
    isSignature: true,
    isRotating: false,
    prepTimeMinutes: 18,
    calories: 520,
    description: 'پیش‌غذای اصیل اشراف فرانسه؛ بافتی ابریشمی که روی تابه مسی با شعله تیز تفت خورده، با شیرینی ظریف انجیرهای تازه سیاه پخته‌شده در سرکه بالزامیک کهنه مودنا و نمک دریایی گرانده.',
    ingredients: [
      'فوا گرا دست‌چین جنوب غربی فرانسه',
      'انجیر سیاه کاراملیزه با عسل وحشی زاگرس',
      'کاهش سرکه بالزامیک ۲۰ ساله',
      'نان بریوش گرم و تست شده',
      'فلوت نمک دریایی فلور دو سل'
    ],
    sommelierPairing: 'اکسیر انگور سفید سوترن با عطر زردآلو و گل یاس',
    chefNote: 'ترکیب حرارت سطح برشته و مغز لطیف فوا گرا، هارمونی شگفت‌انگیزی خلق می‌کند.',
    serviceRitual: 'همراه با نان گرم در پارچه کتان دست‌دوز و کارد مخصوص سرو جگر.',
    originStory: 'دستور ثبت‌شده در دفاتر مهمان‌داری دوک‌های بوردو در قرن نوزدهم.',
    dietaryTags: ['حلال ۱۰۰٪', 'لوکس کلاسیک'],
    rating: 4.94,
    reviewsCount: 88,
  },
  {
    id: 'tartare-saumon-caviar',
    frenchName: 'Tartare de Saumon Sauvage et Caviar Impérial',
    persianName: 'تارتار سالمون وحشی نروژ با خاویار امپریال بلوگا',
    persianSubtitle: 'سالمون دست‌چین با لیمو ترش پرودانس، آووکادو هاس و مرواریدهای خاویار خزر',
    category: 'entrees',
    priceTomans: 3400000,
    formattedPrice: '۳,۴۰۰,۰۰۰ تومان',
    image: salmonCaviarImg,
    galleryImages: [
      {
        url: salmonCaviarImg,
        title: 'نمای مرواریدهای خاویار',
        perspective: 'سرو در ظرف یخ بلورین با قاشق صدف مادر-مروارید'
      },
      {
        url: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?q=80&w=800&auto=format&fit=crop',
        title: 'تکسچر و بافت مکعبی سالمون',
        perspective: 'برش‌های دست‌ساز و لایه‌بندی آووکادو ارگانیک'
      },
      {
        url: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=800&auto=format&fit=crop',
        title: 'چاشنی‌ها و کراکر ترد',
        perspective: 'روغن زیتون فرابکر دره پرون با گل‌های خوراکی بنفشه'
      }
    ],
    isSignature: true,
    isRotating: false,
    prepTimeMinutes: 16,
    calories: 380,
    description: 'ترکیبی شاهانه از سالمون تازه نروژی خرد شده با دست، طعم‌دار شده با شالت، کپر، روغن زیتون بکر اکسترا ویرجین و تزیین شده با ۵۰ گرم خاویار بلوگا امپریال و کراکر دست‌ساز.',
    ingredients: [
      'فیله سالمون وحشی تازه نروژ',
      'خاویار سیاه اصیل بلوگا امپریال',
      'آووکادو هاس مکزیکی تازه',
      'روغن زیتون ارگانیک دره پرون',
      'سس خردل دیژون ملایم و لیمو تازه'
    ],
    sommelierPairing: 'نوشیدنی گازدار طلایی رزماری و گریپ‌فروت صورتی',
    chefNote: 'خاویار با قاشق مرواریدی مادر-مروارید سرو می‌شود تا خلوص طعم حفظ گردد.',
    serviceRitual: 'سرو بر روی بستری از تکه‌های یخ تراشیده با کریستال‌های باکارا.',
    dietaryTags: ['حلال ۱۰۰٪', 'غذای دریایی فاخر', 'بدون گلوتن'],
    rating: 4.97,
    reviewsCount: 94,
  },
  {
    id: 'magret-de-canard',
    frenchName: 'Magret de Canard Rôti au Miel et Épices Douces',
    persianName: 'سینه اردک برشته با عسل وحشی و سس آلبالوی کوهی',
    persianSubtitle: 'اردک فرانسوی بارباری با پوست کاراملی ترد، پوره کدو حلوایی و ادویه‌های گرم',
    category: 'plats',
    priceTomans: 3250000,
    formattedPrice: '۳,۲۵۰,۰۰۰ تومان',
    image: duckImg,
    galleryImages: [
      {
        url: duckImg,
        title: 'چیدمان اصلی و رنگین',
        perspective: 'برش‌های هندسی سینه اردک با کاهش غلیظ شاه‌توت کوهی'
      },
      {
        url: 'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=800&auto=format&fit=crop',
        title: 'پوست کریسپی طلایی',
        perspective: 'پوست کاراملیزه مشبک با عسل اسطوخودوس'
      }
    ],
    isSignature: true,
    isRotating: false,
    prepTimeMinutes: 24,
    calories: 720,
    description: 'سینه اردک اصیل با برش‌های مشبک روی پوست، تفت داده شده تا نهایت تردی طلایی، سرو شده در کنار پوره معطر کدو تنبل با هل و زنجبیل و سس کاهشی شاتوبریان آلبالوی جنگلی.',
    ingredients: [
      'سینه اردک بارباری گرید A',
      'عسل بهاره با عصاره اسطوخودوس',
      'سس ترش و شیرین شاه‌توت و آلبالو',
      'پوره لطیف کدو حلوایی با کره اشیره',
      'هویج‌های مینیاتوری کاراملی'
    ],
    sommelierPairing: 'نکتار انار یاقوتی با گلپر و دارچین ملایم',
    chefNote: 'گوشت صورتی و آبدار اردک با تندی ملایم فلفل چهار فصل تلفیق شده است.',
    serviceRitual: 'برش ظریف در حضور مهمان توسط سرپیشخدمت ارشد.',
    dietaryTags: ['حلال ۱۰۰٪', 'کلاسیک جنوب فرانسه'],
    rating: 4.92,
    reviewsCount: 76,
  },
  {
    id: 'sole-meuniere',
    frenchName: 'Sole Meunière au Beurre Noisette et Câpres',
    persianName: 'ماهی حلوا سفید فرانسوی با کره فندقی و کپر',
    persianSubtitle: 'صید روز اقیانوس اطلس، پخته شده به سبک منیر با لیمو ترش سیسیلی و جعفری',
    category: 'plats',
    priceTomans: 3650000,
    formattedPrice: '۳,۶۵۰,۰۰۰ تومان',
    image: salmonCaviarImg,
    galleryImages: [
      {
        url: salmonCaviarImg,
        title: 'نمای کامل سرو سر میز',
        perspective: 'سرو بر روی دیس نقره با کره طلایی در حال جوش'
      },
      {
        url: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?q=80&w=800&auto=format&fit=crop',
        title: 'بافت فیله و کپر',
        perspective: 'فیله‌برداری بدون استخوان با مهارت پیشخدمت ارشد'
      }
    ],
    isSignature: true,
    isRotating: false,
    prepTimeMinutes: 22,
    calories: 510,
    description: 'ماهی کفشک (Sole) کامل با فیله‌برداری اختصاصی سر میز توسط کاپیتان ارشد سالن. پخته‌شده در کره برنزه شده (Beurre Noisette) که عطر فندقی شگفت‌انگیزی آزاد می‌کند.',
    ingredients: [
      'ماهی سل دوور تازه اقیانوس اطلس',
      'کره قهوه‌ای تفت‌داده شده برتانی',
      'کپرهای مدیترانه‌ای شور ملایم',
      'آبلیموی تازه سیسیلی فشرده',
      'سیب‌زمینی‌های بخارپز پاریسی با شوید تازه'
    ],
    sommelierPairing: 'اکسیر سیب سبز ترش، خیار و رازیانه کوهی',
    chefNote: 'سرو و پاک کردن استخوان ماهی مستقیماً در برابر دیدگان مهمان صورت می‌پذیرد.',
    serviceRitual: 'فیله‌برداری تشریفاتی با دو کارد نقره‌ای سر میز.',
    dietaryTags: ['حلال ۱۰۰٪', 'دریایی ویژه', 'امضای سالن'],
    rating: 4.96,
    reviewsCount: 81,
  },
  {
    id: 'plateau-fromages-affines',
    frenchName: 'Plateau de Grands Fromages Affinés (4 Variétés)',
    persianName: 'تخته پنیرهای اعلای کهن فرانسوی با انجیر و گردو',
    persianSubtitle: 'کومته ۳۶ ماهه، رکفور غارهای روکفور، بری دومو و شور خاکستری با نان گردویی',
    category: 'fromages',
    priceTomans: 2200000,
    formattedPrice: '۲,۲۰۰,۰۰۰ تومان',
    image: cheeseBoardImg,
    galleryImages: [
      {
        url: cheeseBoardImg,
        title: 'تخته بلوط فرانسوی',
        perspective: 'چیدمان چهار پنیر با علامت‌های کهنگی و مربای انجیر خانگی'
      },
      {
        url: 'https://images.unsplash.com/photo-1631379578550-7038263db699?q=80&w=800&auto=format&fit=crop',
        title: 'بافت پنیرهای دست‌ساز',
        perspective: 'برش‌های دست‌چین با مغز گردوی تویسرکان و عسل آویشن'
      }
    ],
    isSignature: false,
    isRotating: false,
    prepTimeMinutes: 10,
    calories: 460,
    description: 'سفر در تاریخ لبنیات فرانسه؛ چهار قطعه از دست‌سازترین پنیرهای کنترل‌شده با نشان اصالت AOC، همراه با انجیر خشک، بادام درختی بو داده، مربای خانگی گلابی و نان خمیرترش داغ.',
    ingredients: [
      'پنیر کومته ۳۶ ماهه غار ژورا',
      'پنیر رگه‌آبی روکفور شیر گوسفند',
      'بری دو مو نرم با عطر قارچ وحشی',
      'پنیر بز شور پوشیده از خاکستر چوب',
      'عسل طبیعی و نان خمیرترش گردویی'
    ],
    sommelierPairing: 'دمنوش سرد گل گاوزبان و بهارنارنج با عسل',
    chefNote: 'پیشنهاد می‌شود پنیرها از لطیف‌ترین (بری) به قوی‌ترین (روکفور) چشیده شوند.',
    serviceRitual: 'توضیح تاریخچه هر پنیر توسط کارشناس پنیر عمارت.',
    dietaryTags: ['بدون گوشت', 'AOC فرانسه'],
    rating: 4.93,
    reviewsCount: 52,
  },
  {
    id: 'souffle-chocolat-valrhona',
    frenchName: 'Soufflé Chaud au Chocolat Valrhona Guanaja 70%',
    persianName: 'سوفله گرم شکلات تلخ ۷۰٪ والورونا با بستنی وانیل بوربون',
    persianSubtitle: 'سوفله پف‌کرده تازه با شکلات گواناجا و بستنی دست‌ساز وانیل ماداگاسکار',
    category: 'desserts',
    priceTomans: 1650000,
    formattedPrice: '۱,۶۵۰,۰۰۰ تومان',
    image: dessertImg,
    galleryImages: [
      {
        url: dessertImg,
        title: 'پف طلایی سوفله در رمکین',
        perspective: 'خروج مستقیم از فر با ارتفاع ۳ سانتی‌متر بالای لبه ظرف'
      },
      {
        url: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?q=80&w=800&auto=format&fit=crop',
        title: 'ریختن گاناش شکلات داغ',
        perspective: 'سوراخ کردن مرکز سوفله و ریختن کرم وانیل مذاب'
      }
    ],
    isSignature: true,
    isRotating: true,
    prepTimeMinutes: 20,
    calories: 490,
    description: 'اوج هنر قنادی پاریس؛ سوفله‌ای با پوسته نازک برشته و قلبی مذاب و ابریشمی از شکلات ناب گواناجا ۷۰٪ والورونا فرانسه. سر میز باز شده و یک اسکوپ بستنی خنک وانیل ماداگاسکار در مرکز آن جای می‌گیرد.',
    ingredients: [
      'شکلات خالص والورونا گواناجا ۷۰٪',
      'تخم‌مرغ‌های ارگانیک تازه محلی',
      'کره فرانسوی اشیره و شکر نیشکر قهوه‌ای',
      'دانه‌های وانیل طبیعی جزیره ماداگاسکار',
      'پودر قند ظریف و پسته دست‌چین'
    ],
    sommelierPairing: 'قهوه اسپرسو دوبل روست اختصاصی یا موکتیل شکلات سرد',
    chefNote: 'مدت پخت دقیقاً ۱۲ دقیقه است و باید ظرف ۳ دقیقه پس از خروج از فر سرو شود.',
    serviceRitual: 'شکستن سطح پف‌کرده با قاشق طلایی و ریختن گاناش گرم در برابر مهمان.',
    originStory: 'خلق‌شده بر اساس دستور قرن هفدهم کاخ ورسای برای لویی چهاردهم.',
    dietaryTags: ['دسر امضا', 'شکلات دست‌ساز'],
    rating: 4.99,
    reviewsCount: 165,
  },
  {
    id: 'nectar-royal-elixir',
    frenchName: 'Élixir Impérial aux Baies d’Or et Rose de Damas',
    persianName: 'اکسیر شاهانه توت‌های طلایی و عصاره گل‌سرخ',
    persianSubtitle: 'نکتار دست‌ساز تمشک وحشی، زعفران قائنات، آب گازدار فرانسوی و اکلیل خوراکی',
    category: 'boissons',
    priceTomans: 850000,
    formattedPrice: '۸۵۰,۰۰۰ تومان',
    image: elixirImg,
    galleryImages: [
      {
        url: elixirImg,
        title: 'درخشش اکلیل طلایی در گیلاس',
        perspective: 'گیلاس کریستال سنت لوئیس با مه‌ساز یخ خشک اختصاصی'
      },
      {
        url: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?q=80&w=800&auto=format&fit=crop',
        title: 'ریختن گازدار بر بستر میوه‌ها',
        perspective: 'تلفیق تمشک ارگانیک با عطر بهارنارنج و گلاب دوآتیشه'
      }
    ],
    isSignature: true,
    isRotating: false,
    prepTimeMinutes: 8,
    calories: 140,
    description: 'نوشیدنی خوش‌آمدگویی رسمی عمارت ملاقات؛ آب‌میوه‌های فصلی دست‌افشره با جوشانده زعفران سوپر نگین، عصاره بهارنارنج و گاز ملایم در گیلاس‌های کریستال پایه‌بلند با درخشش ورقه‌های طلای شناور.',
    ingredients: [
      'عصاره تمشک و شاتوت تازه جنگلی',
      'عصاره طبیعی زعفران سوپر نگین خراسان',
      'آب چشمه گازدار پریه فرانسه',
      'عصاره گل‌سرخ کاشان و بهارنارنج شیراز',
      'اکلیل خوراکی و ورق طلای شناور'
    ],
    sommelierPairing: 'مناسب برای آغاز ضیافت یا همراهی با پیش‌غذاهای لطیف',
    chefNote: 'پیش از نوشیدن، لیوان را به آرامی بچرخانید تا گرد طلا در نور شمع‌ها بدرخشد.',
    serviceRitual: 'سرو با افکت مه‌ساز دود ملایم بر روی دیس کریستالی.',
    dietaryTags: ['ارگانیک ۱۰۰٪', 'بدون الکل', 'نوشیدنی امضا'],
    rating: 4.95,
    reviewsCount: 118,
  },
];

export const SALON_EXPERIENCES: SalonExperience[] = [
  {
    id: 'salon-louis-xiv',
    persianName: 'تالار اصلی کاخ ورسای (Salon Louis XIV)',
    frenchName: 'Le Grand Salon Versailles',
    capacity: 'ظرفیت ۲ الی ۸ نفر',
    image: interiorImg,
    description: 'تالار مرکزی عمارت با لوسترهای کریستال باکارای قرن ۱۹، پرده‌های مخمل زرشکی دست‌بافت و پیانوگرند زنده که اجرای قطعات فرانسوی را در طول شب طنین‌انداز می‌کند.',
    features: ['موسیقی زنده پیانوی کلاسیک', 'پیشخدمت اختصاصی ملبس به فراک رسمی', 'میزهای سنگ مرمر کارارا'],
    recommendedFor: 'سالگردهای باشکوه، قرارهای عاشقانه و پذیرایی از مهمانان ویژه',
  },
  {
    id: 'salon-prive-diamant',
    persianName: 'سالن وی‌آی‌پی الماس (Salon Privé Diamant)',
    frenchName: 'Le Salon Privé Diamant',
    capacity: 'ظرفیت ۶ الی ۱۶ نفر',
    image: chefImg,
    description: 'اتاق ضیافت کاملاً خصوصی با ورودی مجزا از باغ، سیستم تهویه هوای هپا، شومینه سنگ مرمر طبیعی، بادی‌گارد اختصاصی تشریفات و امکان تنظیم نور و موسیقی اختصاصی.',
    features: ['ورودی کاملاً مستقل از حیاط اختصاصی', 'میزبانی سرآشپز پیر لوران پای میز', 'سیستم اکوستیک و صوتی سفارشی'],
    recommendedFor: 'جلسات دیپلماتیک، ضیافت‌های عقد و قرارهای مهم کاری نخبگان و پزشکان مشهد',
  },
  {
    id: 'terrasse-etoilee',
    persianName: 'بالکن ستاره‌باران عمارت (Terrasse Étoilée)',
    frenchName: 'La Terrasse Étoilée',
    capacity: 'ظرفیت ۲ الی ۴ نفر',
    image: terraceImg,
    description: 'تراس مرتفع با چشم‌انداز شب‌های مشهد و باغ عمارت، مجهز به سیستم گرمایش هوایی هوشمند و چیدمان شمع‌های بی‌پایان برای سالگردها و لحظات عاشقانه.',
    features: ['دید ۳۶۰ درجه به شب‌های آرام مشهد', 'چیدمان گل‌های طبیعی با سفارش اختصاصی', 'عکاس اختصاصی تشریفات در صورت تمایل'],
    recommendedFor: 'خواستگاری‌های اشرافی، سورپرایزهای تولد و جشن‌های دونفره',
  },
];

export const VIP_CHAUFFEUR_OPTIONS = [
  {
    id: 'bmw7',
    name: 'ب‌ام‌و سری ۷ تشریفات (BMW 7-Series)',
    description: 'ترانسفر رفت و برگشت VIP با راننده آموزش‌دیده کت‌وشلواری در سراسر مشهد (سجاد، احمدآباد، وکیل‌آباد، کوهسنگی، فرودگاه و هتل‌های ۵ ستاره)',
    priceTomans: 1800000,
    formattedPrice: '۱,۸۰۰,۰۰۰ تومان',
    icon: 'car',
  },
  {
    id: 'mercedes-s',
    name: 'مرسدس بنز اس کلاس (Mercedes-Benz S-Class)',
    description: 'اوج وقار و آرامش؛ خودروی تشریفات سیاه با آب‌میوه تازه و نشریات روز اقتصادی و هنری فرانسه',
    priceTomans: 2400000,
    formattedPrice: '۲,۴۰۰,۰۰۰ تومان',
    icon: 'crown',
  },
];

export const LUXURY_GIFT_CARDS: LuxuryGiftCard[] = [
  {
    id: 'carte-or',
    title: 'کارت ضیافت اشرافی طلایی',
    frenchTitle: 'Invitation Dîner d’Or',
    amountTomans: 10000000,
    formattedAmount: '۱۰,۰۰۰,۰۰۰ تومان',
    packaging: 'جعبه مخمل دست‌دوز زرشکی با نشان برنزی برجسته ملاقات و موم سرخ فرانسوی',
    perks: ['شامل منوی کامل ۴ مرحله‌ای برای ۲ نفر', 'میز اختصاصی با رزرو VIP در تالار ورسای', 'دسر سفارشی با شمع دست‌ساز'],
  },
  {
    id: 'carte-diamant',
    title: 'کارت ضیافت امپریال الماس',
    frenchTitle: 'Invitation Impériale Diamant',
    amountTomans: 25000000,
    formattedAmount: '۲۵,۰۰۰,۰۰۰ تومان',
    packaging: 'قاب خاتم چرم ایتالیایی با کارت طلایی حکاکی شده با نام مهمان',
    perks: ['شامل سرویس کامل خاویار بار و شام ۵ کورس', 'ترانسفر رفت و برگشت با ب‌ام‌و سری ۷ در مشهد', 'مشاوره اختصاصی سرآشپز پیر لوران'],
  },
];

export const WALKTHROUGH_STEPS: WalkthroughStep[] = [
  {
    id: 1,
    title: 'عمارت باشکوه در بلوار سجاد مشهد',
    frenchTitle: 'La Grande Entrée à Mashhad',
    persianDescription: 'گذر از هیاهوی شهر و ورود به محوطه اختصاصی و رویایی عمارت ملاقات؛ جایی که سکوت، نورپردازی کهربایی و استقبال گرم تشریفات ولت، آغازگر شبی به یادماندنی است.',
    image: facadeImg,
    highlightText: 'استقبال دربان اختصاصی و پارک خودروی شما توسط تشریفات ولت',
    soundCue: 'نواهای آرام پیانوی کلاسیک فرانسوی و نسیم ملایم باغ عمارت',
  },
  {
    id: 2,
    title: 'ورود به تالار لوسترهای کریستال',
    frenchTitle: 'L’Arrivée dans la Salle des Miroirs',
    persianDescription: 'پیشخدمت ارشد با خوش‌آمدگویی گرم شما را به میز رزرو شده هدایت می‌کند. شمع‌های روشن، گیلاس‌های کریستال و عطر گل‌های سفید تازه فضا را پر کرده‌اند.',
    image: interiorImg,
    highlightText: 'اکسیر پیش‌درآمد فصلی به همراه نان بریوش گرم فرانسوی',
    soundCue: 'صدای طنین قطعه کلر دو لون دبوسی بر کلاویه‌های گرندپیانو',
  },
  {
    id: 3,
    title: 'خلق طعم توسط سرآشپز پیر لوران',
    frenchTitle: 'La Création Gastronomique',
    persianDescription: 'هر ظرف مانند یک بوم نقاشی از طعم‌هاست؛ تفت دادن گوشت‌های ناب با کره نورماندی، رنده‌کردن ترافل سیاه تازه و پوشش ورق طلای خوراکی در برابر چشمان شما.',
    image: chefImg,
    highlightText: 'توضیح کامل فلسفه طعم هر غذا توسط سرمیزبان اختصاصی',
    soundCue: 'حرارت دلنشین تابه مسی و شکوه لحظه سرو پای میز',
  },
  {
    id: 4,
    title: 'خاتمه با شکوه و بدرقه اختصاصی',
    frenchTitle: 'La Cérémonie de Départ',
    persianDescription: 'پایان شب با سوفله‌های داغ والورونا، قهوه تازه آسیاب‌شده و تحویل خودروی تمیز شما در درب عمارت با بدرقه تیم تشریفات ملاقات.',
    image: dessertImg,
    highlightText: 'هدیه یادبود جعبه ماکارون دست‌پز سرآشپز برای هر میز',
    soundCue: 'خاطره‌ای جاودانه از آرامش و شکوه در قلب مشهد',
  },
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'g1',
    title: 'نمای شبانه عمارت ملاقات در بلوار سجاد مشهد',
    category: 'interior',
    categoryLabel: 'تالار و عمارت',
    image: facadeImg,
    description: 'نورپردازی آرام و اصالت معماری مدرن-کلاسیک در قلب بلوار سجاد مشهد.',
  },
  {
    id: 'g2',
    title: 'چیدمان میز تالار الماس ورسای',
    category: 'interior',
    categoryLabel: 'تالار و عمارت',
    image: interiorImg,
    description: 'ظروف نقره کریستوفل، گیلاس‌های باکارا و رومیزی‌های کتان دست‌دوز.',
  },
  {
    id: 'g3',
    title: 'فیله مینیون با ترافل سیاه و ورق طلا',
    category: 'cuisine',
    categoryLabel: 'هنر آشپزی',
    image: filetImg,
    description: 'گوشت اعلای تفت خورده با کره اشیره و ورقه طلای ۲۴ عیار.',
  },
  {
    id: 'g4',
    title: 'تارتار سالمون وحشی با خاویار امپریال بلوگا',
    category: 'cuisine',
    categoryLabel: 'هنر آشپزی',
    image: salmonCaviarImg,
    description: 'سالمون تازه نروژی با مرواریدهای خاویار خزر و آووکادو هاس.',
  },
  {
    id: 'g5',
    title: 'سوفله گرم شکلات والورونا ۷۰٪',
    category: 'cuisine',
    categoryLabel: 'هنر آشپزی',
    image: dessertImg,
    description: 'پف طلایی و عطر مست‌کننده شکلات خالص گواناجا و وانیل ماداگاسکار.',
  },
  {
    id: 'g6',
    title: 'سرآشپز پیر لوران در حال تزیین بشقاب امضا',
    category: 'vip',
    categoryLabel: 'تیم و تشریفات',
    image: chefImg,
    description: 'تمرکز بی‌نهایت بر میلی‌متر به میلی‌متر چیدمان هر اثر هنری روی بشقاب.',
  },
  {
    id: 'g7',
    title: 'تراس ستاره‌باران در شب‌های سجاد',
    category: 'vip',
    categoryLabel: 'فضاهای اختصاصی',
    image: terraceImg,
    description: 'چشم‌انداز اختصاصی و چیدمان صدها شمع برای مناسبت‌های دونفره.',
  },
  {
    id: 'g8',
    title: 'فوا گرا تفت‌داده با انجیر سیاه کاراملی',
    category: 'cuisine',
    categoryLabel: 'هنر آشپزی',
    image: foieGrasImg,
    description: 'شاهکار کلاسیک پرودانس با سس کاهشی بالزامیک ۲۰ ساله.',
  },
  {
    id: 'g9',
    title: 'تخته پنیرهای کهن فرانسوی با نشان AOC',
    category: 'cuisine',
    categoryLabel: 'هنر آشپزی',
    image: cheeseBoardImg,
    description: 'منتخبی از نایاب‌ترین پنیرهای دست‌ساز با نان گرم خمیرترش.',
  },
];

export const JALALI_MONTHS = [
  'فروردین', 'اردیبهشت', 'خرداد',
  'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر',
  'دی', 'بهمن', 'اسفند'
];

export const JALALI_WEEKDAYS = [
  'شنبه', 'یک‌شنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه'
];

export const TIME_SLOTS = [
  { id: 'slot-1', time: '19:30', label: '۱۹:۳۰ الی ۲۱:۳۰ (ضیافت گرگ و میش)', badge: 'سانس اول' },
  { id: 'slot-2', time: '21:45', label: '۲۱:۴۵ الی ۲۳:۴۵ (ضیافت شبانه با پیانوی زنده)', badge: 'محبوب‌ترین' },
  { id: 'slot-3', time: '22:30', label: '۲۲:۳۰ الی ۰۰:۳۰ (ضیافت نیمه‌شب)', badge: 'خلوت و آرام' },
];

export const OCCASIONS = [
  'ضیافت شام رسمی و کاری',
  'سالگرد ازدواج و پیوند اشرافی',
  'جشن تولد اختصاصی VIP',
  'دیدار دیپلماتیک و مهمانان بین‌المللی',
  'دورهمی خانوادگی فاخر',
  'پذیرایی آزاد و شخصی'
];

export const SALONS = [
  {
    id: 'salon-louis-xiv',
    persianName: 'تالار اصلی کاخ ورسای',
    frenchName: 'Le Grand Salon Versailles',
    capacity: 'ظرفیت ۲ تا ۸ نفر',
    description: 'لوسترهای باکارای قرن ۱۹، نوای زنده پیانو و پیشخدمت‌های اختصاصی.',
  },
  {
    id: 'salon-prive-diamant',
    persianName: 'سالن VIP الماس',
    frenchName: 'Le Salon Privé Diamant',
    capacity: 'ظرفیت ۶ تا ۱۶ نفر',
    description: 'اتاق اختصاصی با ورودی مجزا از باغ، شومینه مرمر و حضور سرآشپز پای میز.',
  },
  {
    id: 'terrasse-etoilee',
    persianName: 'تراس ستاره‌باران عمارت',
    frenchName: 'La Terrasse Étoilée',
    capacity: 'ظرفیت ۲ تا ۴ نفر',
    description: 'چشم‌انداز مرتفع شب‌های مشهد با سیستم گرمایش هوایی و صدها شمع طبیعی.',
  },
  {
    id: 'salon-opera',
    persianName: 'سالن اپرا و پیانو بار',
    frenchName: 'Le Salon Opéra',
    capacity: 'ظرفیت ۲ تا ۶ نفر',
    description: 'مجاورت با سن پیانوگرند، مبلمان چرم ایتالیایی و اتمسفر رمانتیک.',
  },
];

