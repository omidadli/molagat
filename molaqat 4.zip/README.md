# ملاقات | Molaqat Haute Gastronomie 🇫🇷✨

وب‌سایت رسمی و لوکس رستوران فاخر فرانسوی «ملاقات» (مشهد، بلوار سجاد).

---

## 🚀 راهنمای جامع استقرار (Deploy)

### روش اول: دیپلوی با درگ و دراپ در Netlify Drop (ساده‌ترین و سریع‌ترین)
1. فایل زیپ خروجی پروژه را Extract (از حالت فشرده خارج) کنید.
2. وارد سایت [app.netlify.com/drop](https://app.netlify.com/drop) شوید.
3. **فقط پوشه `dist`** را با موس بکشید و داخل کادر صفحه Netlify Drop بیندازید (Drag & Drop).
4. سایت شما ظرف ۳ ثانیه به صورت آنلاین و کامل فعال می‌شود!

> 💡 **نکته کلیدی:** اگر می‌خواهید با درگ و دراپ در Netlify دیپلوی کنید، باید پوشه **`dist`** (که حاوی فایل‌های کامپایل‌شده نهایی `index.html` و `assets` است) را درگ کنید، نه کل پوشه سورس کد را.

---

### روش دوم: دیپلوی خودکار از طریق GitHub در Netlify / Vercel
اگر پروژه را در GitHub قرار داده‌اید:
1. در پنل Netlify روی **Add new site > Import an existing project** کلیک کنید.
2. مخزن گیت‌هاب را انتخاب کنید.
3. تنظیمات از قبل در فایل `netlify.toml` تعریف شده است:
   - **Build Command:** `npm run build`
   - **Publish directory:** `dist`
4. روی **Deploy Site** کلیک کنید.

---

### روش سوم: توسعه و اجرای محلی (Local Development)
```bash
# نصب وابستگی‌ها
npm install

# اجرای سرور توسعه
npm run dev

# ساخت نسخه پروداکشن
npm run build

# پیش‌نمایش نسخه بیلد شده
npm run preview
```
